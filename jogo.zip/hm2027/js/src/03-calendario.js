  // ============================= 03-calendario.js =============================
  // Calendário (jornadas, método do círculo)
  // Fixtures (circle method, double round robin)
  // =================================================================
  function shuffleArray(arr){
    const a = arr.slice();
    for(let i=a.length-1;i>0;i--){
      const j = Math.floor(Math.random()*(i+1));
      const tmp = a[i]; a[i]=a[j]; a[j]=tmp;
    }
    return a;
  }
  function validateFixtures(fixtures, teamIds){
    const n = teamIds.length;
    const isOdd = n % 2 !== 0;
    const expectedRounds = isOdd ? n*2 : (n-1)*2;  // com bye, cada volta precisa de N jornadas, não N-1
    if(fixtures.length !== expectedRounds) return false;
    const expectedGamesPerRound = Math.floor(n/2);
    const pairCount = {};
    const homeAway = {}; teamIds.forEach(id=>homeAway[id]={home:0,away:0});
    const byesPerTeam = {}; teamIds.forEach(id=>byesPerTeam[id]=0);
    for(const round of fixtures){
      if(round.length !== expectedGamesPerRound) return false;
      const seen = new Set();
      for(const m of round){
        if(m.home===m.away) return false;
        if(seen.has(m.home) || seen.has(m.away)) return false;
        seen.add(m.home); seen.add(m.away);
        homeAway[m.home].home++; homeAway[m.away].away++;
        const key = [m.home,m.away].sort().join("|");
        pairCount[key] = (pairCount[key]||0)+1;
      }
      if(isOdd){
        // exatamente uma equipa de descanso (bye) por jornada, quando o número é ímpar
        const resting = teamIds.filter(id=>!seen.has(id));
        if(resting.length !== 1) return false;
        byesPerTeam[resting[0]]++;
      }
    }
    for(const key in pairCount) if(pairCount[key] !== 2) return false;
    for(const id of teamIds) if(homeAway[id].home !== n-1 || homeAway[id].away !== n-1) return false;
    if(isOdd){
      // cada equipa deve descansar exatamente 2 vezes ao longo da época (1 por volta)
      for(const id of teamIds) if(byesPerTeam[id] !== 2) return false;
    }
    return true;
  }
  // Baralha a ordem das equipas antes de gerar o calendário (nova sequência de jornadas e de
  // jogos em casa/fora a cada época) e valida programaticamente antes de aceitar o resultado.
  function generateValidatedFixtures(teamIds){
    let fixtures, tries = 0;
    do {
      fixtures = generateFixtures(shuffleArray(teamIds));
      tries++;
    } while(!validateFixtures(fixtures, teamIds) && tries < 25);
    return fixtures;
  }

  // Método do círculo (round-robin) com suporte a número ímpar de equipas: acrescenta uma
  // equipa fantasma de "bye" — quem calha emparelhado com ela descansa essa jornada, rotativamente,
  // até todas terem tido exatamente um descanso por volta.
  const BYE_TEAM = "__BYE__";
  function generateFixtures(teamIds){
    const isOdd = teamIds.length % 2 !== 0;
    const arr = isOdd ? teamIds.concat([BYE_TEAM]) : teamIds.slice();
    const n = arr.length, numRounds = n-1, half = n/2;
    let current = arr.slice();
    const firstLeg = [];
    for(let r=0;r<numRounds;r++){
      const roundMatches = [];
      for(let i=0;i<half;i++){
        const a = current[i], b = current[current.length-1-i];
        if(a===BYE_TEAM || b===BYE_TEAM) continue; // equipa emparelhada com o bye descansa esta jornada
        if(r%2===0) roundMatches.push({home:a, away:b, played:false, homeScore:0, awayScore:0});
        else roundMatches.push({home:b, away:a, played:false, homeScore:0, awayScore:0});
      }
      firstLeg.push(roundMatches);
      const fixed = current[0]; const rest = current.slice(1); rest.unshift(rest.pop());
      current = [fixed].concat(rest);
    }
    const secondLeg = firstLeg.map(round => round.map(m => ({home:m.away, away:m.home, played:false, homeScore:0, awayScore:0})));
    return firstLeg.concat(secondLeg);
  }

  // Fase 3: agenda cronologica unica de todas as competicoes.
  // Correção: o id não incluía a época — "placard-2026-27::round-0" era o MESMO id todas as
  // épocas (o roundIndex volta sempre a 0), fazendo com que o estado "processado" de uma ronda
  // já jogada na época anterior contaminasse incorretamente a mesma ronda da época seguinte
  // (ainda por jogar), através do mapa de preservação de estado em rebuildGlobalAgenda. Bug
  // real, confirmado: a 2ª época ficava presa nas primeiras rondas sem nenhum evento pendente.
  function agendaEventId(competitionId, roundIndex, epoca){ return competitionId+"::e"+(epoca!=null?epoca:"?")+"::round-"+roundIndex; }
  function roundIsProcessed(round){ return !!round && round.every(f=>f.played); }
  function rebuildGlobalAgenda(){
    const previous = new Map((state.globalAgenda||[]).map(e=>[e.id,e]));
    const events = [];
    Object.values(state.competitions).forEach(comp=>{
      (comp.fixtures||[]).forEach((round,roundIndex)=>{
        const id=agendaEventId(comp.id,roundIndex,comp.epoca), old=previous.get(id);
        const processed=roundIsProcessed(round)||(old&&old.status==="processado");
        events.push({id,competitionId:comp.id,roundIndex,date:new Date(round.date),status:processed?"processado":"pendente",processedAt:processed?(old&&old.processedAt?new Date(old.processedAt):new Date(round.date)):null});
      });
    });
    events.sort((a,b)=>a.date-b.date||a.competitionId.localeCompare(b.competitionId)||a.roundIndex-b.roundIndex);
    state.globalAgenda=events; return events;
  }
  function agendaEventsForDate(date){ return (state.globalAgenda||[]).filter(e=>e.status==="pendente"&&sameDay(e.date,date)); }
  function markAgendaEventProcessed(eventId){
    const e=(state.globalAgenda||[]).find(x=>x.id===eventId);
    if(!e||e.status==="processado") return false;
    e.status="processado"; e.processedAt=new Date(state.currentDate); return true;
  }
  function syncCompetitionStatus(comp){ if(comp&&comp.currentRound>=comp.fixtures.length) comp.status="concluida"; }
  function resetStats(){ Object.values(state.teams).forEach(t => { t.stats = { J:0,V:0,E:0,D:0,GM:0,GS:0,Pts:0 }; }); }

  // =================================================================
