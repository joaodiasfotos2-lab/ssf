  // ============================= 07g-europa.js =============================
  // Competições Europeias — WSE Champions League, WSE Cup, WSE Trophy e Ronda de Qualificação.
  // Implementação a partir do estudo `HM2027_Estudo_CompeticoesEuropeias_2026-09-12.md` (projeto
  // Claude): ranking real por coeficiente de país (método D'Hondt, validado contra o sorteio real
  // 2026-27 — Portugal 5/Espanha 4/Itália 2/França 1 na Champions League), e uma "nuvem" de clubes
  // REAIS de cada um dos 5 países ainda não jogáveis (França, Alemanha, Suíça, Inglaterra, Áustria)
  // — correção pedida pelo utilizador: só os NOMES DOS JOGADORES são inventados (plantel mínimo no
  // motor real, `generatePlaceholderRoster`); os clubes têm de ser reais. Lista de clubes por país
  // pesquisada em hoqueipatins.pt (ligas de topo de França/Alemanha/Suíça/Inglaterra) e, para a
  // Áustria (sem página própria nesse site), na Vorarlberger Rollsportverband/Rollsport Austria —
  // ver EUROPA_NUVEM_CLUBES_REAIS abaixo. Sem evolução nem mercado, exatamente como decidido no
  // estudo — só a identidade do clube mudou de gerada para real.
  //
  // Nota de arquitetura (decidida ao retomar esta implementação): as três provas + a ronda de
  // qualificação NÃO são modeladas como entradas de state.competitions. Foi confirmado por
  // inspeção de código que processGlobalAgendaForCurrentDate() só dá tratamento interativo
  // (pausa para o jogo do próprio utilizador) à competição de state.userCompetitionId — qualquer
  // outra entrada de state.competitions é sempre resolvida 100% por IA
  // (processCompetitionRoundFullyAI), mesmo que o clube do utilizador lá conste. Como o clube do
  // utilizador pode perfeitamente disputar a Europa AO MESMO TEMPO que a sua liga doméstica, isso
  // impediria sempre o utilizador de jogar os seus próprios jogos europeus. Por isso, tal como a
  // Taça de Portugal/Elite Cup/Copa del Rey/Supercopas, a Europa tem o seu próprio estado
  // (state.europa) e o seu próprio ciclo diário (processEuropaForCurrentDate), chamado a partir de
  // processPhaseFiveFinalsForCurrentDate() (07-playoff.js), com pausa interativa própria
  // (state.pendingEuropaSlot) exatamente no mesmo espírito de state.pendingEliteCupFase/etc.
  //
  // Simplificações assumidas nesta implementação (o estudo deixava alguns pormenores por fechar
  // "a confirmar durante a implementação" — ver secção 4, ponto 7, e a nota sobre potes/qualificação
  // não estarem completamente documentados nos excertos oficiais disponíveis):
  // - Cada prova recebe sempre um número total de vagas por época (Champions League 12, Cup 16,
  //   Trophy 11), tal como o estudo confirma e valida com o sorteio real. Para reconciliar isso
  //   com a Ronda de Qualificação (16 clubes -> vencedor sobe à Champions League, 2º/3º à Cup, 4º
  //   à Trophy) sem exceder esses totais, o D'Hondt corre com um número de vagas DIRETAS reduzido
  //   (Champions League 8, Cup 8, Trophy 7), reservando exatamente 4+8+4=16 vagas para os
  //   resultados da qualificação — o total final de cada prova continua a ser sempre 12/16/11.
  // - A 1ª edição (época 1, sem histórico) usa o sorteio real 2026-27 (potes da secção 1.1b do
  //   estudo) tal e qual para a Champions League — a Cup/Trophy/Qualificação da 1ª edição não têm
  //   dados reais equivalentes disponíveis, por isso usam o mesmo mecanismo simulado das edições
  //   seguintes, com a reputação inicial dos clubes como critério de ordenação (não há ainda
  //   classificações domésticas de uma época anterior).
  // - Fase eliminatória da Champions League simplificada a partir dos 4 primeiros de cada grupo
  //   (8 clubes): quartos/meias/final em campo neutro, decisivo (grandes penalidades se
  //   necessário) — sem o "play-in 5º-8º" do regulamento real, que o próprio estudo deixava em
  //   aberto para decidir na implementação.
  // - WSE Cup: oitavos a duas mãos (mesma mecânica de golos agregados já usada na Supercoppa
  //   Italiana), quartos a uma mão em casa de um dos dois (sorteio, sem neutralidade), meias e
  //   final em Final a Quatro, campo neutro.
  // - WSE Trophy: os 5 clubes mais fortes do lote de 11 (soma de diretos + 4º de qualificação)
  //   entram diretamente nos quartos; os 6 restantes disputam 3 eliminatórias preliminares (uma
  //   mão, campo neutro); quartos/meias/final também em campo neutro.
  // =================================================================

  const EUROPA_PAISES = ["pt","es","it","fr","de","ch","en","at"];
  const EUROPA_NUVEM_PAISES = ["fr","de","ch","en","at"];
  // Coeficiente real e exato da época 2026-27 (Appendix B, documentos oficiais WSE) — usado só
  // como ponto de partida da 1ª edição; a partir da 2ª época, o coeficiente evolui sempre a
  // partir dos resultados realmente simulados (ver europaCoefPaisAtual). A Áustria não tem
  // ranking próprio nos documentos oficiais — fica com o valor mais baixo do lote, por omissão,
  // tal como o estudo propõe.
  const EUROPA_COEF_INICIAL = { pt:1859.00, es:1270.50, it:720.00, fr:467.50, ch:140.00, de:72.00, en:9.00, at:5.00 };
  // Banda de reputação por país da "nuvem", calibrada a partir do coeficiente real face à França
  // (100%) e à banda real de reputação já usada no jogo para a 2ª/3ª Divisão portuguesa (ver
  // estudo, secção 3.1) — nunca atinge o limiar de "Candidato europeu" (75+).
  const EUROPA_REP_BANDS = { fr:[58,79], ch:[50,65], de:[42,52], en:[40,48], at:[40,45] };
  // Clubes reais por país, pesquisados nas fontes indicadas pelo utilizador (hoqueipatins.pt para
  // França/Alemanha/Suíça/Inglaterra; para a Áustria — sem página própria nesse site — na
  // Vorarlberger Rollsportverband/Rollsport Austria, confirmando um panorama competitivo real mas
  // muito reduzido, coerente com não ter coeficiente de país oficial). Cada país fica com
  // exatamente os clubes reais encontrados (as contagens diferem de país para país, ao contrário
  // da versão anterior desta prova, que forçava sempre 10 por país com nomes gerados):
  //  - França: Nationale 1 Élite 2026/27 (12 clubes) — inclui o SCRA St. Omer, que ocupava um dos
  //    lugares reais do sorteio 2026-27 da Champions League (ver europaBuildChampionsInitialEdition).
  //  - Alemanha: 1. Rollhockey-Bundesliga Herren, fase regular (7 clubes).
  //  - Suíça: NLA (Harvest National League), fase de qualificação (8 clubes na fonte — RHC Wolfurt
  //    é excluído daqui porque é um clube austríaco, ver Áustria abaixo).
  //  - Inglaterra: Premier League Men 2026/27 (10 clubes).
  //  - Áustria: sem liga nacional organizada nas fontes disponíveis — só os clubes efetivamente
  //    confirmados em atividade (RHC Dornbirn e RHC Wolfurt, os dois principais; RHC Feldkirch,
  //    clube mais recente; RHC Villach, na Caríntia, que já defrontou equipas do Vorarlberg).
  const EUROPA_NUVEM_CLUBES_REAIS = {
    fr: ["CP Roubaix","SA Mérignac","HC Dinan Quévert","Nantes ARH","SCRA St. Omer","SPRS Ploufragan","La Vendéenne RH","CS Noisy Le Grand RS","US Coutras","Poiré Roller","PA Créhen","US Villejuif"],
    de: ["RESG Walsum","SK Germania Herringen","RSC Cronenberg","IGR Remscheid","TuS Düsseldorf-Nord","SGR Darmstadt","RHC Recklinghausen"],
    ch: ["RHC Diessbach","Montreux Hockey","RSC Uttigen","RHC Wimmis","SC Thunerstern","Pully RHC","RC Biasca"],
    en: ["Herne Bay United RH&SC","Middlesbrough RHC","Soham RHC","Manchester RSC","Farnham RHC","Letchworth RHC","RHC Invicta","King's Lynn RHC","ECU RHC","Herne Bay RHC"],
    at: ["RHC Dornbirn","RHC Wolfurt","RHC Feldkirch","RHC Villach"],
  };
  // Nome real do pavilhão/recinto de cada clube da nuvem (pedido do utilizador: a página do
  // clube mostra sempre o nome do pavilhão) — pesquisado clube a clube; onde a pesquisa não
  // confirmou um nome próprio (clubes suíços/ingleses/austríacos mais pequenos, e dois franceses),
  // usa-se um nome genérico plausível em vez de inventar um nome "confirmado" que não é real.
  const EUROPA_NUVEM_PAVILHOES = {
    "CP Roubaix": ["Salle Michel Breistroff", "Roubaix"],
    "SA Mérignac": ["Salle Robert Brettes", "Mérignac"],
    "HC Dinan Quévert": ["Salle Omnisports Némée", "Dinan"],
    "Nantes ARH": ["Salle du Croissant", "Nantes"],
    "SCRA St. Omer": ["Salle des Sports du Brockus", "Saint-Omer"],
    "SPRS Ploufragan": ["Salle Glénan", "Ploufragan"],
    "La Vendéenne RH": ["Salle Omnisports", "La Roche-sur-Yon"],
    "CS Noisy Le Grand RS": ["Gymnase Les Yvris", "Noisy-le-Grand"],
    "US Coutras": ["Patinoire Milou Ducourtioux", "Coutras"],
    "Poiré Roller": ["Complexe Sportif de la Montparière", "Le Poiré-sur-Vie"],
    "PA Créhen": ["Salle Omnisports", "Créhen"],
    "US Villejuif": ["Gymnase Paul Langevin", "Villejuif"],
    "RESG Walsum": ["Sporthalle Beckersloh", "Duisburg-Walsum"],
    "SK Germania Herringen": ["Glück-Auf-Arena", "Hamm-Herringen"],
    "RSC Cronenberg": ["Alfred-Henckels-Halle", "Wuppertal-Cronenberg"],
    "IGR Remscheid": ["Sporthalle Hackenberg", "Remscheid"],
    "TuS Düsseldorf-Nord": ["Rollsporthalle TuS Nord", "Düsseldorf"],
    "SGR Darmstadt": ["Sporthalle am Orpheum", "Darmstadt"],
    "RHC Recklinghausen": ["Heinrich-Auge-Halle", "Recklinghausen"],
    "RHC Diessbach": ["Sporthalle Diessbach", "Diessbach bei Büren"],
    "Montreux Hockey": ["Patinoire de Montreux", "Montreux"],
    "RSC Uttigen": ["Sporthalle Uttigen", "Uttigen"],
    "RHC Wimmis": ["Sporthalle Wimmis", "Wimmis"],
    "SC Thunerstern": ["Sporthalle Thun", "Thun"],
    "Pully RHC": ["Salle Omnisports de Pully", "Pully"],
    "RC Biasca": ["Palestra Comunale di Biasca", "Biasca"],
    "Herne Bay United RH&SC": ["William Reid Sports Centre", "Herne Bay"],
    "Middlesbrough RHC": ["Middlesbrough Sports Village", "Middlesbrough"],
    "Soham RHC": ["Soham Leisure Centre", "Soham"],
    "Manchester RSC": ["Manchester Sports Centre", "Manchester"],
    "Farnham RHC": ["Farnham Sports Centre", "Farnham"],
    "Letchworth RHC": ["Letchworth Leisure Centre", "Letchworth Garden City"],
    "RHC Invicta": ["Kent Sports Hall", "Kent"],
    "King's Lynn RHC": ["King's Lynn Leisure Centre", "King's Lynn"],
    "ECU RHC": ["Sports Hall", "Inglaterra"],
    "Herne Bay RHC": ["William Reid Sports Centre", "Herne Bay"],
    "RHC Dornbirn": ["Sporthalle Dornbirn", "Dornbirn"],
    "RHC Wolfurt": ["Sporthalle Wolfurt", "Wolfurt"],
    "RHC Feldkirch": ["Sporthalle Feldkirch", "Feldkirch"],
    "RHC Villach": ["Sporthalle Villach", "Villach"],
  };
  // Identificador estável a partir do nome real (independente de posição/ordem na lista).
  function europaSlug(nome){
    return String(nome).normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");
  }

  // Estado base (aditivo — ver migração em 11-guardar-carregar.js). Criado aqui, a nível de
  // módulo (corre uma única vez, no arranque do jogo, antes de qualquer carreira começar) para
  // que os clubes da nuvem já existam em state.teams quando chooseClub() percorrer
  // Object.values(state.teams) para inicializar finanças/identidade tática/etc. — exatamente como
  // os clubes reais de CLUB_DEFS, só que a partir de EUROPA_NUVEM_CLUBES_REAIS em vez de vir da
  // base de dados.
  if(!state.europa || typeof state.europa!=="object") state.europa = { nuvemGerada:false, coefPais:{}, coefClube:{}, historico:[], edicao:null };
  EUROPA_PAISES.forEach(p=>{ if(!Array.isArray(state.europa.coefPais[p])) state.europa.coefPais[p]=[]; });
  if(!state.europa.coefClube || typeof state.europa.coefClube!=="object") state.europa.coefClube = {};
  if(!Array.isArray(state.europa.historico)) state.europa.historico = [];

  function ensureEuropaNuvemClubes(){
    ensureEuropaNuvemClubesBase();
    ensureNuvemReais();
  }
  function ensureEuropaNuvemClubesBase(){
    if(state.europa.nuvemGerada) return;
    EUROPA_NUVEM_PAISES.forEach(pais=>{
      const band = EUROPA_REP_BANDS[pais];
      (EUROPA_NUVEM_CLUBES_REAIS[pais]||[]).forEach(nome=>{
        const id = `europa-${pais}-${europaSlug(nome)}`;
        if(state.teams[id]) return;
        // A reputação continua a ser calibrada (não há dados reais de força relativa entre estes
        // clubes) — só a identidade (nome/país) passou a ser real, nunca gerada.
        const rng = makeSeededRng(id);
        const reputacao = seededRnd(rng, band[0], band[1]);
        const tier = reputacao>=65 ? 2 : 3;
        const pavilhaoInfo = EUROPA_NUVEM_PAVILHOES[nome] || ["Pavilhão Municipal", nome];
        state.teams[id] = {
          id, name: nome, color:"#5B6B73", tier, divisaoAtual:"europa-nuvem", zona:null, pais,
          pavilhao: pavilhaoInfo[0], cidadePavilhao: pavilhaoInfo[1],
          nuvemEuropeia:true,
          equipaPrincipalId:null, equipaBId:null,
          reputacao, reputacaoPontos:reputacao, reputacaoClube:reputacao, desempenhoRecente:50,
          capacidadeFinanceira:reputacao, massaAdepta:reputacao,
          // Correcção (auditoria externa, 2026-09-17): "Médias" não é um dos 4 valores reais de
          // condicoesTreino (Excelentes/Muito boas/Boas/Razoáveis) usados em todas as tabelas do
          // jogo (clubAppeal, recuperação, custo de treino, força de jogo) — caía sempre no
          // fallback genérico dessas tabelas, por acidente, nunca por decisão. "Boas" é o valor
          // real mais próximo de um clube "médio" (fica a meio da escala).
          condicoesTreino:"Boas",
          players: generatePlaceholderRoster(id, tier, "europa-nuvem", pais, reputacao),
          sistema:"3-1", mentalidade:"equilibrado", pressao:"media", provisional:true,
          stats: { J:0,V:0,E:0,D:0,GM:0,GS:0,Pts:0 },
          // Academia e Juvenis (Fase 1, 2026-09-22): clubes "nuvem" nunca têm academia
          // (academyEligible exclui nuvemEuropeia) — null aqui só por consistência, para o campo
          // existir sempre em todo o clube do jogo, tal como nos clubes de 02-estado.js.
          academy: null,
        };
      });
    });
    state.europa.nuvemGerada = true;
  }

  // Jogadores REAIS em clubes que não existem ou não são simulados (pedido do utilizador,
  // 2026-10-15: convocatórias reais de França e Argentina no 1.º Mundial). Vêm de
  // HM2027_DATABASE.nuvemReais (clube → jogadores) e substituem o jogador gerado mais fraco da
  // mesma posição no clube da nuvem correspondente; um clube argentino da nuvem
  // (Atlético Argentino, San Juan) é criado à parte, só com o(s) jogador(es) reais. Como são
  // jogadores de plantel normais, envelhecem, evoluem e reformam-se como os outros
  // (ver nuvemReaisSeedSeason, 08zd-nuvem-reais.js) e jogam as provas europeias pelo clube.
  // Idempotente (saves antigos também recebem estes jogadores ao carregar); quem já se reformou
  // nunca é reposto. Lucas Ordóñez é `intransferivel` — nunca pode ser contratado/emprestado.
  const NUVEM_REAIS_INTRANSFERIVEIS = ["nuvem-lucas-ordonez-19880421"];
  function ensureNuvemReais(){
    const data = (typeof window!=="undefined" && window.HM2027_DATABASE && window.HM2027_DATABASE.nuvemReais) || {};
    const retired = new Set((state.retiredPlayers||[]).map(r=>r.id));
    Object.keys(data).forEach(nome=>{
      let team = Object.values(state.teams).find(t=>t.nuvemEuropeia && t.name===nome);
      if(!team && nome==="Atlético Argentino (San Juan)"){
        const id = "nuvem-ar-atletico-argentino-san-juan";
        team = state.teams[id] = {
          id, name:nome, color:"#5B6B73", tier:3, divisaoAtual:"europa-nuvem", zona:null, pais:"ar",
          pavilhao:"Estadio Cubierto", cidadePavilhao:"San Juan",
          nuvemEuropeia:true, nuvemExtra:true, equipaPrincipalId:null, equipaBId:null,
          reputacao:45, reputacaoPontos:45, reputacaoClube:45, desempenhoRecente:50,
          capacidadeFinanceira:45, massaAdepta:45, condicoesTreino:"Boas", players:[],
          sistema:"3-1", mentalidade:"equilibrado", pressao:"media", provisional:true,
          stats:{ J:0,V:0,E:0,D:0,GM:0,GS:0,Pts:0 }, academy:null,
        };
      }
      if(!team) return;
      const usedIds = new Set(team.players.map(p=>p.id)), usedNums = new Set(team.players.map(p=>p.num));
      data[nome].forEach(raw=>{
        if(retired.has(raw.id) || team.players.some(p=>p.nuvemRealId===raw.id)) return;
        // O jogador pode já existir noutra equipa (nunca acontece — intransferível — mas protege duplicados)
        const p = normalizeImportedPlayer(raw, team.players.length, team.id, usedIds, usedNums, "europa-nuvem", team.pais);
        p.nuvemReal = true; p.nuvemRealId = raw.id;
        if(NUVEM_REAIS_INTRANSFERIVEIS.includes(raw.id)) p.intransferivel = true;
        const isPlaceholder = x => new RegExp("^"+team.id.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"-p\\d+$").test(String(x.id||""));
        const weakest = team.players.filter(x=>x.pos===p.pos && isPlaceholder(x)).sort((a,b)=>overall(a)-overall(b))[0];
        if(weakest) team.players = team.players.filter(x=>x!==weakest);
        team.players.push(p);
      });
    });
  }
  ensureEuropaNuvemClubes();

  function europaNuvemClubIds(pais){
    return Object.values(state.teams).filter(t=>t.nuvemEuropeia && t.pais===pais).map(t=>t.id).sort();
  }
  function europaCountryOf(teamId){
    const t = state.teams[teamId];
    if(t && t.nuvemEuropeia) return t.pais;
    const def = (typeof CLUB_DEFS!=="undefined" ? CLUB_DEFS : []).find(d=>d.id===teamId);
    return (def && def.pais) || "pt";
  }
  function europaClubStrength(id){
    const t = state.teams[id];
    if(!t) return 0;
    return t.reputacaoPontos!=null ? t.reputacaoPontos : normalizeClubReputation(t.reputacao, t);
  }

  // ---- Coeficientes (país e clube) — janela rolante das últimas 5 épocas ----
  function europaCoefPaisAtual(pais){
    const hist = (state.europa.coefPais && state.europa.coefPais[pais]) || [];
    if(!hist.length) return EUROPA_COEF_INICIAL[pais] || 1;
    return hist.reduce((s,v)=>s+v,0);
  }
  function europaClubCoefSum(clubId){
    const hist = (state.europa.coefClube && state.europa.coefClube[clubId]) || [];
    return hist.reduce((s,v)=>s+v,0);
  }

  // Método D'Hondt: maior quociente (coeficiente / (vagas já atribuídas + 1)) ganha cada vaga
  // sucessiva — validado nesta sessão contra o sorteio real 2026-27 (12 vagas da Champions
  // League: Portugal 5, Espanha 4, Itália 2, França 1, reproduzido com exatidão).
  function dhondtSeats(seats, coefMap){
    const result = {}; Object.keys(coefMap).forEach(k=>result[k]=0);
    for(let s=0;s<seats;s++){
      let bestKey=null, bestQuotient=-1;
      Object.keys(coefMap).forEach(k=>{
        if(!(coefMap[k]>0)) return;
        const q = coefMap[k]/(result[k]+1);
        if(q>bestQuotient){ bestQuotient=q; bestKey=k; }
      });
      if(bestKey==null) break;
      result[bestKey]++;
    }
    return result;
  }

  // Correção (bug real reportado pelo utilizador, 2026-10-04: "o sporting foi campeao e no
  // seguinte estava na wse cup e nao na champions. as regras nao estao definidas?"): a ordenação
  // doméstica usada para repartir as vagas europeias (clSeats/cupSeats/trophySeats, via D'Hondt
  // logo a seguir) vinha sempre da classificação da FASE REGULAR (standingsForCompetition), nunca
  // ajustada ao resultado do playoff — nas três ligas com playoff (Placard, OK Liga, Serie A1) o
  // campeão real da época é quem vence o playoff, não necessariamente quem termina em 1º lugar na
  // fase regular. Um campeão que termine, por exemplo, em 3º/4º lugar na fase regular entrava na
  // repartição de vagas como um mero 3º/4º classificado, podendo cair para a Cup/Trophy em vez da
  // Champions League — exactamente o caso reportado. Promove o campeão (e o vice, quando seguido
  // por essa competição) ao topo da lista antes de a repartir; a ordem da fase regular mantém-se
  // inalterada para todos os outros clubes.
  function reorderForDomesticChampion(ids, championId, runnerUpId){
    if(!Array.isArray(ids) || !ids.length) return ids;
    const promoted = [championId, runnerUpId].filter(id=>id && ids.includes(id));
    if(!promoted.length) return ids;
    return promoted.concat(ids.filter(id=>!promoted.includes(id)));
  }
  // Ordenação dos clubes elegíveis de um país — para pt/es/it usa a classificação final doméstica
  // da época anterior (capturada em completedSummary, ver 07-playoff.js/08-evolucao-jogadores.js),
  // com o campeão (e vice, quando aplicável) do playoff promovidos ao topo — ver
  // reorderForDomesticChampion, acima; sem essa classificação (1ª carreira, ou caso-limite), cai
  // para a reputação atual. Para os 5 países da nuvem, usa o coeficiente de clube acumulado (ou a
  // reputação-base, na 1ª edição).
  function europaCountryClubRanking(pais, summary){
    if(pais==="pt"){
      const ids = summary && Array.isArray(summary.placardFullStandingsIds) && summary.placardFullStandingsIds.length
        ? reorderForDomesticChampion(summary.placardFullStandingsIds.slice(), summary.placardChampionId, null)
        : (typeof CLUB_DEFS!=="undefined" ? CLUB_DEFS.filter(d=>d.divisaoAtual==="placard").map(d=>d.id) : []);
      return ids.filter(id=>state.teams[id]).sort((a,b)=> ids.indexOf(a)-ids.indexOf(b));
    }
    if(pais==="es"){
      const ids = summary && Array.isArray(summary.okLigaStandingsIds) && summary.okLigaStandingsIds.length
        ? reorderForDomesticChampion(summary.okLigaStandingsIds.slice(), summary.okLigaChampionId, summary.okLigaRunnerUpId)
        : (typeof CLUB_DEFS!=="undefined" ? CLUB_DEFS.filter(d=>d.divisaoAtual==="ok-liga").map(d=>d.id) : []);
      return ids.filter(id=>state.teams[id]);
    }
    if(pais==="it"){
      const ids = summary && Array.isArray(summary.serieA1StandingsIds) && summary.serieA1StandingsIds.length
        ? reorderForDomesticChampion(summary.serieA1StandingsIds.slice(), summary.serieA1ChampionId, summary.serieA1RunnerUpId)
        : (typeof CLUB_DEFS!=="undefined" ? CLUB_DEFS.filter(d=>d.divisaoAtual==="serie-a1").map(d=>d.id) : []);
      return ids.filter(id=>state.teams[id]);
    }
    return europaNuvemClubIds(pais).slice().sort((a,b)=> europaClubCoefSum(b)-europaClubCoefSum(a) || europaClubStrength(b)-europaClubStrength(a));
  }

  // Vagas diretas (reduzidas — ver nota de arquitetura no topo do ficheiro) + reserva para a
  // Ronda de Qualificação (16 clubes, sempre): Champions League 8 diretas + 4 via qualificação;
  // Cup 8 diretas + 8 via qualificação (2º/3º de cada grupo); Trophy 7 diretas + 4 via
  // qualificação (4º de cada grupo) — total 12/16/11, exatamente como o estudo valida.
  // Correção (bug real, encontrado ao validar ed.participantes — auditoria 2026-09-12): na 1ª
  // edição, o sorteio real da Champions League é FIXO (europaBuildChampionsInitialEdition, 12
  // clubes concretos) mas era calculado de forma totalmente independente desta alocação genérica
  // (D'Hondt sobre o ranking doméstico) — um clube podia sair do sorteio fixo da Champions E,
  // ainda assim, ser "apanhado" pela alocação genérica de Cup/Trophy/Qualificação (ex.: Porto,
  // Benfica, Bassano na Cup; Braga, Igualada HC na Trophy), acabando com jogos marcados em DUAS
  // provas europeias ao mesmo tempo. excludeIds (os 12 clubes já fixos na Champions da 1ª
  // edição) filtra o ranking de cada país antes de repartir os lugares diretos/qualificação.
  function europaComputeAllocation(summary, excludeIds){
    const skip = excludeIds || new Set();
    const coefMap = {}; EUROPA_PAISES.forEach(p=>coefMap[p]=europaCoefPaisAtual(p));
    const clSeats = dhondtSeats(8, coefMap), cupSeats = dhondtSeats(8, coefMap), trophySeats = dhondtSeats(7, coefMap);
    const ranking = {}; EUROPA_PAISES.forEach(p=>ranking[p]=europaCountryClubRanking(p, summary).filter(id=>!skip.has(id)));
    const clDirect=[], cupDirect=[], trophyDirect=[];
    const idx = {}; EUROPA_PAISES.forEach(p=>idx[p]=0);
    EUROPA_PAISES.forEach(p=>{
      const lista = ranking[p];
      const take = n => { const out=[]; while(out.length<n && idx[p]<lista.length){ out.push(lista[idx[p]]); idx[p]++; } return out; };
      take(clSeats[p]||0).forEach(id=>clDirect.push({id,pais:p}));
      take(cupSeats[p]||0).forEach(id=>cupDirect.push({id,pais:p}));
      take(trophySeats[p]||0).forEach(id=>trophyDirect.push({id,pais:p}));
    });
    // Reforço (bug real, encontrado ao testar a correção acima): excludeIds pode esgotar a lista
    // de UM país antes de este cumprir a sua própria quota (ex.: a 1ª edição remove os clubes já
    // fixos no sorteio da Champions League antes de repartir Cup/Trophy, e a Itália não tem
    // clubes reais suficientes para cobrir a Champions E a sua quota de Cup/Trophy) — sem isto,
    // Cup/Trophy acabavam com MENOS clubes do que as vagas diretas previam, quebrando o desenho
    // do quadro (nº de "byes"/emparelhamentos assume sempre os totais 8/8/7 corretos, ver
    // europaBuildTrophyFromEntrants). Completa a partir de QUALQUER país com sobra (por ordem de
    // EUROPA_PAISES, continuando os mesmos cursores idx — nunca repete um clube já atribuído),
    // só quando isto acontece; em condições normais (sem excludeIds) isto nunca tem efeito, já
    // que cada take() cumpre sempre a sua quota exatamente.
    function topUp(seatsTotal, arr){
      let need = seatsTotal - arr.length;
      for(const p of EUROPA_PAISES){
        if(need<=0) break;
        const lista = ranking[p];
        while(need>0 && idx[p]<lista.length){ arr.push({id:lista[idx[p]], pais:p}); idx[p]++; need--; }
      }
    }
    const sumSeats = o => Object.values(o).reduce((a,b)=>a+b,0);
    topUp(sumSeats(clSeats), clDirect);
    topUp(sumSeats(cupSeats), cupDirect);
    topUp(sumSeats(trophySeats), trophyDirect);
    // Pool da Ronda de Qualificação: 16 clubes, por ordem decrescente de coeficiente de país,
    // sempre dando prioridade ao país com menos vagas diretas já atribuídas (mesma regra proposta
    // no estudo, secção 3.2) — enquanto houver clubes elegíveis por sobrar em cada país.
    const totalDiretas = p => (clSeats[p]||0)+(cupSeats[p]||0)+(trophySeats[p]||0);
    const paisesOrdenados = EUROPA_PAISES.slice().sort((a,b)=> totalDiretas(a)-totalDiretas(b) || coefMap[b]-coefMap[a]);
    const qualifPool = [];
    let guard=0;
    while(qualifPool.length<16 && guard<200){
      guard++;
      let progresso=false;
      for(const p of paisesOrdenados){
        if(qualifPool.length>=16) break;
        const lista = ranking[p];
        if(idx[p]<lista.length){ qualifPool.push({id:lista[idx[p]], pais:p}); idx[p]++; progresso=true; }
      }
      if(!progresso) break;
    }
    return { coefMap, clSeats, cupSeats, trophySeats, clDirect, cupDirect, trophyDirect, qualifPool };
  }

  // ---- Ties genéricas (eliminatórias, 1 ou 2 mãos) ----
  function europaMakeTie(homeId, awayId, dates, neutral){
    const legs = dates.map((d,i)=> i===0
      ? { home:homeId, away:awayId, date:new Date(d), played:false, homeScore:0, awayScore:0, soWinner:null }
      : { home:awayId, away:homeId, date:new Date(d), played:false, homeScore:0, awayScore:0, soWinner:null });
    return { home:homeId, away:awayId, neutral:!!neutral, legs, vencedor:null };
  }
  function europaTieAggregate(tie){
    let golsHome=0, golsAway=0;
    tie.legs.forEach(leg=>{
      if(leg.home===tie.home){ golsHome+=leg.homeScore; golsAway+=leg.awayScore; }
      else { golsHome+=leg.awayScore; golsAway+=leg.homeScore; }
    });
    return { golsHome, golsAway };
  }
  function europaTieDecide(tie){
    if(!tie.legs.every(l=>l.played)) return null;
    const { golsHome, golsAway } = europaTieAggregate(tie);
    if(golsHome>golsAway) return tie.home;
    if(golsAway>golsHome) return tie.away;
    const last = tie.legs[tie.legs.length-1];
    if(last.soWinner==="home") return last.home;
    if(last.soWinner==="away") return last.away;
    return null;
  }
  // Bug real (encontrado no teste alargado desta prova): um agregado a duas mãos pode ficar
  // empatado mesmo quando NENHUMA das mãos, isoladamente, terminou empatada (ex.: 2-1 na 1ª mão,
  // 1-2 na 2ª) — nesse caso não há golo/soWinner nenhum a apontar como desempate e
  // europaTieDecide devolve null para sempre, bloqueando a eliminatória. A regra real prevê
  // grandes penalidades para desempatar o agregado nessa situação; como o motor de jogo só sabe
  // simular um jogo de cada vez, resolve-se aqui com um jogo de desempate dedicado, decisivo e em
  // campo neutro (isPlayoff força sempre um vencedor) — só o resultado de grandes penalidades é
  // aproveitado, nunca o marcador, que não conta para nada (a eliminatória já foi decidida pelo
  // agregado real das duas mãos jogadas).
  function europaResolveTieWinner(tie){
    const direto = europaTieDecide(tie);
    if(direto) return direto;
    const desempate = simulateMatchToCompletion(tie.home, tie.away, true, true, "europa-desempate");
    if(desempate.home>desempate.away) return tie.home;
    if(desempate.away>desempate.home) return tie.away;
    return desempate.soWinner==="away" ? tie.away : tie.home;
  }

  // ---- Fase de grupos (Qualificação e Champions League) — round-robin isolado, nunca escreve em
  // team.stats (esse campo é só da liga doméstica); classificação própria calculada aqui. ----
  function europaSingleLegFixtures(teamIds){
    const full = generateFixtures(shuffleArray(teamIds));
    return full.slice(0, Math.floor(full.length/2));
  }
  function europaGroupStandings(grupo){
    const tally = {};
    grupo.teamIds.forEach(id=>tally[id]={id,J:0,V:0,E:0,D:0,GM:0,GS:0,Pts:0});
    (grupo.fixtures||[]).forEach(round=>round.forEach(fx=>{
      if(!fx.played) return;
      const h=tally[fx.home], a=tally[fx.away]; if(!h||!a) return;
      h.J++; a.J++; h.GM+=fx.homeScore; h.GS+=fx.awayScore; a.GM+=fx.awayScore; a.GS+=fx.homeScore;
      if(fx.soWinner==="home"){ h.V++; h.Pts+=3; a.D++; }
      else if(fx.soWinner==="away"){ a.V++; a.Pts+=3; h.D++; }
      else if(fx.homeScore>fx.awayScore){ h.V++; h.Pts+=3; a.D++; }
      else if(fx.awayScore>fx.homeScore){ a.V++; a.Pts+=3; h.D++; }
      else { h.E++; a.E++; h.Pts++; a.Pts++; }
    }));
    return Object.values(tally).sort((x,y)=> y.Pts-x.Pts || (y.GM-y.GS)-(x.GM-x.GS) || y.GM-x.GM || x.id.localeCompare(y.id));
  }

  // ---- Datas — cada prova com o seu próprio calendário-alvo, sempre verificado contra colisões
  // com as ligas domésticas (avoidLeagueCollisionsOnDate, já generalizado em 07e-copas-nacionais.js
  // para exatamente este efeito). ----
  function europaBaseYear(season){ return 2025+season; }
  function europaQualifStartDate(season){ return new Date(europaBaseYear(season), 8, 2); }
  // Correção (pedido do utilizador, 2026-09-13): "Podes deixar a qualificação no início. Mas a
  // champions só começa em novembro e os grupos acabam em final de março" — a Ronda de
  // Qualificação mantém-se em setembro (europaQualifStartDate, acima, inalterada), mas a fase de
  // grupos da WSE Champions League passa de 30 de setembro para meados de novembro, com uma
  // cadência quinzenal (em vez de semanal — ver o parâmetro intervalDays de
  // europaAssignGroupSetDates) para que as 10 jornadas (round-robin duplo) só terminem no final
  // de março, em vez de logo em dezembro.
  function europaChampionsGroupStartDate(season){ return new Date(europaBaseYear(season), 10, 18); }
  function europaChampionsKnockoutDates(season){
    const y = europaBaseYear(season);
    // A fase de grupos só termina no final de março (ver europaChampionsGroupStartDate) — os
    // quartos/meias/final têm de vir depois disso, não antes como acontecia com o calendário
    // antigo (grupos a terminar em dezembro, quartos já em janeiro).
    // Correção (2026-10-04, pedido do utilizador: "final four taça de portugal ao mesmo tempo do
    // playoff e liga dos campeoes depois", com levantamento de 5 épocas reais em anexo) —
    // substitui a âncora anterior (último sábado de maio, decisão de 2026-09-27, tomada sem o
    // levantamento real que entretanto o utilizador fez): a fase final real da principal
    // competição europeia de hóquei em patins acontece sempre entre 4 e 15 de maio (2021/22 a
    // 2025/26, Final Four ou Final a Oito consoante a época) — nunca no fim de maio. Com a âncora
    // antiga, as meias/final da Champions caíam depois do início real do Playoff (meados de maio,
    // ver playoffStartTargetDate em 07-playoff.js), gerando a mesma colisão reportada. Ancora-se
    // agora ao 2º sábado de maio (dentro do intervalo real 4-15 de maio) — a final no domingo
    // seguinte, sempre antes do novo início do Playoff.
    const meiasDate = addDays(nextWeekday(new Date(y+1,4,1), 6), 7); // 2º sábado de maio (1º sábado + 7 dias)
    return {
      quartos: nextWeekday(new Date(y+1,3,21), 3),
      meias: meiasDate,
      final: addDays(meiasDate, 1), // domingo seguinte
    };
  }
  // Correção (verificação pedida pelo utilizador: "os jogos da WSE Cup, primeira mão aparecem
  // jogados imediatamente após o sorteio"): as datas da Cup/Trophy eram sempre um calendário fixo
  // (7/21 de outubro, etc.), calculado sem qualquer relação com a data REAL em que a Ronda de
  // Qualificação termina (esse sorteio só acontece quando o último grupo de qualificação fica
  // concluído — evento, não uma data fixa). Na prática a qualificação por vezes só termina muito
  // perto de 7 de outubro (colisões de calendário com as ligas domésticas empurram-na para a
  // frente), deixando a 1ª mão da Cup a acontecer no dia seguinte ao sorteio, ou até no mesmo dia
  // — sem qualquer antecedência real. europaApplyMinLeadTime garante que a primeira data de cada
  // calendário fica sempre pelo menos EUROPA_MIN_DRAW_LEAD_DAYS depois do sorteio; se isso empurrar
  // essa data, TODO o calendário da prova desliza pelo mesmo número de dias (mantendo os intervalos
  // internos entre fases exatamente como já estavam), reajustado ao dia da semana correto de cada
  // fase (nunca para trás).
  const EUROPA_MIN_DRAW_LEAD_DAYS = 14;
  function europaApplyMinLeadTime(dates, firstKey, ref, minDays){
    if(!ref) return dates;
    const minFirst = addDays(ref, minDays==null?EUROPA_MIN_DRAW_LEAD_DAYS:minDays);
    const shiftDays = Math.ceil((minFirst - dates[firstKey])/86400000);
    if(shiftDays<=0) return dates;
    const shifted={};
    Object.keys(dates).forEach(k=>{ shifted[k]=nextWeekday(addDays(dates[k], shiftDays), dates[k].getDay()); });
    return shifted;
  }
  // Correção (2026-09-14, pedido direto do utilizador: "a final da wse cup é no domingo meio
  // abril. oitavos em novembro"): calendário anterior tinha os oitavos em outubro e a Final a
  // Quatro (meias+final) já em janeiro do ano seguinte — passa a ter os oitavos em novembro e a
  // Final a Quatro em meados de abril, um adiamento total de cerca de 3 meses. Os quartos (mão
  // única) ficam em janeiro, a meio caminho entre as duas datas fixadas pelo utilizador.
  function europaCupDates(season, ref){
    const y = europaBaseYear(season);
    const dates = {
      oitavosLeg1: nextWeekday(new Date(y,10,4), 3),
      oitavosLeg2: nextWeekday(new Date(y,10,18), 3),
      quartos: nextWeekday(new Date(y+1,0,13), 3),
      meias: nextWeekday(new Date(y+1,3,10), 6),
      final: nextWeekday(new Date(y+1,3,11), 0),
    };
    return europaApplyMinLeadTime(dates, "oitavosLeg1", ref);
  }
  // Correção (2026-09-14, pedido direto do utilizador: "final wse trohpy meio de março. oitavos
  // inicio meio novembro"): calendário anterior tinha a eliminatória preliminar em meados de
  // outubro e a Final a Quatro (meias+final) já em início de fevereiro — passa a ter a preliminar
  // em meados de novembro e a Final a Quatro em meados de março. Os quartos (mão única) ficam em
  // dezembro, a meio caminho entre as duas datas fixadas pelo utilizador.
  function europaTrophyDates(season, ref){
    const y = europaBaseYear(season);
    const dates = {
      preliminar: nextWeekday(new Date(y,10,11), 3),
      quartos: nextWeekday(new Date(y,11,9), 3),
      meias: nextWeekday(new Date(y+1,2,13), 6),
      final: nextWeekday(new Date(y+1,2,14), 0),
    };
    return europaApplyMinLeadTime(dates, "preliminar", ref);
  }
  function europaBracketPhaseDate(compKey, fase, season){
    if(compKey==="champions") return europaChampionsKnockoutDates(season)[fase];
    if(compKey==="cup") return europaCupDates(season)[fase];
    if(compKey==="trophy") return europaTrophyDates(season)[fase];
    return state.currentDate;
  }
  // intervalDays: por omissão 7 (semanal, comportamento original — usado pela Ronda de
  // Qualificação, que continua semanal). A fase de grupos da WSE Champions League passa a chamar
  // esta função com intervalDays=14 (quinzenal), para que as suas 10 jornadas (round-robin duplo)
  // caibam entre novembro e final de março em vez de ficarem todas apinhadas até dezembro — ver
  // europaChampionsGroupStartDate.
  function europaAssignGroupSetDates(grupos, startDate, weekdayNum, intervalDays){
    intervalDays = intervalDays || 7;
    (grupos||[]).forEach(g=>{
      let d = new Date(startDate);
      g.fixtures.forEach(round=>{
        d = nextFixtureDateOutsideChristmasBreak(nextWeekday(d, weekdayNum));
        // Correção (verificação pedida pelo utilizador): a verificação de colisão corria depois
        // de a própria jornada já ter recebido a data — o percurso genérico por state.europa
        // (avoidLeagueCollisionsOnDate, generalizado em 07e-copas-nacionais.js) encontrava então
        // a PRÓPRIA jornada sentada exatamente nessa data e reagendava-a por engano, como falsa
        // colisão consigo mesma. Verifica-se sempre ANTES de atribuir a data à jornada (que nesse
        // momento ainda não tem date nenhuma, logo nunca colide consigo própria).
        // Os clubes desta jornada já são conhecidos neste momento — protege-se apenas a
        // disponibilidade real desses clubes (3.3 da auditoria externa), não o dia inteiro.
        avoidLeagueCollisionsOnDate(d, "as competições europeias", round.flatMap(fx=>[fx.home,fx.away]));
        round.date = new Date(d);
        d = addDays(d, intervalDays);
      });
    });
  }
  function europaAssignTiesCollisionCheck(ties, label){
    // Mesma correção: europaMakeTie já atribui a data a cada "mão" no momento em que a
    // eliminatória é criada — a proteção teria de excluir explicitamente essas mesmas mãos do
    // percurso genérico (que também varre state.europa), para nunca as confundir com uma colisão
    // real contra OUTRA prova.
    const excludeLegs = new Set();
    (ties||[]).forEach(tie=> tie.legs.forEach(leg=> excludeLegs.add(leg)));
    // Os dois clubes de cada eliminatória já são conhecidos neste momento — protege-se apenas a
    // disponibilidade real desses clubes (3.3 da auditoria externa), não o dia inteiro.
    (ties||[]).forEach(tie=> tie.legs.forEach(leg=> avoidLeagueCollisionsOnDate(leg.date, "a "+label, [tie.home, tie.away], 0, excludeLegs)));
  }

  const EUROPA_FASE_LABEL = { preliminar:"Eliminatória Preliminar", oitavos:"Oitavos-de-Final", quartos:"Quartos-de-Final", meias:"Meias-Finais", final:"Final", grupos:"Fase de Grupos", aguardando:"A aguardar apuramento" };
  const EUROPA_BRACKET_PHASES = { champions:["quartos","meias","final"], cup:["oitavos","quartos","meias","final"], trophy:["preliminar","quartos","meias","final"] };
  // Pontos por fase alcançada (números oficiais exatos, documento WSE "Women's/Men's Clubs
  // Competitions Points 2026" — ver estudo, secção 1.2/3.2).
  const EUROPA_POINTS = {
    champions: { vencedor:100, final:85, meias:75, quartos:60, grupo5:50, grupo6:40 },
    cup: { vencedor:40, final:15, meias:10, quartos:5, oitavos:3 },
    trophy: { vencedor:30, final:25, meias:15, quartos:10, preliminar:5 },
  };
  const EUROPA_PRIZES = {
    champions: { vencedor:50000, final:20000, meias:8000, rep:2.5, label:"WSE Champions League" },
    cup: { vencedor:25000, final:10000, meias:4000, rep:1.2, label:"WSE Cup" },
    trophy: { vencedor:15000, final:6000, meias:2500, rep:0.7, label:"WSE Trophy" },
  };

  function europaAwardPoints(ed, clubId, compKey, faseKey){
    const tabela = EUROPA_POINTS[compKey]; const pts = tabela ? (tabela[faseKey]||0) : 0;
    if(!pts || !clubId) return;
    ed.pontosEpoca[clubId] = Math.max(ed.pontosEpoca[clubId]||0, pts);
  }
  function europaAwardBracketPrizes(bracket, compKey, ed){
    const cfg = EUROPA_PRIZES[compKey];
    const campeaoTeam = state.teams[bracket.campeao], runnerUpTeam = state.teams[bracket.runnerUp];
    if(campeaoTeam){
      awardClubTitle(bracket.campeao, "europa-"+compKey, `${cfg.label} ${ed.seasonLabel}`);
      // O bónus de reputação do campeão já não é atribuído aqui isoladamente — ver
      // europaApplySeasonReputationBoost (chamada em europaCheckSeasonConcluded), que aplica um
      // ajuste proporcional à posição de TODOS os participantes, não só de quem vence.
      addFinanceMovement(campeaoTeam, "receita", "Prémio de competição", `${cfg.label} ${ed.seasonLabel} — vencedor`, cfg.vencedor, state.currentDate);
    }
    if(runnerUpTeam) addFinanceMovement(runnerUpTeam, "receita", "Prémio de competição", `${cfg.label} ${ed.seasonLabel} — finalista`, cfg.final, state.currentDate);
    (bracket.jogos.meias||[]).forEach(tie=>{
      if(!tie.vencedor) return;
      const perdedor = tie.vencedor===tie.home ? tie.away : tie.home;
      const team = state.teams[perdedor];
      if(team && cfg.meias) addFinanceMovement(team, "receita", "Prémio de competição", `${cfg.label} ${ed.seasonLabel} — meia-final`, cfg.meias, state.currentDate);
    });
  }

  // ---- Construção da edição da época ----
  function europaBuildQualificationGroups(poolIds){
    const usableCount = Math.floor(poolIds.length/4)*4;
    const usable = poolIds.slice(0, usableCount);
    const sorted = usable.slice().sort((a,b)=> europaClubStrength(b)-europaClubStrength(a));
    const groups = [[],[],[],[]];
    sorted.forEach((id,i)=>{ const block=Math.floor(i/4), pos=i%4; const g = block%2===0 ? pos : 3-pos; groups[g].push(id); });
    const nomes=["A","B","C","D"];
    const grupos = groups.map((teamIds,i)=> teamIds.length>=2 ? {
      id:"qualif-"+nomes[i], nome:"Qualificação Europeia — Grupo "+nomes[i], teamIds,
      fixtures: europaSingleLegFixtures(teamIds), currentRound:0, status:"regular",
    } : null).filter(Boolean);
    return { concluida:false, grupos };
  }
  function europaBuildChampionsGroupsFromClubIds(ids){
    const sorted = ids.slice().sort((a,b)=> europaClubCoefSum(b)-europaClubCoefSum(a) || europaClubStrength(b)-europaClubStrength(a));
    const pote1=sorted.slice(0,4), pote2=sorted.slice(4,8), pote3=sorted.slice(8,12);
    const p1=shuffleArray(pote1), p2=shuffleArray(pote2), p3=shuffleArray(pote3);
    const grupoA=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]].filter(Boolean);
    const grupoB=[p1[2],p1[3],p2[2],p2[3],p3[2],p3[3]].filter(Boolean);
    return [
      { id:"champions-a", nome:"WSE Champions League — Grupo A", teamIds:grupoA, fixtures:generateValidatedFixtures(grupoA), currentRound:0, status:"regular" },
      { id:"champions-b", nome:"WSE Champions League — Grupo B", teamIds:grupoB, fixtures:generateValidatedFixtures(grupoB), currentRound:0, status:"regular" },
    ];
  }
  // 1ª edição real (sorteio de 24 de julho de 2026, Braga — ver estudo, secção 1.1b): os 3 potes
  // reais tal e qual. O lugar francês no Pote 3 é o SCRA St. Omer — clube real da nuvem francesa
  // (França ainda não é jogável, mas o clube é real, tal como todos os outros da nuvem), nunca um
  // substituto fictício.
  function europaBuildChampionsInitialEdition(){
    const pote1=["trissino","porto","barcelos","sporting"].filter(id=>state.teams[id]);
    const pote2=["benfica","fc-barcelona","hc-liceo","cp-calafell"].filter(id=>state.teams[id]);
    const stOmerId = europaNuvemClubIds("fr").find(id=>state.teams[id] && state.teams[id].name==="SCRA St. Omer");
    const pote3=[stOmerId,"igualada-hc","braga","bassano"].filter(id=>state.teams[id]);
    const p1=shuffleArray(pote1), p2=shuffleArray(pote2), p3=shuffleArray(pote3);
    const grupoA=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]].filter(Boolean);
    const grupoB=[p1[2],p1[3],p2[2],p2[3],p3[2],p3[3]].filter(Boolean);
    return {
      id:"champions", label:"WSE Champions League", fase:"grupos", directIds:[],
      grupos:[
        { id:"champions-a", nome:"WSE Champions League — Grupo A", teamIds:grupoA, fixtures:generateValidatedFixtures(grupoA), currentRound:0, status:"regular" },
        { id:"champions-b", nome:"WSE Champions League — Grupo B", teamIds:grupoB, fixtures:generateValidatedFixtures(grupoB), currentRound:0, status:"regular" },
      ],
      jogos:{quartos:[],meias:[],final:[]}, campeao:null, runnerUp:null,
    };
  }
  function europaBuildCupFromEntrants(ids, season, ref){
    const sorted = ids.slice().sort((a,b)=>europaClubStrength(b)-europaClubStrength(a));
    const n = sorted.length, half = Math.floor(n/2);
    const dates = europaCupDates(season, ref);
    const ties=[];
    for(let i=0;i<half;i++) ties.push(europaMakeTie(sorted[i], sorted[n-1-i], [dates.oitavosLeg1, dates.oitavosLeg2], false));
    return ties;
  }
  function europaBuildTrophyFromEntrants(ids, season, ref){
    const sorted = ids.slice().sort((a,b)=>europaClubStrength(b)-europaClubStrength(a));
    const byeIds = sorted.slice(0,5);
    let restantes = sorted.slice(5);
    if(restantes.length%2===1) byeIds.push(restantes.pop());
    const dates = europaTrophyDates(season, ref);
    const ties=[];
    for(let i=0;i<restantes.length/2;i++) ties.push(europaMakeTie(restantes[i], restantes[restantes.length-1-i], [dates.preliminar], true));
    return { byeIds, ties };
  }

  function europaFinalizeQualificacao(ed){
    ed.qualificacao.concluida = true;
    const winners=[], seconds=[], thirds=[], fourths=[];
    ed.qualificacao.grupos.forEach(g=>{
      const tabela = europaGroupStandings(g);
      if(tabela[0]) winners.push(tabela[0].id);
      if(tabela[1]) seconds.push(tabela[1].id);
      if(tabela[2]) thirds.push(tabela[2].id);
      if(tabela[3]) fourths.push(tabela[3].id);
    });
    winners.forEach(id=>{ ed.participantes[id]="champions"; });
    seconds.forEach(id=>{ ed.participantes[id]="cup"; });
    thirds.forEach(id=>{ ed.participantes[id]="cup"; });
    fourths.forEach(id=>{ ed.participantes[id]="trophy"; });
    if(winners.length) pushNews(state.currentDate, `Ronda de qualificação europeia ${ed.seasonLabel} concluída — apurados para a ${competitionLinkHtml("europa-champions","WSE Champions League")}: ${winners.map(id=>teamLinkHtml(id)).join(", ")}.`, "sistema", "Europa — Qualificação concluída", {autoAdvanceStop:true});
    // Correção (verificação pedida pelo utilizador: notícia sempre que a equipa do utilizador
    // passa de fase ou sai da competição): a Ronda de Qualificação nunca tinha nenhuma notícia
    // dedicada ao clube do utilizador — só a lista coletiva de apurados para a Champions League
    // acima (que nem sequer cobre quem se apura para a Cup/Trophy, nem quem fica eliminado da
    // Europa por inteiro ao ficar fora dos 4 primeiros do seu grupo).
    const userNaQualificacao = (ed.qualificacao.grupos||[]).some(g=>g.teamIds.includes(state.userTeamId));
    if(userNaQualificacao){
      const tierUtilizador = ed.participantes[state.userTeamId];
      if(tierUtilizador==="champions"){
        pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} venceu o seu grupo da Ronda de Qualificação e apura-se para a fase de grupos da ${competitionLinkHtml("europa-champions","WSE Champions League")} ${ed.seasonLabel}.`, "sistema", `${myTeam().name} apurado para a WSE Champions League`, {autoAdvanceStop:true});
      } else if(tierUtilizador==="cup"){
        pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} termina a Ronda de Qualificação com lugar na ${competitionLinkHtml("europa-cup","WSE Cup")} ${ed.seasonLabel}.`, "sistema", `${myTeam().name} apurado para a WSE Cup`, {autoAdvanceStop:true});
      } else if(tierUtilizador==="trophy"){
        pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} termina a Ronda de Qualificação com lugar na ${competitionLinkHtml("europa-trophy","WSE Trophy")} ${ed.seasonLabel}.`, "sistema", `${myTeam().name} apurado para a WSE Trophy`, {autoAdvanceStop:true});
      } else {
        pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} foi eliminado da Ronda de Qualificação Europeia ${ed.seasonLabel} — não ficou entre os 4 primeiros do seu grupo e não vai disputar nenhuma competição europeia esta época.`, "sistema", `${myTeam().name} eliminado da Europa`, {autoAdvanceStop:true});
      }
    }
    if(ed.champions.fase==="aguardando"){
      const clIds = (ed.champions.directIds||[]).concat(winners);
      ed.champions.grupos = europaBuildChampionsGroupsFromClubIds(clIds);
      ed.champions.fase = "grupos";
      europaAssignGroupSetDates(ed.champions.grupos, europaChampionsGroupStartDate(ed.epoca), 3, 14);
      // Correção (pedido do utilizador, 2026-09-17: "nos emails dos sorteios, o sorteio deve
      // aparecer no corpo do email"): antes só avisava que o sorteio tinha acontecido, sem
      // mostrar a composição dos grupos — passa a listá-los no corpo da notícia.
      const gruposCorpo=ed.champions.grupos.map(g=>`<p style="margin:0 0 8px;"><b>${escapeHtml(g.nome)}</b><br>${g.teamIds.map(id=>teamLinkHtml(id)).join(" · ")}</p>`).join("");
      pushNews(state.currentDate, `🏆 <b>Sorteio da fase de grupos da ${competitionLinkHtml("europa-champions","WSE Champions League")} ${ed.seasonLabel} realizado:</b><br><br>${gruposCorpo}`, "sistema", "WSE Champions League — Sorteio", {autoAdvanceStop:true});
    } else {
      // 1ª edição: os 12 lugares da Champions League já estão fixos pelo sorteio real — os
      // vencedores da qualificação recebem pontos equivalentes a uma fase de grupos (não entram
      // na fase de grupos real desta 1ª edição).
      winners.forEach(id=>europaAwardPoints(ed, id, "champions", "grupo6"));
    }
    const cupIds = (ed.cup.directIds||[]).concat(seconds, thirds);
    ed.cup.jogos.oitavos = europaBuildCupFromEntrants(cupIds, ed.epoca, state.currentDate);
    ed.cup.fase = "oitavos";
    europaAssignTiesCollisionCheck(ed.cup.jogos.oitavos, ed.cup.label);
    const trophyIds = (ed.trophy.directIds||[]).concat(fourths);
    const trophyBuild = europaBuildTrophyFromEntrants(trophyIds, ed.epoca, state.currentDate);
    ed.trophy.byeIds = trophyBuild.byeIds;
    if(trophyBuild.ties.length){
      ed.trophy.jogos.preliminar = trophyBuild.ties;
      ed.trophy.fase = "preliminar";
      europaAssignTiesCollisionCheck(ed.trophy.jogos.preliminar, ed.trophy.label);
    } else {
      const dates = europaTrophyDates(ed.epoca);
      const pool = shuffleArray(trophyBuild.byeIds);
      const pairs=[]; for(let i=0;i<pool.length;i+=2) pairs.push([pool[i],pool[i+1]]);
      ed.trophy.jogos.quartos = pairs.filter(p=>p[0]&&p[1]).map(([a,b])=>europaMakeTie(a,b,[dates.quartos],true));
      ed.trophy.fase = "quartos";
      europaAssignTiesCollisionCheck(ed.trophy.jogos.quartos, ed.trophy.label);
    }
    // Correção (pedido do utilizador, 2026-09-17: "nos emails dos sorteios, o sorteio deve
    // aparecer no corpo do email"): idem — passa a listar os confrontos sorteados, não só avisar
    // que o sorteio aconteceu.
    const cupParesCorpo=ed.cup.jogos.oitavos.map(j=>`${teamLinkHtml(j.home)} vs ${teamLinkHtml(j.away)}`).join("<br>");
    const trophyJogosAtual=ed.trophy.fase==="preliminar"?ed.trophy.jogos.preliminar:ed.trophy.jogos.quartos;
    const trophyParesCorpo=(trophyJogosAtual||[]).map(j=>`${teamLinkHtml(j.home)} vs ${teamLinkHtml(j.away)}`).join("<br>");
    const trophyByesCorpo=(ed.trophy.byeIds&&ed.trophy.fase==="preliminar"&&ed.trophy.byeIds.length)?`<br><i>Com bye direto:</i> ${ed.trophy.byeIds.map(id=>teamLinkHtml(id)).join(" · ")}`:"";
    pushNews(state.currentDate, `🏆 <b>Sorteios europeus realizados:</b><br><br><b>${competitionLinkHtml("europa-cup","WSE Cup")} ${ed.seasonLabel}:</b><br>${cupParesCorpo}<br><br><b>${competitionLinkHtml("europa-trophy","WSE Trophy")} ${ed.seasonLabel}:</b><br>${trophyParesCorpo}${trophyByesCorpo}`, "sistema", "Europa — Sorteios", {autoAdvanceStop:true});
  }

  // Se, por qualquer motivo, a edição anterior ainda não tiver terminado quando é preciso
  // arrancar uma nova (proteção contra bloqueio indefinido — ver nota no topo do ficheiro),
  // resolve-se instantaneamente tudo o que faltar por IA antes de prosseguir.
  function europaForceConcludeIfPending(){
    const ed = state.europa.edicao;
    if(!ed || ed.concluida) return;
    let guard=0;
    while(!ed.concluida && guard<5000){
      state.pendingEuropaSlot=null; state.matchDayReady=false;
      const before = JSON.stringify({q:ed.qualificacao.concluida, c:ed.champions.fase, cu:ed.cup.fase, t:ed.trophy.fase});
      processEuropaForCurrentDate();
      state.pendingEuropaSlot=null; state.matchDayReady=false; state.pendingFixture=null; state.pendingProvisional=null;
      const after = JSON.stringify({q:ed.qualificacao.concluida, c:ed.champions.fase, cu:ed.cup.fase, t:ed.trophy.fase});
      guard++;
      if(before===after){
        // nada aconteceu (provavelmente à espera de uma data futura) — avança as datas pendentes
        // artificialmente para desbloquear, só neste cenário de recurso.
        let avancou=false;
        [ed.qualificacao.grupos, (ed.champions.grupos||[])].forEach(lista=>lista.forEach(g=>{
          if(g.status!=="concluida" && g.fixtures[g.currentRound] && g.fixtures[g.currentRound].date){ g.fixtures[g.currentRound].date = new Date(state.currentDate); avancou=true; }
        }));
        [ed.champions, ed.cup, ed.trophy].forEach(bracket=>{
          const ties = bracket.jogos && bracket.jogos[bracket.fase];
          (ties||[]).forEach(tie=>tie.legs.forEach(leg=>{ if(!leg.played){ leg.date=new Date(state.currentDate); avancou=true; } }));
        });
        if(!avancou) break;
      }
    }
  }

  function europaInitEdition(options){
    options = options || {};
    ensureEuropaNuvemClubes();
    europaForceConcludeIfPending();
    if(state.europa.edicao && state.europa.edicao.epoca===state.season) return;
    if(state.europa.historico.some(e=>e.epoca===state.season)) return;
    const summary = options.summary || state.pendingSeasonSummary || state.lastSeasonSummary || {};
    // 1ª edição: o sorteio da Champions League é construído JÁ AQUI (e reutilizado abaixo, nunca
    // reconstruído — reconstruir dava um sorteio diferente, com shuffleArray) para poder excluir
    // os seus 12 clubes da alocação genérica de Cup/Trophy/Qualificação (ver comentário em
    // europaComputeAllocation) — sem isto, um clube podia acabar a jogar duas provas europeias
    // ao mesmo tempo (bug real, encontrado ao validar ed.participantes — auditoria 2026-09-12).
    let championsInicial = null;
    if(options.initialEditionOverride) championsInicial = europaBuildChampionsInitialEdition();
    const excludeIds = championsInicial ? new Set(championsInicial.grupos.flatMap(g=>g.teamIds)) : null;
    const alloc = europaComputeAllocation(summary, excludeIds);
    const ed = { epoca: state.season, seasonLabel: seasonLabel(state.season), concluida:false, pontosEpoca:{}, quotas:{ cl:alloc.clSeats, cup:alloc.cupSeats, trophy:alloc.trophySeats }, participantes:{} };
    const poolIds = alloc.qualifPool.map(x=>x.id);
    ed.qualificacao = europaBuildQualificationGroups(poolIds);
    poolIds.forEach(id=>{ ed.participantes[id]="qualificacao"; });
    europaAssignGroupSetDates(ed.qualificacao.grupos, europaQualifStartDate(state.season), 3);
    if(options.initialEditionOverride){
      ed.champions = championsInicial;
      europaAssignGroupSetDates(ed.champions.grupos, europaChampionsGroupStartDate(state.season), 3, 14);
      ed.champions.grupos.forEach(g=>g.teamIds.forEach(id=>{ ed.participantes[id]="champions"; }));
    } else {
      ed.champions = { id:"champions", label:"WSE Champions League", fase:"aguardando", directIds:alloc.clDirect.map(x=>x.id), grupos:[], jogos:{quartos:[],meias:[],final:[]}, campeao:null, runnerUp:null };
      alloc.clDirect.forEach(x=>{ ed.participantes[x.id]="champions"; });
    }
    ed.cup = { id:"cup", label:"WSE Cup", fase:"aguardando", directIds:alloc.cupDirect.map(x=>x.id), jogos:{oitavos:[],quartos:[],meias:[],final:[]}, campeao:null, runnerUp:null };
    alloc.cupDirect.forEach(x=>{ ed.participantes[x.id]="cup"; });
    ed.trophy = { id:"trophy", label:"WSE Trophy", fase:"aguardando", directIds:alloc.trophyDirect.map(x=>x.id), byeIds:[], jogos:{preliminar:[],quartos:[],meias:[],final:[]}, campeao:null, runnerUp:null };
    alloc.trophyDirect.forEach(x=>{ ed.participantes[x.id]="trophy"; });
    state.europa.edicao = ed;
    const resumoQuotas = EUROPA_PAISES.filter(p=>alloc.clSeats[p]||alloc.cupSeats[p]||alloc.trophySeats[p]).map(p=>`${p.toUpperCase()}: CL ${alloc.clSeats[p]||0}/Cup ${alloc.cupSeats[p]||0}/Trophy ${alloc.trophySeats[p]||0}`).join(" · ");
    pushNews(state.currentDate, `Competições europeias ${ed.seasonLabel}: quotas diretas por país (mais a ronda de qualificação) — ${resumoQuotas}.`, "sistema", "Europa — Quotas da época");
  }

  // ---- Processamento diário ----
  function europaGroupById(id){
    const ed = state.europa && state.europa.edicao; if(!ed) return null;
    return (ed.qualificacao.grupos||[]).concat(ed.champions.grupos||[]).find(g=>g.id===id) || null;
  }
  function europaBracketById(id){
    const ed = state.europa && state.europa.edicao; if(!ed) return null;
    return ed[id] || null;
  }
  // Correção (bug real, reportado pelo utilizador): o jogo ao vivo/simulado do próprio
  // utilizador só recebia isPlayoff/neutralVenue corretos quando startLiveMatchWithLineup era
  // chamado a partir de state.pendingPlayoffSeries/pendingTacaPortugalFase/pendingSupertaca/
  // pendingEliteCupFase (ver 09-fluxo-epoca.js) — state.pendingEuropaSlot nunca constava dessa
  // lista. Isto tinha dois efeitos: (1) a Europa nunca recebia o bónus de assistência de "jogo
  // grande" (matchAttendance, opts.playoff); e mais grave, (2) como o motor só força
  // prolongamento/grandes penalidades quando ctx.isPlayoff é verdadeiro, um empate aos 90 minutos
  // do PRÓPRIO utilizador numa eliminatória europeia a uma só mão (quartos/meias/final da
  // Champions/Cup/Trophy, sempre de mão única) terminava sem desempate visível — só depois
  // "resolvido" nos bastidores por europaResolveTieWinner, sem o utilizador chegar a ver o seu
  // próprio desempate. Estas duas funções replicam, para o jogo do utilizador, exatamente a
  // mesma lógica de isPlayoff/neutralVenue já usada para as mãos IA-IA em
  // europaProcessBracketForCurrentDate (isLast leg decisivo, tie.neutral) — grupos nunca são
  // decisivos (empates contam, tal como as mãos IA-IA em europaProcessOneGroupForCurrentDate).
  function europaPendingIsPlayoff(){
    const slot = state.pendingEuropaSlot; if(!slot) return false;
    if(slot.tipo!=="mata-mata") return false;
    const bracket = europaBracketById(slot.bracketId);
    const tie = bracket && bracket.jogos[slot.fase] && bracket.jogos[slot.fase][slot.tieIdx];
    return !!tie && slot.legIdx===tie.legs.length-1;
  }
  function europaPendingIsNeutral(){
    const slot = state.pendingEuropaSlot; if(!slot) return false;
    if(slot.tipo!=="mata-mata") return false;
    const bracket = europaBracketById(slot.bracketId);
    const tie = bracket && bracket.jogos[slot.fase] && bracket.jogos[slot.fase][slot.tieIdx];
    return !!tie && !!tie.neutral;
  }
  // Ponte para o mercado de transferências (auditoria pedida pelo utilizador, 2026-09-12):
  // competitionPrestigeForTeam/clubAppeal (04-financas.js) só olhavam para state.competitions —
  // um clube que só joga a "nuvem" europeia nunca lá entra, e mesmo um clube jogável
  // (Portugal/Espanha/Itália) que se qualifica para a Champions League via Europa não via essa
  // qualificação refletida na sua atratividade de mercado. Escala pensada para ficar
  // acima/à volta/abaixo do Placard (90): Champions acima, Cup próxima, Trophy e Qualificação
  // abaixo — sempre o valor mais alto do NÍVEL MAIS ELEVADO atingido essa época
  // (ed.participantes guarda só esse nível mais alto, nunca é rebaixado dentro da mesma época).
  const EUROPA_COMPETITION_PRESTIGE = { champions:95, cup:80, trophy:68, qualificacao:60 };
  function europaCompetitionPrestigeForTeam(teamId){
    const ed = state.europa && state.europa.edicao;
    if(!ed || !ed.participantes) return null;
    const tier = ed.participantes[teamId];
    return tier ? (EUROPA_COMPETITION_PRESTIGE[tier]||null) : null;
  }
  function europaProcessOneGroupForCurrentDate(grupo){
    if(!grupo || grupo.status==="concluida") return false;
    if(grupo.currentRound>=grupo.fixtures.length){ grupo.status="concluida"; return false; }
    const round = grupo.fixtures[grupo.currentRound];
    if(!round.date || round.date.getTime() > state.currentDate.getTime()) return false;
    const myFixture = round.find(fx=>fx.home===state.userTeamId || fx.away===state.userTeamId);
    round.forEach(fx=>{
      if(fx===myFixture || fx.played) return;
      const res = simulateMatchToCompletion(fx.home, fx.away, false, false, grupo.id);
      fx.played=true; fx.homeScore=res.home; fx.awayScore=res.away; fx.soWinner=res.soWinner||null;
    });
    if(myFixture && !myFixture.played){
      state.pendingEuropaSlot = { tipo:"grupo", grupoId:grupo.id, roundIdx:grupo.currentRound };
      const oppId = myFixture.home===state.userTeamId ? myFixture.away : myFixture.home;
      state.pendingProvisional = { mine: ensureMinimumSquad(myTeam()), opp: ensureMinimumSquad(state.teams[oppId]) };
      state.pendingFixture = myFixture;
      state.pendingSuspensionServing = { home:getSuspendedIds(myFixture.home), away:getSuspendedIds(myFixture.away) };
      generatePreGameReport(myFixture, `${grupo.nome} — Jornada ${grupo.currentRound+1} de ${grupo.fixtures.length}`, null);
      state.matchDayReady = true;
      return true;
    }
    grupo.currentRound++;
    if(grupo.currentRound>=grupo.fixtures.length) grupo.status="concluida";
    return true;
  }
  function europaProcessGroupSetForCurrentDate(grupos){
    let any=false;
    for(const grupo of (grupos||[])){
      if(state.matchDayReady) return any;
      let progresso=true;
      while(progresso && !state.matchDayReady && grupo.status!=="concluida"){
        progresso = europaProcessOneGroupForCurrentDate(grupo);
        any = any || progresso;
      }
    }
    return any;
  }
  function europaRecordGroupResult(grupoId, roundIdx, hs, as, soWinner, attendance){
    const grupo = europaGroupById(grupoId);
    const round = grupo && grupo.fixtures[roundIdx];
    const fx = round && round.find(f=>f.home===state.userTeamId || f.away===state.userTeamId);
    if(!fx || fx.played) return;
    fx.played=true; fx.homeScore=hs; fx.awayScore=as; fx.soWinner=soWinner||null;
    // Pedido do utilizador (2026-09-12): os jogos europeus do próprio utilizador passam a ter
    // impacto financeiro real — bilheteira em casa (com o "ambiente europeu" já refletido em
    // matchAttendance via opts.europa), custo de organização e deslocação, esta última muito mais
    // alta quando os dois clubes são de países diferentes (opts.internacional — ver
    // processMatchFinances/EUROPA_CUSTO_DESLOCACAO_INTERNACIONAL em 04-financas.js). A fase de
    // grupos é sempre a duas mãos reais (nunca campo neutro), por isso processa-se sempre.
    // attendance (opcional): quando o jogo foi ao vivo, o chamador passa ctx.attendance (o valor
    // único já mostrado ao utilizador durante a partida) — ver processMatchFinances.
    processMatchFinances(fx.home, fx.away, state.currentDate, { europa:true, internacional: europaCountryOf(fx.home)!==europaCountryOf(fx.away), attendance });
  }

  function europaAdvanceBracketPhase(bracket){
    const compKey = bracket.id;
    const phases = EUROPA_BRACKET_PHASES[compKey];
    const curIdx = phases.indexOf(bracket.fase);
    const ties = bracket.jogos[bracket.fase]||[];
    const ed = state.europa.edicao;
    const winners=[];
    ties.forEach(tie=>{
      const vencedor = europaResolveTieWinner(tie);
      if(!vencedor){ console.error("Europa: eliminatória terminou sem vencedor definido.", bracket.id, bracket.fase, tie); return; }
      const perdedor = vencedor===tie.home ? tie.away : tie.home;
      tie.vencedor = vencedor;
      winners.push(vencedor);
      europaAwardPoints(ed, perdedor, compKey, bracket.fase);
      const agr = europaTieAggregate(tie);
      // Correção (pedido do utilizador, 2026-09-17: "não quero notícias individuais de
      // resultados ... WSE ou outra competição"): resultado entre dois clubes de IA não
      // interessa — só publica quando um dos dois é o próprio clube do utilizador (as notícias
      // dedicadas de "passa"/"eliminado", logo a seguir, já cobrem esse caso).
      if(vencedor===state.userTeamId || perdedor===state.userTeamId){
        pushNews(state.currentDate, `${teamLinkHtml(vencedor)} elimina ${teamLinkHtml(perdedor)} (${agr.golsHome}-${agr.golsAway}) — ${competitionLinkHtml("europa-"+bracket.id, bracket.label)}, ${EUROPA_FASE_LABEL[bracket.fase]}.`, "jogo", `${bracket.label} — Resultado`);
      }
      // Correção (verificação pedida pelo utilizador: notícia sempre que a equipa do utilizador
      // passa de fase ou sai da competição): a mensagem acima já nomeia sempre os dois clubes
      // reais, mas nunca destacava explicitamente o próprio clube do utilizador — mesmo padrão já
      // usado na Taça de Portugal/Copa del Rey/Coppa Italia/Supercopa de España. A final (última
      // fase) não gera aqui a mensagem de "passa de fase" — é coberta pela notícia de campeão,
      // logo a seguir, tal como acontece nas restantes competições.
      if(vencedor===state.userTeamId && bracket.fase!==phases[phases.length-1]){
        pushNews(state.currentDate, `${teamLinkHtml(vencedor)} passa a fase seguinte da ${competitionLinkHtml("europa-"+bracket.id, bracket.label)} ${ed.seasonLabel} (${EUROPA_FASE_LABEL[bracket.fase]}), após eliminar ${teamLinkHtml(perdedor)} por ${agr.golsHome}-${agr.golsAway} no agregado.`, "sistema", `${myTeam().name} avança na ${bracket.label}`, {autoAdvanceStop:true});
      } else if(perdedor===state.userTeamId){
        pushNews(state.currentDate, `${teamLinkHtml(perdedor)} foi eliminado da ${competitionLinkHtml("europa-"+bracket.id, bracket.label)} ${ed.seasonLabel} — fase: ${EUROPA_FASE_LABEL[bracket.fase]} — após perder com ${teamLinkHtml(vencedor)} por ${agr.golsHome}-${agr.golsAway} no agregado.`, "sistema", `${myTeam().name} eliminado da ${bracket.label}`, {autoAdvanceStop:true});
      }
    });
    if(curIdx===phases.length-1){
      const campeao = winners[0], final = ties[0];
      if(!final || !campeao) return;
      const runnerUp = campeao===final.home ? final.away : final.home;
      bracket.campeao=campeao; bracket.runnerUp=runnerUp; bracket.fase="concluida";
      europaAwardPoints(ed, campeao, compKey, "vencedor");
      europaAwardPoints(ed, runnerUp, compKey, "final");
      europaAwardBracketPrizes(bracket, compKey, ed);
      pushNews(state.currentDate, `🏆 ${teamLinkHtml(campeao)} venceu a ${competitionLinkHtml("europa-"+bracket.id, bracket.label)} ${ed.seasonLabel}!`, "sistema", `${bracket.label} — Campeão`, {autoAdvanceStop:true});
      return;
    }
    const nextFase = phases[curIdx+1];
    let nextEntrants;
    if(compKey==="trophy" && bracket.fase==="preliminar") nextEntrants = (bracket.byeIds||[]).concat(shuffleArray(winners));
    else nextEntrants = shuffleArray(winners);
    const dataFase = europaBracketPhaseDate(compKey, nextFase, ed.epoca);
    const neutral = !(compKey==="cup" && nextFase==="quartos");
    const pairs=[]; for(let i=0;i<nextEntrants.length;i+=2) pairs.push([nextEntrants[i],nextEntrants[i+1]]);
    bracket.jogos[nextFase] = pairs.filter(p=>p[0]&&p[1]).map(([a,b])=> europaMakeTie(a,b,[dataFase], neutral));
    bracket.fase = nextFase;
    europaAssignTiesCollisionCheck(bracket.jogos[nextFase], bracket.label);
    // Correção (verificação pedida pelo utilizador: "notícia sempre que há final mesmo que não
    // seja do utilizador"): ao contrário da Taça de Portugal/Copa del Rey/Coppa Italia/Elite
    // Cup/domestic playoff, as competições europeias nunca tinham uma notícia dedicada a anunciar
    // a Final definida — só o resultado genérico da meia-final (que já nomeia o vencedor, mas não
    // destaca a final como acontecimento próprio). Sempre que só resta um jogo (a final), publica-
    // se a mesma mensagem que as restantes competições já têm.
    if(nextFase==="final" && bracket.jogos.final.length===1){
      const finalTie = bracket.jogos.final[0];
      pushNews(state.currentDate, `Final da ${competitionLinkHtml("europa-"+bracket.id, bracket.label)} ${ed.seasonLabel} definida: ${teamLinkHtml(finalTie.home)} vs ${teamLinkHtml(finalTie.away)}.`, "sistema", `${bracket.label} — Final`, {autoAdvanceStop:true});
    }
  }
  function europaProcessBracketForCurrentDate(bracket){
    if(!bracket || bracket.fase==="concluida" || bracket.fase==="aguardando") return false;
    const ties = bracket.jogos[bracket.fase]||[];
    if(!ties.length) return false;
    let any=false;
    for(let tIdx=0; tIdx<ties.length; tIdx++){
      if(state.matchDayReady) return any;
      const tie = ties[tIdx];
      let leg;
      while((leg = tie.legs.find(l=>!l.played))){
        if(!leg.date || leg.date.getTime() > state.currentDate.getTime()) break;
        const isLast = tie.legs[tie.legs.length-1]===leg;
        const involvesUser = leg.home===state.userTeamId || leg.away===state.userTeamId;
        if(!involvesUser){
          const res = simulateMatchToCompletion(leg.home, leg.away, isLast, tie.neutral, bracket.id);
          leg.played=true; leg.homeScore=res.home; leg.awayScore=res.away; leg.soWinner=res.soWinner||null;
          any=true;
          continue;
        }
        const legIdx = tie.legs.indexOf(leg);
        state.pendingEuropaSlot = { tipo:"mata-mata", bracketId:bracket.id, fase:bracket.fase, tieIdx:tIdx, legIdx };
        const oppId = leg.home===state.userTeamId ? leg.away : leg.home;
        state.pendingProvisional = { mine: ensureMinimumSquad(myTeam()), opp: ensureMinimumSquad(state.teams[oppId]) };
        state.pendingFixture = leg;
        state.pendingSuspensionServing = { home:getSuspendedIds(leg.home), away:getSuspendedIds(leg.away) };
        const legTxt = tie.legs.length>1 ? (legIdx===0?" — 1ª mão":" — 2ª mão") : "";
        generatePreGameReport(leg, `${bracket.label} — ${EUROPA_FASE_LABEL[bracket.fase]}${legTxt}`, null);
        state.matchDayReady = true;
        return true;
      }
    }
    // Nota (ver europaResolveTieWinner acima): já não se exige aqui que europaTieDecide dê um
    // vencedor direto para todas as eliminatórias — só que todas as mãos estejam jogadas; um
    // agregado empatado sem golo de desempate é sempre resolvido dentro de
    // europaAdvanceBracketPhase (grandes penalidades dedicadas), nunca fica bloqueado.
    if(ties.every(t=>t.legs.every(l=>l.played))){ europaAdvanceBracketPhase(bracket); any=true; }
    return any;
  }
  function europaRecordTieLegResult(bracketId, fase, tieIdx, legIdx, hs, as, soWinner, attendance){
    const bracket = europaBracketById(bracketId);
    const tie = bracket && bracket.jogos[fase] && bracket.jogos[fase][tieIdx];
    const leg = tie && tie.legs[legIdx];
    if(!leg || leg.played) return;
    leg.played=true; leg.homeScore=hs; leg.awayScore=as; leg.soWinner=soWinner||null;
    // Só há bilheteira/custo de organização/deslocação reais quando o jogo NÃO é em campo neutro
    // (tie.neutral): nas fases neutras (grosso da Champions League e da Trophy, "Final a Quatro"
    // da Cup) nenhum dos dois clubes está realmente "em casa", por isso não se simula receita nem
    // custo de deslocação para nenhum dos dois lados. legIdx===tie.legs.length-1 (última mão) é a
    // mesma condição de "jogo decisivo" já usada em europaPendingIsPlayoff — dá o bónus de
    // assistência de "jogo grande" ao mesmo jogo que já força prolongamento/grandes penalidades.
    // attendance (opcional): quando o jogo foi ao vivo, o chamador passa ctx.attendance (o valor
    // único já mostrado ao utilizador durante a partida) — ver processMatchFinances.
    if(!tie.neutral){
      const isPlayoff = legIdx===tie.legs.length-1;
      processMatchFinances(leg.home, leg.away, state.currentDate, { europa:true, playoff:isPlayoff, internacional: europaCountryOf(leg.home)!==europaCountryOf(leg.away), attendance });
    }
    // Correção (pedido do utilizador, 2026-09-17: "não quero notícias individuais de resultados
    // ... WSE ou outra competição"): resultado de 1ª mão entre dois clubes de IA não interessa —
    // só publica quando um dos dois é o próprio clube do utilizador.
    if(tie.legs.length>1 && legIdx===0 && (leg.home===state.userTeamId || leg.away===state.userTeamId)){
      pushNews(state.currentDate, `${competitionLinkHtml("europa-"+bracket.id, bracket.label)} — 1ª mão: ${teamLinkHtml(leg.home)} ${hs}-${as} ${teamLinkHtml(leg.away)}.`, "jogo", `${bracket.label} — 1ª mão`);
    }
  }

  function europaStartChampionsKnockout(ed){
    const bracket = ed.champions;
    const tabelas = bracket.grupos.map(g=>europaGroupStandings(g));
    // Correção (verificação pedida pelo utilizador: notícia sempre que a equipa do utilizador
    // passa de fase ou sai da competição): um clube 5º/6º do seu grupo fica eliminado da WSE
    // Champions League por inteiro (só recebe pontos de reputação/coeficiente, sem mais nenhuma
    // prova europeia a seguir) e isso nunca gerava nenhuma notícia — nem sequer para o utilizador.
    tabelas.forEach(tabela=>tabela.forEach((row,pos)=>{
      if(pos>=4){
        europaAwardPoints(ed, row.id, "champions", pos===4?"grupo5":"grupo6");
        if(row.id===state.userTeamId){
          pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} foi eliminado da ${competitionLinkHtml("europa-champions","WSE Champions League")} ${ed.seasonLabel} na fase de grupos (${pos+1}º lugar do grupo).`, "sistema", `${myTeam().name} eliminado da WSE Champions League`, {autoAdvanceStop:true});
        }
      }
    }));
    const [tabelaA, tabelaB] = tabelas;
    if(!tabelaA || !tabelaB || tabelaA.length<4 || tabelaB.length<4) return;
    const seeds = [tabelaA[0].id, tabelaB[0].id, tabelaA[1].id, tabelaB[1].id, tabelaA[2].id, tabelaB[2].id, tabelaA[3].id, tabelaB[3].id];
    const pairsIdx = [[0,7],[1,6],[2,5],[3,4]];
    const dataQuartos = europaChampionsKnockoutDates(ed.epoca).quartos;
    bracket.jogos.quartos = pairsIdx.map(([i,j])=> europaMakeTie(seeds[i], seeds[j], [dataQuartos], true));
    bracket.fase = "quartos";
    europaAssignTiesCollisionCheck(bracket.jogos.quartos, bracket.label);
    pushNews(state.currentDate, `Apurados os 8 finalistas da ${competitionLinkHtml("europa-champions","WSE Champions League")} ${ed.seasonLabel} — quartos-de-final sorteados.`, "sistema", "WSE Champions League — Quartos-de-Final", {autoAdvanceStop:true});
    if(seeds.includes(state.userTeamId)){
      pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} termina a fase de grupos da ${competitionLinkHtml("europa-champions","WSE Champions League")} ${ed.seasonLabel} apurado para os quartos-de-final.`, "sistema", `${myTeam().name} apurado para os quartos-de-final`, {autoAdvanceStop:true});
    }
  }

  // Pedido do utilizador (2026-09-12): "as posições nas competições europeias têm de dar mais
  // reputação e apelo aos clubes" — substitui o bónus de reputação que só existia para o campeão
  // de cada prova (EUROPA_PRIZES[...].rep, agora sem uso) por um ajuste proporcional à posição
  // real de CADA clube participante, usando o mesmo sinal (ed.pontosEpoca) já calculado para o
  // coeficiente de país/clube — ninguém precisa de uma segunda tabela de valores. A divisão por
  // 40 mantém a mesma ordem de grandeza do bónus antigo (campeão da Champions: 100/40=2,5;
  // campeão da Cup: 40/40=1,0; campeão da Trophy: 30/40=0,75 — muito próximo dos 2.5/1.2/0.7
  // anteriores), mas agora todos os participantes recebem algo proporcional ao nível mais longe
  // que chegaram (grupo, quartos, final, etc.), nunca só quem vence. Clubes da "nuvem" ficam de
  // fora (nunca evoluem, decisão já tomada explicitamente com o utilizador).
  function europaApplySeasonReputationBoost(ed){
    Object.keys(ed.pontosEpoca).forEach(clubId=>{
      const team = state.teams[clubId];
      if(!team || team.nuvemEuropeia) return;
      const pts = ed.pontosEpoca[clubId];
      if(!pts) return;
      const delta = pts/40;
      team.reputacaoPontos = clamp((team.reputacaoPontos!=null?team.reputacaoPontos:normalizeClubReputation(team.reputacao,team))+delta, 5, 99);
      team.reputacao = reputationFromPoints(team.reputacaoPontos);
    });
  }
  function europaCheckSeasonConcluded(ed){
    if(!ed || ed.concluida) return;
    const champDone = ed.champions.fase==="concluida";
    const cupDone = ed.cup.fase==="concluida";
    const trophyDone = ed.trophy.fase==="concluida";
    if(!(ed.qualificacao.concluida && champDone && cupDone && trophyDone)) return;
    ed.concluida = true;
    europaApplySeasonReputationBoost(ed);
    const porPais = {};
    Object.keys(ed.pontosEpoca).forEach(clubId=>{
      const pais = europaCountryOf(clubId);
      porPais[pais] = (porPais[pais]||0) + ed.pontosEpoca[clubId];
      if(!Array.isArray(state.europa.coefClube[clubId])) state.europa.coefClube[clubId]=[];
      state.europa.coefClube[clubId].push(ed.pontosEpoca[clubId]);
      if(state.europa.coefClube[clubId].length>5) state.europa.coefClube[clubId].shift();
    });
    EUROPA_PAISES.forEach(p=>{
      state.europa.coefPais[p].push(porPais[p]||0);
      if(state.europa.coefPais[p].length>5) state.europa.coefPais[p].shift();
    });
    state.europa.historico.push({ epoca:ed.epoca, seasonLabel:ed.seasonLabel, campeaoChampions:ed.champions.campeao, campeaoCup:ed.cup.campeao, campeaoTrophy:ed.trophy.campeao });
    pushNews(state.currentDate, `Época europeia ${ed.seasonLabel} encerrada — coeficientes de país e de clube atualizados para a próxima edição.`, "sistema", "Europa — Fim de época");
  }

  function processEuropaForCurrentDate(){
    const ed = state.europa && state.europa.edicao;
    if(!ed || ed.concluida) return false;
    let any=false;
    any = europaProcessGroupSetForCurrentDate(ed.qualificacao.grupos) || any;
    if(state.matchDayReady) return any;
    if(!ed.qualificacao.concluida && ed.qualificacao.grupos.length && ed.qualificacao.grupos.every(g=>g.status==="concluida")) europaFinalizeQualificacao(ed);
    if(ed.champions.grupos && ed.champions.grupos.length){
      any = europaProcessGroupSetForCurrentDate(ed.champions.grupos) || any;
      if(state.matchDayReady) return any;
      if(ed.champions.fase==="grupos" && ed.champions.grupos.every(g=>g.status==="concluida")) europaStartChampionsKnockout(ed);
    }
    any = europaProcessBracketForCurrentDate(ed.champions) || any;
    if(state.matchDayReady) return any;
    any = europaProcessBracketForCurrentDate(ed.cup) || any;
    if(state.matchDayReady) return any;
    any = europaProcessBracketForCurrentDate(ed.trophy) || any;
    if(state.matchDayReady) return any;
    europaCheckSeasonConcluded(ed);
    return any;
  }

  // ---- Serialização (11-guardar-carregar.js) ----
  function europaSerializeLeg(l){ return { ...l, date: l.date ? new Date(l.date).toISOString() : null }; }
  function europaDeserializeLeg(l){ return { ...l, date: l.date ? new Date(l.date) : null }; }
  function europaSerializeTie(t){ return { ...t, legs: (t.legs||[]).map(europaSerializeLeg) }; }
  function europaDeserializeTie(t){ return { ...t, legs: (t.legs||[]).map(europaDeserializeLeg) }; }
  function europaSerializeGroup(g){ return { ...g, fixtures: serializeCompetitionFixtures(g.fixtures) }; }
  function europaDeserializeGroup(g){ return { ...g, fixtures: deserializeCompetitionFixtures(g.fixtures) }; }
  function europaSerializeBracket(b){
    const jogos={}; Object.keys(b.jogos||{}).forEach(fase=>{ jogos[fase]=(b.jogos[fase]||[]).map(europaSerializeTie); });
    return { ...b, jogos, grupos: b.grupos ? b.grupos.map(europaSerializeGroup) : b.grupos };
  }
  function europaDeserializeBracket(b){
    if(!b) return b;
    const jogos={}; Object.keys(b.jogos||{}).forEach(fase=>{ jogos[fase]=(b.jogos[fase]||[]).map(europaDeserializeTie); });
    return { ...b, jogos, grupos: b.grupos ? b.grupos.map(europaDeserializeGroup) : b.grupos };
  }
  function europaSerializeEdicao(ed){
    if(!ed) return null;
    return {
      ...ed,
      qualificacao: { concluida: ed.qualificacao.concluida, grupos: (ed.qualificacao.grupos||[]).map(europaSerializeGroup) },
      champions: europaSerializeBracket(ed.champions), cup: europaSerializeBracket(ed.cup), trophy: europaSerializeBracket(ed.trophy),
    };
  }
  function europaDeserializeEdicao(ed){
    if(!ed) return null;
    return {
      ...ed,
      qualificacao: { concluida: !!(ed.qualificacao&&ed.qualificacao.concluida), grupos: (ed.qualificacao&&ed.qualificacao.grupos||[]).map(europaDeserializeGroup) },
      champions: europaDeserializeBracket(ed.champions), cup: europaDeserializeBracket(ed.cup), trophy: europaDeserializeBracket(ed.trophy),
    };
  }
