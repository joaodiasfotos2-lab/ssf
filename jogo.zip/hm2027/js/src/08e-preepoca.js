// Pré-época: estágio e jogos de preparação (2026-10-08, pedido do utilizador: ideia 3 da lista de
// novas ideias). Decisões de desenho confirmadas por ele: os amigáveis são datas REAIS do
// calendário, jogados como os outros jogos (convocatória, ao vivo ou simulado); efeitos em
// entrosamento táctico, coesão do balneário, condição física e risco de lesão; SÓ custos, sem
// qualquer receita.
//
// A pré-época é a janela que vai do arranque da época (1 de Setembro, ver seasonStartDate) até ao
// primeiro jogo oficial do clube do utilizador (Elite Cup, Supertaça, Taça ou 1.ª jornada). O
// plano vive em state.preSeason:
//   { epoca, aberta, criadaEm, estagio, amigaveis[] }
//   estagio    null ou { tipo:"refeicoes"|"curto"|"longo", inicio, dias, diaAtual, ultimoDia, terminado, custo }
//              — o estágio ocupa os dias seguintes ao da escolha, um dia de cada vez, com efeitos
//              diários (processPreSeasonForCurrentDate, chamado todos os dias a partir de
//              09-fluxo-epoca.js)
//   amigaveis  [{ id, date, home, away, oppId, casa, played, cancelled, homeScore, awayScore,
//                 custo }] — máximo 4; datas guardadas em ISO (save/load sem conversões)
//
// Os jogos de preparação NÃO contam para nada oficial: nem classificações, nem estatísticas de
// época, nem cartões/suspensões, nem prémios (ver ctx.isFriendly em finalizePlayerStats). Têm o
// efeito real no físico (condição, lesões) porque o motor é o mesmo.

const PRESEASON_MAX_AMIGAVEIS = 4;
const PRESEASON_ESTAGIOS = {
  curto: { label: "Estágio curto", dias: 5, refeicoesDia: 2, hotel: true, famDia: 0.7, condDia: 1.5, riscoDia: 0.0035, coesaoDia: 0.5 },
  // 0.2.20 — estágio "sem dormidas": só treinos e refeições em comum, cada um dorme em casa. Muito mais barato
  // (a opção realista nos escalões inferiores) e com efeitos mais modestos e menos risco.
  refeicoes: { label: "Estágio sem dormidas", dias: 5, refeicoesDia: 1, hotel: false, famDia: 0.45, condDia: 0.8, riscoDia: 0.002, coesaoDia: 0.3 },
  longo: { label: "Estágio longo", dias: 10, refeicoesDia: 2, hotel: true, famDia: 0.9, condDia: 2.5, riscoDia: 0.005, coesaoDia: 0.5 },
};

function preSeasonCurrent() {
  let ps = state.preSeason;
  if (ps && ps.epoca === state.season) return ps;
  // Saves anteriores à pré-época (ou carregados a meio da janela) não têm plano: cria-se aqui,
  // sem efeitos colaterais, enquanto a 1.ª jornada da liga ainda não chegou.
  if (state.userTeamId && !state.seasonOver && !state.playoffActive && state.currentRound === 0 &&
      state.fixtures && state.fixtures[0] && state.currentDate < new Date(state.fixtures[0].date)) {
    initPreSeasonPlan();
    ps = state.preSeason;
    return ps && ps.epoca === state.season ? ps : null;
  }
  return null;
}
function initPreSeasonPlan() {
  const team = typeof myTeam === "function" ? myTeam() : null;
  state.preSeason = team ? { epoca: state.season, aberta: true, criadaEm: isoDate(state.currentDate), estagio: null, amigaveis: [] } : null;
}

// Datas dos jogos oficiais já conhecidos do clube do utilizador que não são da liga (Elite Cup,
// Supertaça, Taça, Europa…): um amigável nunca pode cair nesses dias.
function preSeasonOfficialDates() {
  const dates = [];
  const push = d => { if (d) { const x = new Date(d); if (!isNaN(x)) dates.push(x); } };
  try { if (typeof otherCompetitionsScheduleRows === "function") otherCompetitionsScheduleRows().forEach(r => { if (!r.played) push(r.date); }); } catch (e) {}
  try { const sup = typeof supertacaMyFixtureForCurrentDate === "function" ? supertacaMyFixtureForCurrentDate() : null; if (sup) push(sup.date); } catch (e) {}
  try { const taca = typeof tacaMyTieForCurrentDate === "function" ? tacaMyTieForCurrentDate() : null; if (taca) push(taca.date); } catch (e) {}
  return dates;
}
// Primeiro jogo da liga (a pré-época acaba na véspera) — enquanto a 1.ª jornada não chegou.
function preSeasonFirstOfficialDate() {
  if (state.currentRound !== 0 || !state.fixtures || !state.fixtures[0]) return null;
  const d = new Date(state.fixtures[0].date);
  return isNaN(d) ? null : d;
}
// Último dia em que ainda se pode jogar um amigável (véspera da 1.ª jornada da liga).
function preSeasonWindowEnd() {
  const first = preSeasonFirstOfficialDate();
  return first ? addDays(first, -1) : null;
}
function preSeasonStageDates(ps) {
  const e = ps && ps.estagio;
  if (!e || e.terminado) return [];
  const out = [];
  for (let i = 1; i <= e.dias; i++) out.push(isoDate(addDays(new Date(e.inicio), i)));
  return out;
}
function preSeasonActiveFriendlies(ps) {
  return (ps ? ps.amigaveis : []).filter(g => !g.cancelled);
}

// 0.2.20 — custos de pré-época escalam com a divisão (os mínimos fixos eram os do Placard: na 3.ª Divisão,
// "cada um leva o seu carro"). Usa o mesmo multiplicador dos custos de funcionamento por divisão.
function preSeasonDivMult(team) {
  const m = typeof DIVISION_OPERATING_COST_MULT !== "undefined" ? DIVISION_OPERATING_COST_MULT[team && team.divisaoAtual] : null;
  return m == null ? 1 : m;
}
// 0.2.22 — custo do estágio por pessoa e por dia (pedido do utilizador): refeição 5 € (sem dormidas: só o
// almoço; com dormidas: almoço + jantar) e 50 € de hotel por noite; contam os jogadores do plantel + 3 de staff.
// 0.2.23 — os preços de base (refeição 5 €, hotel 50 €/noite, deslocação 300 €) são os de um clube da 3.ª Divisão;
// escalam com o escalão do clube (hotéis e refeições mais caros nas divisões de topo).
const PRESEASON_STAFF = 3, PRESEASON_REFEICAO = 5, PRESEASON_HOTEL = 50, PRESEASON_DESLOCACAO = 300;
const PRESEASON_PRECO_ESCALAO = { "3div": 1, "2div": 1.4, "ok-liga-plata": 1.4, "placard": 2, "ok-liga": 2, "serie-a1": 2 };
function preSeasonPrecos(team) {
  const f = PRESEASON_PRECO_ESCALAO[team && team.divisaoAtual] || 1.4;
  return { fator: f, refeicao: Math.round(PRESEASON_REFEICAO * f), hotel: Math.round(PRESEASON_HOTEL * f), desloc: Math.round(PRESEASON_DESLOCACAO * f / 10) * 10 };
}
function preSeasonStagePessoas(team) { return (team.players || []).filter(p => !p.__provisional).length + PRESEASON_STAFF; }
function preSeasonStageCustoPessoaDia(tipo) {
  const c = PRESEASON_ESTAGIOS[tipo]; if (!c) return 0;
  const pr = preSeasonPrecos(myTeam());
  return c.refeicoesDia * pr.refeicao + (c.hotel ? pr.hotel : 0);
}
function preSeasonStageDeslocacao(tipo) { const c = PRESEASON_ESTAGIOS[tipo]; return c && c.hotel ? preSeasonPrecos(myTeam()).desloc : 0; }
function preSeasonStageCost(tipo) {
  const cfg = PRESEASON_ESTAGIOS[tipo]; if (!cfg) return 0;
  return preSeasonStagePessoas(myTeam()) * preSeasonStageCustoPessoaDia(tipo) * cfg.dias + preSeasonStageDeslocacao(tipo);
}
function preSeasonFriendlyCost(casa) {
  const team = myTeam();
  const wb = monthlyWageBill(team);
  const mult = preSeasonDivMult(team);
  const piso = Math.max(50, Math.round((casa ? 800 : 1500) * mult / 10) * 10);
  return Math.max(piso, Math.round(wb * (casa ? 0.015 : 0.035) / 50) * 50);
}

function preSeasonValidFriendlyDate(ps, date) {
  const d = new Date(date);
  if (isNaN(d)) return { ok: false, reason: "Data inválida." };
  const fim = preSeasonWindowEnd();
  if (!fim) return { ok: false, reason: "Já não há jogos oficiais por disputar nesta janela." };
  if (d <= state.currentDate && !(d > state.currentDate)) return { ok: false, reason: "A data tem de ser posterior a hoje." };
  if (d > fim) return { ok: false, reason: "O amigável tem de ser jogado até à véspera do primeiro jogo oficial." };
  const key = isoDate(d);
  if (preSeasonStageDates(ps).includes(key)) return { ok: false, reason: "Nessa data o plantel está em estágio." };
  if (preSeasonOfficialDates().some(x => sameDay(x, d))) return { ok: false, reason: "Nessa data o clube tem um jogo oficial." };
  const clash = preSeasonActiveFriendlies(ps).some(g => Math.abs((new Date(g.date) - d) / 86400000) < 2);
  if (clash) return { ok: false, reason: "Tem de haver pelo menos dois dias entre amigáveis." };
  return { ok: true };
}
function preSeasonValidDates(ps) {
  const fim = preSeasonWindowEnd(); if (!fim) return [];
  const out = [];
  for (let d = addDays(state.currentDate, 1); d <= fim && out.length < 60; d = addDays(d, 1)) {
    if (preSeasonValidFriendlyDate(ps, d).ok) out.push(new Date(d));
  }
  return out;
}
function preSeasonOpponentOptions() {
  const mine = myTeam(); if (!mine) return [];
  const country = teamCountry(mine);
  return Object.values(state.teams)
    .filter(t => t && t.id !== mine.id && t.id !== mine.equipaBId && !t.equipaPrincipalId && !t.nuvemEuropeia && !t.selecaoNacional &&
      Array.isArray(t.players) && t.players.length >= 5 && teamCountry(t) === country)
    .sort((a, b) => (b.reputacaoClube || 0) - (a.reputacaoClube || 0));
}

function scheduleFriendly(opts) {
  const ps = preSeasonCurrent();
  if (!ps || !ps.aberta) return { ok: false, reason: "A pré-época já terminou." };
  if (preSeasonActiveFriendlies(ps).length >= PRESEASON_MAX_AMIGAVEIS) return { ok: false, reason: `Já tens ${PRESEASON_MAX_AMIGAVEIS} amigáveis marcados.` };
  const mine = myTeam();
  const opp = state.teams[opts && opts.oppId];
  if (!opp || opp.id === mine.id || !preSeasonOpponentOptions().some(t => t.id === opp.id)) return { ok: false, reason: "Adversário inválido." };
  const v = preSeasonValidFriendlyDate(ps, opts.date);
  if (!v.ok) return v;
  const casa = opts.casa !== false;
  const g = {
    id: `amig-${ps.epoca}-${ps.amigaveis.length + 1}-${Math.floor(Math.random() * 1e6)}`,
    date: isoDate(new Date(opts.date)), home: casa ? mine.id : opp.id, away: casa ? opp.id : mine.id, oppId: opp.id, casa,
    played: false, cancelled: false, homeScore: 0, awayScore: 0, custo: preSeasonFriendlyCost(casa), amigavel: true,
  };
  ps.amigaveis.push(g);
  ps.amigaveis.sort((a, b) => new Date(a.date) - new Date(b.date));
  return { ok: true, jogo: g };
}
function cancelFriendly(id) {
  const ps = preSeasonCurrent(); if (!ps) return { ok: false, reason: "Sem pré-época." };
  const g = ps.amigaveis.find(x => x.id === id);
  if (!g || g.played || g.cancelled) return { ok: false, reason: "Este jogo já não pode ser cancelado." };
  if (new Date(g.date) <= state.currentDate) return { ok: false, reason: "O jogo é hoje e já não pode ser cancelado." };
  g.cancelled = true;
  return { ok: true };
}

// 0.2.25 — enquanto o estágio ainda não começou (nenhum dia decorrido) pode trocar-se de opção: o custo é devolvido.
function revertPreSeasonStage() {
  const ps = preSeasonCurrent(); const e = ps && ps.estagio;
  if (!e) return { ok: true };
  if (e.terminado || e.diaAtual > 0) return { ok: false, reason: "O estágio já começou: só podes cancelá-lo (o custo já pago não é devolvido)." };
  const team = myTeam(); initClubFinance(team);
  const f = ensureFinanceAudit(team.financeiro), custo = e.custo || 0;
  f.saldo += custo; f.despesasEpoca = Math.max(0, (f.despesasEpoca || 0) - custo);
  try { const k = financeAuditCategory("Pré-época"); if (f.auditoriaEpoca && f.auditoriaEpoca.despesas) f.auditoriaEpoca.despesas[k] = Math.max(0, (f.auditoriaEpoca.despesas[k] || 0) - custo); } catch (err) {}
  const i = (f.movimentos || []).findIndex(m => m.category === "Pré-época" && m.type === "despesa" && m.value === custo);
  if (i >= 0) f.movimentos.splice(i, 1);
  ps.estagio = null;
  return { ok: true };
}
function setPreSeasonStage(tipo) {
  const ps = preSeasonCurrent(); const cfg = PRESEASON_ESTAGIOS[tipo];
  if (!ps || !ps.aberta) return { ok: false, reason: "A pré-época já terminou." };
  if (!cfg) return { ok: false, reason: "Tipo de estágio desconhecido." };
  if (ps.estagio && !ps.estagio.terminado && ps.estagio.tipo === tipo && ps.estagio.diaAtual === 0) return { ok: true, custo: ps.estagio.custo };
  if (ps.estagio) { const r = revertPreSeasonStage(); if (!r.ok) return r; }
  const team = myTeam(); initClubFinance(team);
  if (team.financeiro.restricoesInsolvencia) return { ok: false, reason: "O clube está sob intervenção financeira e não pode pagar um estágio." };
  const fim = preSeasonWindowEnd();
  if (!fim || addDays(state.currentDate, cfg.dias) > fim) return { ok: false, reason: `Já não há ${cfg.dias} dias livres antes do primeiro jogo oficial.` };
  const stageEnd = addDays(state.currentDate, cfg.dias);
  if (preSeasonOfficialDates().some(x => x > state.currentDate && x <= stageEnd)) return { ok: false, reason: "Há um jogo oficial marcado durante os dias do estágio." };
  if (preSeasonActiveFriendlies(ps).some(g => { const d = new Date(g.date); return d > state.currentDate && d <= stageEnd; })) {
    return { ok: false, reason: "Há um amigável marcado durante os dias do estágio. Cancela-o primeiro." };
  }
  const custo = preSeasonStageCost(tipo);
  addFinanceMovement(team, "despesa", "Pré-época", `${cfg.label} de pré-época (${cfg.dias} dias)`, custo, state.currentDate);
  ps.semEstagio = false;
  ps.estagio = { tipo, inicio: isoDate(state.currentDate), dias: cfg.dias, diaAtual: 0, ultimoDia: isoDate(state.currentDate), terminado: false, custo, lesoes: 0 };
  return { ok: true, custo };
}

// Escolha explícita de não fazer estágio (2026-10-12, pedido do utilizador: o texto "Sem estágio…"
// parecia um botão e não era). Só decide enquanto ainda não há estágio; pode mudar de ideias.
function setPreSeasonNoStage() {
  const ps = preSeasonCurrent();
  if (!ps || !ps.aberta) return { ok: false, reason: "A pré-época já terminou." };
  if (ps.estagio) { const r = revertPreSeasonStage(); if (!r.ok) return r; }
  ps.semEstagio = true;
  return { ok: true };
}
// Cancela um estágio em curso: o custo já pago perde-se e os dias restantes são dispensados.
function cancelPreSeasonStage() {
  const ps = preSeasonCurrent(); const e = ps && ps.estagio;
  if (!e || e.terminado) return { ok: false, reason: "Não há nenhum estágio em curso." };
  e.terminado = true; e.cancelado = true;
  const rest = Math.max(0, e.dias - e.diaAtual);
  pushNews(state.currentDate, `O estágio foi cancelado a meio (faltavam ${rest} dia${rest === 1 ? "" : "s"}). O custo já pago não é devolvido; o plantel regressa ao treino normal.`, "sistema", "Estágio cancelado");
  return { ok: true };
}

// Efeitos diários do estágio: condição, familiaridade táctica, entrosamento e risco de lesão.
function advancePreSeasonStageDay(ps) {
  const e = ps && ps.estagio;
  if (!e || e.terminado) return;
  const today = isoDate(state.currentDate);
  if (today <= e.ultimoDia) return;
  e.ultimoDia = today;
  e.diaAtual += 1;
  const cfg = PRESEASON_ESTAGIOS[e.tipo];
  if (e.diaAtual === 1) pushNews(state.currentDate, `O plantel parte para um ${cfg.label.toLowerCase()} de ${cfg.dias} dias. Os jogadores ficam ao serviço do treinador até ao fim do período.`, "sistema", "Estágio de pré-época");
  const team = myTeam();
  const sistema = team.treinoTaticoEscolhido || team.sistema || "3-1";
  if (sistemaOk(sistema)) famAdd(team, sistema, cfg.famDia);
  const medMult = medicalInjuryMult(team);
  const b = ensureBalneario(team);
  if (b) {
    syncBalnearioPresenca(team);
    b.coesao = clamp(b.coesao + cfg.coesaoDia, 3, 99);
    // Os recém-chegados integram-se mais depressa: cada dia de estágio "vale" 6 dias de convívio.
    Object.keys(b.presenca).forEach(pid => { if (balnearioAgoMs() - b.presenca[pid] < 60 * 86400000) b.presenca[pid] -= 6 * 86400000; });
  }
  const lesionados = [];
  team.players.filter(p => !p.__provisional).forEach(p => {
    p.condicao = roundDecimal(clamp((p.condicao != null ? p.condicao : 100) + cfg.condDia, 0, 100));
    if ((p.diasLesao || 0) > 0) return;
    let risco = cfg.riscoDia * medMult;
    if ((p.age || 24) >= 31) risco *= 1 + ((p.age || 31) - 30) * 0.05;
    if ((p.condicao != null ? p.condicao : 100) < 60) risco *= 1.4;
    if (Math.random() < risco) {
      const dias = Math.max(3, Math.round((6 + Math.random() * 22) * medicalDurationMult(team)));
      lesionados.push({ p, dias });
    }
  });
  e.lesoes += lesionados.length;
  lesionados.forEach(({ p, dias }) => lesAplicarGrave(p, team, { origem: { tipo: "estagio" }, dias }));
  if (e.diaAtual >= e.dias) {
    e.terminado = true;
    const extra = e.lesoes ? ` Houve ${e.lesoes} lesão${e.lesoes > 1 ? "ões" : ""} pelo caminho.` : " Sem lesões a lamentar.";
    pushNews(state.currentDate, `O estágio terminou. O plantel regressa mais em forma, mais entrosado nos sistemas de jogo e com os recém-chegados mais integrados.${extra}`, "sistema", "Estágio concluído");
  }
}

// Chamado todos os dias (09-fluxo-epoca.js), logo a seguir às restantes provas do dia.
function processPreSeasonForCurrentDate() {
  // Amigáveis e quadrangulares marcados no separador Calendário (08t-calendario.js) — valem em
  // qualquer altura da época, por isso são tratados antes de saber se ainda há pré-época.
  if (typeof calAmigProcessarHoje === "function" && calAmigProcessarHoje()) return true;
  const ps = preSeasonCurrent();
  if (!ps) return false;
  advancePreSeasonStageDay(ps);
  const today = state.currentDate;
  const fim = preSeasonWindowEnd();
  for (const g of ps.amigaveis) {
    if (g.played || g.cancelled) continue;
    const d = new Date(g.date);
    if (d > today && !sameDay(d, today)) continue;
    if (!sameDay(d, today) && (today - d) / 86400000 > 1) {
      g.cancelled = true;
      pushNews(today, `O jogo de preparação com ${teamLinkHtml(g.oppId)} foi cancelado: não foi possível realizá-lo na data marcada.`, "sistema", "Amigável cancelado");
      continue;
    }
    if (state.matchDayReady || state.pendingFixture) return false; // vaga única partilhada com as restantes provas
    const mine = myTeam();
    state.pendingProvisional = { mine: ensureMinimumSquad(mine), opp: ensureMinimumSquad(state.teams[g.oppId]) };
    state.pendingFixture = g; state.pendingAmigavel = true;
    generatePreGameReport(g, "Jogo de preparação", null);
    state.matchDayReady = true;
    return true;
  }
  if (ps.aberta && (!fim || today > fim)) ps.aberta = false;
  return false;
}
// Antevisão na véspera (mesmo padrão da Supertaça/Taça).
function preSeasonPreviewForTomorrow() {
  if (typeof calAmigAmanha === "function" && calAmigAmanha()) return true;
  const ps = preSeasonCurrent(); if (!ps) return false;
  const amanha = addDays(state.currentDate, 1);
  const g = ps.amigaveis.find(x => !x.played && !x.cancelled && sameDay(new Date(x.date), amanha));
  if (!g) return false;
  pushNews(state.currentDate, `Jogo de preparação amanhã: ${teamLinkHtml(g.home)} vs ${teamLinkHtml(g.away)}${g.casa ? ", em casa" : ", fora"}. O resultado não conta para nenhuma competição.`, "jogo", "Jogo de preparação amanhã");
  generatePreGameReport(g, "Jogo de preparação", null);
  return true;
}
function preSeasonNextFriendlyRow() {
  const ps = preSeasonCurrent();
  const g = ps ? ps.amigaveis.find(x => !x.played && !x.cancelled) : null;
  const a = g ? { date: g.date, label: "Jogo de preparação", oppId: g.oppId, casa: g.casa } : null;
  const b = typeof calAmigProximaLinha === "function" ? calAmigProximaLinha() : null;
  if (a && b) return new Date(a.date) <= new Date(b.date) ? a : b;
  return a || b;
}

function recordFriendlyResult(g, hs, as) {
  if (!g) return;
  const ps = preSeasonCurrent();
  g.played = true; g.homeScore = hs; g.awayScore = as;
  const mine = myTeam();
  const minhaPontuacao = g.home === mine.id ? hs : as, adversaria = g.home === mine.id ? as : hs;
  const res = minhaPontuacao > adversaria ? "V" : minhaPontuacao < adversaria ? "D" : "E";
  // Amigável marcado no Calendário: o objeto pode ser uma cópia; sincroniza o original.
  if (g.origem === "cal" && state.calAmig) {
    const q = state.calAmig.jogos.find(x => x.id === g.id);
    if (q && q !== g) { q.played = true; q.homeScore = hs; q.awayScore = as; }
  }
  const custo = g.custo != null ? g.custo : preSeasonFriendlyCost(g.casa);
  if (custo > 0) addFinanceMovement(mine, "despesa", g.origem === "cal" ? "Jogos de preparação" : "Pré-época", `Jogo de preparação com ${state.teams[g.oppId] ? state.teams[g.oppId].name : "adversário"} (organização${g.casa ? "" : " e deslocação"})`, custo, state.currentDate);
  if (g.casa && state.teams[g.oppId]) pavilhaoAmigavel(mine, state.teams[g.oppId], state.currentDate);   // bilheteira e bar (08o-pavilhao.js)
  // Entrosamento: um jogo a sério treina o sistema usado e integra os recém-chegados.
  const sistema = mine.sistema || "3-1";
  if (sistemaOk(sistema)) famAdd(mine, sistema, 1.0);
  const b = ensureBalneario(mine);
  if (b) {
    syncBalnearioPresenca(mine);
    b.coesao = clamp(b.coesao + (res === "V" ? 0.9 : res === "E" ? 0.6 : 0.3), 3, 99);
    Object.keys(b.presenca).forEach(pid => { if (balnearioAgoMs() - b.presenca[pid] < 60 * 86400000) b.presenca[pid] -= 10 * 86400000; });
  }
  const txt = res === "V" ? "Vitória" : res === "D" ? "Derrota" : "Empate";
  if (typeof amigIAEfeitos === "function" && state.teams[g.oppId]) amigIAEfeitos(state.teams[g.oppId], res === "V" ? "D" : res === "D" ? "V" : "E");
  if (g.torneioId && typeof calTorneioResultado === "function") { calTorneioResultado(g, hs, as); return; }
  pushNews(state.currentDate, `🤝 Jogo de preparação: ${teamLinkHtml(g.home)} ${hs}-${as} ${teamLinkHtml(g.away)}. ${txt} no ensaio — o plantel ganhou rodagem e entrosamento, mas o resultado não conta para nada.`, "jogo", `Amigável: ${txt} ${minhaPontuacao}-${adversaria}`);
}

// ---------------------------------------------------------------- Interface (Centro do Clube)
function preSeasonDateLabel(d) { return fmtDateShort(d instanceof Date ? d : new Date(d)); }
function renderPreSeasonPanel() {
  // O mesmo painel aparece no sub-separador Pré-época do Calendário e no ecrã de pré-época (modal), onde o utilizador
  // passa os primeiros dias da carreira.
  ["preSeasonPanel", "preSeasonPanelModal"].forEach(id => renderPreSeasonPanelInto(document.getElementById(id)));
}
function renderPreSeasonPanelInto(el) {
  if (!el) return;
  const ps = preSeasonCurrent(); const team = typeof myTeam === "function" ? myTeam() : null;
  const pendentes = ps ? ps.amigaveis.filter(g => !g.played && !g.cancelled) : [];
  const mostrar = ps && team && (ps.aberta || pendentes.length || (ps.estagio && !ps.estagio.terminado));
  if (!mostrar) { el.classList.add("hidden"); el.innerHTML = ""; return; }
  el.classList.remove("hidden");
  const fim = preSeasonWindowEnd();
  const e = ps.estagio;
  // 0.2.19 — passo 2: estágio em cartões (Sem estágio / Curto / Longo) com custo e efeitos à vista.
  let estagioHtml, estagioBadge = "";
  const efeitos = t => { const c = PRESEASON_ESTAGIOS[t]; return `<li class="up">▲ Condição física +${String(c.condDia).replace(".", ",")}/dia</li><li class="up">▲ Sistema táctico +${String(c.famDia).replace(".", ",")}/dia</li><li class="up">▲ Coesão do balneário</li><li class="dn">▼ ${t === "longo" ? "Maior" : t === "refeicoes" ? "Pouco" : "Algum"} risco de lesão</li>`; };
  const emCurso = !!(e && !e.terminado);
  const iniciado = emCurso && e.diaAtual > 0;   // já passou pelo menos um dia: já não se troca
  if (!e && !ps.aberta) { estagioHtml = '<div class="ps-hint">Sem estágio nesta pré-época.</div>'; estagioBadge = '<span class="ps-badge">Terminado</span>'; }
  else if (!e || emCurso) {
    // 0.2.25 — as quatro opções ficam sempre visíveis; a escolhida fica destacada e, enquanto o estágio não
    // começou, pode trocar-se por outra (o custo é devolvido). Depois de começar, só se pode cancelar.
    const escolhido = emCurso ? e.tipo : (ps.semEstagio ? "sem" : null);
    const marca = t => escolhido === t ? '<span class="ps-chosen">✓ Escolhido</span>' : "";
    const dis = t => iniciado && escolhido !== t ? "disabled" : "";
    const card = t => { const c = PRESEASON_ESTAGIOS[t]; return `<button type="button" class="ps-opt ps-stage-btn ${escolhido === t ? "sel" : ""}" data-tipo="${t}" ${dis(t)}><h4>${c.label}</h4><span class="ps-meta">${iniciado && escolhido === t ? `Dia ${Math.min(e.diaAtual + 1, e.dias)} de ${e.dias}` : `${c.dias} dias${t === "refeicoes" ? " · só refeições, sem dormidas" : ""}`}</span><span class="ps-pricerow"><span class="ps-price">${fmtMoney(preSeasonStageCost(t))}</span>${marca(t)}</span><ul>${efeitos(t)}</ul></button>`; };
    const sem = `<button type="button" class="ps-opt ps-nostage-btn ${escolhido === "sem" ? "sel" : ""}" ${dis("sem")}><h4>Sem estágio</h4><span class="ps-meta">O plantel treina normalmente</span><span class="ps-pricerow"><span class="ps-price">0 €</span>${marca("sem")}</span><ul><li>Sem risco de lesões extra</li><li>Sem ganhos extra</li></ul></button>`;
    const dica = iniciado ? `Estágio em curso: já não dá para trocar. Podes cancelá-lo, mas o custo já pago não é devolvido. <button class="btn btn-ghost ps-stage-cancel-btn" type="button">Cancelar estágio</button>`
      : emCurso ? `Ainda não começou: podes trocar (o custo é devolvido). Sem jogos durante o estágio. `
      : `${ps.semEstagio ? "Decidido: sem estágio (ainda podes mudar de ideias). " : "Durante o estágio não há amigáveis nem jogos. "}`;
    estagioHtml = `<div class="ps-opts">${sem}${card("refeicoes")}${card("curto")}${card("longo")}</div><div class="ps-hint">${dica}</div>`;
    estagioBadge = iniciado ? '<span class="ps-badge ok">Em curso</span>' : emCurso ? '<span class="ps-badge ok">✓ Escolhido</span>' : ps.semEstagio ? '<span class="ps-badge ok">✓ Sem estágio</span>' : '<span class="ps-badge">Por decidir</span>';
  } else if (e.cancelado) {
    estagioHtml = `<div class="ps-hint"><b>${PRESEASON_ESTAGIOS[e.tipo].label} cancelado</b> ao fim de ${e.diaAtual} dia${e.diaAtual === 1 ? "" : "s"}.</div>`;
    estagioBadge = '<span class="ps-badge">Cancelado</span>';
  } else {
    estagioHtml = `<div class="ps-hint"><b>${PRESEASON_ESTAGIOS[e.tipo].label} concluído</b>${e.lesoes ? ` · ${e.lesoes} lesão${e.lesoes > 1 ? "ões" : ""}` : " · sem lesões"}.</div>`;
    estagioBadge = '<span class="ps-badge ok">✓ Concluído</span>';
  }
  // Passo 3: até PRESEASON_MAX_AMIGAVEIS ranhuras — jogos marcados + ranhuras vazias para marcar.
  const ativos = preSeasonActiveFriendlies(ps);
  const podeMarcar = ps.aberta && ativos.length < PRESEASON_MAX_AMIGAVEIS && preSeasonValidDates(ps).length > 0;
  const preenchidas = ativos.map(g => {
    const opp = state.teams[g.oppId];
    const acao = g.played ? `<b>${g.homeScore}-${g.awayScore}</b>` : `<button class="btn btn-ghost ps-cancel-btn" data-id="${g.id}" type="button" ${new Date(g.date) <= state.currentDate ? "disabled" : ""}>Cancelar</button>`;
    return `<div class="ps-slot f"><div><b>${preSeasonDateLabel(g.date)}</b> · ${g.casa ? "Casa" : "Fora"}<small>${opp ? escapeHtml(opp.name) : "—"} · ${fmtMoney(g.custo)}</small></div>${acao}</div>`;
  });
  const vazias = [];
  for (let i = ativos.length; i < PRESEASON_MAX_AMIGAVEIS; i++) vazias.push(ps.aberta ? `<button type="button" class="ps-slot ps-add-btn" ${podeMarcar ? "" : "disabled"}>＋ Marcar amigável</button>` : `<div class="ps-slot">—</div>`);
  const nJog = ativos.filter(g => !g.cancelled).length;
  el.innerHTML = `
    <div class="ps-step">
      <div class="ps-step-h"><span class="ps-num">2</span><h3>Estágio</h3><span class="ps-sub">escolhe uma opção (só uma)</span>${estagioBadge}</div>
      ${estagioHtml}
    </div>
    <div class="ps-step">
      <div class="ps-step-h"><span class="ps-num">3</span><h3>Jogos de preparação</h3><span class="ps-sub">até ${PRESEASON_MAX_AMIGAVEIS} amigáveis · só custos, sem receitas</span><span class="ps-badge ${nJog ? "ok" : ""}">${nJog} / ${PRESEASON_MAX_AMIGAVEIS}</span></div>
      <div class="ps-slots">${preenchidas.join("")}${vazias.join("")}</div>
      <div class="ps-hint">Não contam para a competição; treinam o sistema mas cansam e arriscam lesões.${fim && ps.aberta ? ` Janela até ${preSeasonDateLabel(fim)}.` : ""}</div>
    </div>`;
  const sum = document.getElementById("psSummary");
  if (sum && el.id === "preSeasonPanelModal") {
    const est = e ? (e.cancelado ? "Estágio cancelado" : PRESEASON_ESTAGIOS[e.tipo].label) : (ps.semEstagio ? "Sem estágio" : "Estágio por decidir");
    sum.innerHTML = `Resumo: <b>${est}</b> · <b>${nJog} ${nJog === 1 ? "amigável" : "amigáveis"}</b> · <b>${fmtMoney(team.financeiro.orcamentoTransferencias)}</b> para transferências`;
  }
}

function openPreSeasonFriendlyModal() {
  const ps = preSeasonCurrent(); if (!ps) return;
  const datas = preSeasonValidDates(ps);
  const m = balnearioModalEl();
  m.querySelector("#balnearioModalTitle").textContent = "Marcar amigável";
  const opts = preSeasonOpponentOptions();
  const grupos = {};
  opts.forEach(t => { const lab = competitionLabel(competitionIdForTeam(t.id)) || "Outros"; (grupos[lab] = grupos[lab] || []).push(t); });
  const oppHtml = Object.keys(grupos).map(lab => `<optgroup label="${escapeHtml(lab)}">${grupos[lab].map(t => `<option value="${t.id}">${escapeHtml(t.name)}</option>`).join("")}</optgroup>`).join("");
  m.querySelector("#balnearioModalBody").innerHTML = `
    <div class="ps-form">
      <div class="ps-datelabel">Data<br>${calPickerHtml("psDate", datas.map(d => isoDate(d)), "")}</div>
      <label>Adversário<br><select id="psOpp">${oppHtml}</select></label>
      <label>Local<br><select id="psCasa"><option value="1">Em casa (${fmtMoney(preSeasonFriendlyCost(true))})</option><option value="0">Fora (${fmtMoney(preSeasonFriendlyCost(false))})</option></select></label>
      <div class="helptext" id="psFormErr" style="color:#d6402f;"></div>
      <div class="modal-actions" style="margin-top:8px;"><button class="btn btn-primary" id="psConfirmFriendly">Marcar jogo</button></div>
    </div>`;
  m.classList.remove("hidden");
  calPickerDraw(document.getElementById("psDate"));
}

(function wirePreSeasonUi() {
  document.addEventListener("click", e => {
    const t = e.target;
    if (!t || !t.closest) return;
    const stage = t.closest(".ps-stage-btn");
    if (stage) {
      const r = setPreSeasonStage(stage.getAttribute("data-tipo"));
      if (!r.ok) showTransientNotice(r.reason);
      renderPreSeasonPanel(); if (typeof renderAll === "function") renderAll();
      return;
    }
    if (t.closest(".ps-nostage-btn")) {
      const r = setPreSeasonNoStage();
      if (!r.ok) showTransientNotice(r.reason); else showTransientNotice("Sem estágio: o plantel treina normalmente.");
      renderPreSeasonPanel();
      return;
    }
    if (t.closest(".ps-stage-cancel-btn")) {
      const r = cancelPreSeasonStage();
      if (!r.ok) showTransientNotice(r.reason); else showTransientNotice("Estágio cancelado.");
      renderPreSeasonPanel(); if (typeof renderAll === "function") renderAll();
      return;
    }
    const cancel = t.closest(".ps-cancel-btn");
    if (cancel) {
      const r = cancelFriendly(cancel.getAttribute("data-id"));
      if (!r.ok) showTransientNotice(r.reason);
      renderPreSeasonPanel();
      return;
    }
    if (t.closest(".ps-add-btn")) { if (!t.closest(".ps-add-btn").disabled) openPreSeasonFriendlyModal(); return; }
    if (t.closest("#psConfirmFriendly")) {
      if (!document.getElementById("psDate").getAttribute("data-value")) { document.getElementById("psFormErr").textContent = "Escolhe um dia no calendário."; return; }
      const r = scheduleFriendly({ date: document.getElementById("psDate").getAttribute("data-value"), oppId: document.getElementById("psOpp").value, casa: document.getElementById("psCasa").value === "1" });
      if (!r.ok) { document.getElementById("psFormErr").textContent = r.reason; return; }
      balnearioModalEl().classList.add("hidden");
      renderPreSeasonPanel();
      showTransientNotice("Amigável marcado.");
    }
  });
})();
