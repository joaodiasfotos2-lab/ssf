// Carga de trabalho e sugestão de rotação (2026-10-12, pedido do utilizador: ideia 6 da sexta lista).
// Decisões de desenho confirmadas por ele:
//  - o que conta para a carga acumulada de cada jogador: MINUTOS JOGADOS, DIAS DE DESCANSO entre
//    jogos, VIAGENS (zona geográfica, ver 08j-viagens.js) e TÁTICA/INTENSIDADE;
//  - consequências da carga elevada: MAIOR RISCO DE LESÃO, RECUPERAÇÃO DE CONDIÇÃO MAIS LENTA,
//    RENDIMENTO EM CAMPO e SUGESTÃO DE ROTAÇÃO do adjunto;
//  - vale para TODOS os clubes: a IA sofre os mesmos efeitos e roda o seu onze consoante a carga.
//
// Modelo: player.carga (0–100, "carga aguda" acumulada, guardada com o jogador; saves antigos
// começam a 0). Sobe no fim de cada jogo (cargaAposJogo) e decai todos os dias (cargaDiario).
//  - Um jogo completo de 40 minutos soma ~24 pontos (CARGA_BASE_JOGO); menos minutos, menos carga.
//  - Descanso curto agrava: jogo com ≤2 dias desde o anterior ×1,5, ≤4 dias ×1,25, ≤6 dias ×1,1.
//  - Tática: mentalidade ofensiva ×1,12 / defensiva ×0,92; pressão alta ×1,08 / baixa ×0,94;
//    intensidade do jogo (matchIntensityFactor) entra como fator limitado a 0,85–1,2.
//  - Viagem do visitante: + fadiga da deslocação × 1,5 (escalão 3, estrangeiro, soma ~13 pontos).
//  - Decaimento diário ×0,92 (meia-vida ~8 dias), ligeiramente mais rápido com bom departamento
//    médico (medicalRecoveryMult). Com um jogo por semana a carga ronda os 25–50; com dois jogos
//    na mesma semana passa dos 65 ("alta").
//
// Efeitos: probabilidade de lesão até ×1,6 (injuryChance), recuperação diária de condição até −30%
// (dailyConditionRecovery) e rendimento até −5% (condicaoFactor, por isso em todos os cálculos de
// força, onze e substituições). A IA escolhe o onze com uma penalização à carga (bestOutfieldForSystem).

const CARGA_DECAY = 0.92;
const CARGA_BASE_JOGO = 24;
const CARGA_JOGO_MINUTOS = 40;
const CARGA_BANDAS = [
  { min: 80, id: "critica", label: "Crítica", cor: "#D6402F" },
  { min: 65, id: "alta", label: "Alta", cor: "#E8892B" },
  { min: 45, id: "elevada", label: "Elevada", cor: "#F3C623" },
  { min: 0, id: "normal", label: "Normal", cor: "#3FA34D" },
];
const CARGA_AVISO_MIN = 65;           // a partir daqui o adjunto sugere rotação
const CARGA_AVISO_INTERVALO_DIAS = 5; // no máximo um aviso agregado de cinco em cinco dias

function cargaValor(p){ return p && Number.isFinite(p.carga) ? clamp(p.carga, 0, 100) : 0; }
function cargaBanda(p){
  const c = cargaValor(p);
  return CARGA_BANDAS.find(b => c >= b.min) || CARGA_BANDAS[CARGA_BANDAS.length - 1];
}
function cargaInjuryMult(p){ return 1 + clamp((cargaValor(p) - 50) / 50, 0, 1) * 0.6; }
function cargaRecoveryMult(p){ return 1 - clamp((cargaValor(p) - 55) / 45, 0, 1) * 0.30; }
function cargaPerfFactor(p){ return 1 - clamp((cargaValor(p) - 60) / 40, 0, 1) * 0.05; }
// Penalização (em pontos de OVR) usada pela IA ao escolher o onze: até 4 pontos com carga 100.
function cargaRotacaoPenalty(p){ return clamp((cargaValor(p) - 55) / 45, 0, 1) * 4; }

function cargaDiasDesde(p, hoje){
  if(!p || !p.cargaUltimoJogo) return 99;
  const d = new Date(p.cargaUltimoJogo), h = new Date(hoje || state.currentDate);
  return Math.max(0, Math.round((h - d) / 86400000));
}
function cargaIsoData(d){ return isoDate(new Date(d || state.currentDate)); }

// Carga que um jogador soma num jogo concreto (sem a aplicar) — separado para ser testável.
function cargaDoJogo(p, team, ctx, side, minutos){
  const friendly = !!(ctx && ctx.isFriendly);
  let inc = (minutos / CARGA_JOGO_MINUTOS) * CARGA_BASE_JOGO;
  const dias = cargaDiasDesde(p);
  if(!friendly){
    if(dias <= 2) inc *= 1.5; else if(dias <= 4) inc *= 1.25; else if(dias <= 6) inc *= 1.1;
  } else {
    inc *= 0.6;
  }
  const m = team && team.mentalidade;
  inc *= m === "ofensivo" ? 1.12 : m === "defensivo" ? 0.92 : 1;
  const pr = team && team.pressao;
  inc *= pr === "alta" ? 1.08 : pr === "baixa" ? 0.94 : 1;
  inc *= clamp(ctx && ctx.intensity != null ? ctx.intensity : 1, 0.85, 1.2);
  if(side === "away" && ctx && ctx.viagem && ctx.viagem.fadiga > 0) inc += ctx.viagem.fadiga * 1.5;
  return inc;
}

// Fim de jogo (chamado em finalizePlayerStats, para TODOS os clubes): soma a carga de quem jogou.
function cargaAposJogo(ctx){
  ["home", "away"].forEach(side => {
    const team = state.teams[side === "home" ? ctx.homeId : ctx.awayId];
    if(!team) return;
    const played = ctx.playedSet && ctx.playedSet[side];
    if(!played) return;
    team.players.forEach(p => {
      if(!played.has(p.id)) return;
      const min = ctx.playerMinutes && ctx.playerMinutes[p.id] != null ? ctx.playerMinutes[p.id] : 20;
      p.carga = clamp(cargaValor(p) + cargaDoJogo(p, team, ctx, side, min), 0, 100);
      if(!ctx.isFriendly) p.cargaUltimoJogo = cargaIsoData();
    });
  });
}

// Todos os dias (dailyConditionRecovery): decaimento da carga de todos os jogadores de todos os
// clubes e, para o clube do utilizador, o aviso do adjunto.
function cargaDiario(){
  Object.values(state.teams).forEach(t => {
    const k = Math.pow(CARGA_DECAY, Math.max(0.5, medicalRecoveryMult(t)));
    (t.players || []).forEach(p => {
      const c = cargaValor(p);
      if(c <= 0){ if(p.carga != null && !Number.isFinite(p.carga)) p.carga = 0; return; }
      p.carga = c * k < 0.5 ? 0 : Math.round(c * k * 10) / 10;
    });
  });
  const mine = state.userTeamId && state.teams[state.userTeamId];
  if(mine) cargaAvisoAdjunto(mine);
}

// Melhor alternativa de rotação para um jogador sobrecarregado: mesma posição e linha, disponível,
// carga baixa e OVR o mais próximo possível.
function cargaAlternativa(team, p){
  const ovr = overall(p);
  return (team.players || [])
    .filter(q => q.id !== p.id && q.pos === p.pos && (p.pos === "GR" || q.linha === p.linha) && playerAvailableForMatch(q) && cargaValor(q) < 45 && !q.emprestimo)
    .sort((a, b) => Math.abs(overall(a) - ovr) - Math.abs(overall(b) - ovr))[0] || null;
}
function cargaSobrecarregados(team){
  return (team.players || [])
    .filter(p => playerAvailableForMatch(p) && cargaValor(p) >= CARGA_AVISO_MIN)
    .sort((a, b) => cargaValor(b) - cargaValor(a));
}
function cargaAvisoAdjunto(team){
  const hoje = cargaIsoData();
  if(team.cargaUltimoAviso && cargaDiasDesde({ cargaUltimoJogo: team.cargaUltimoAviso }, hoje) < CARGA_AVISO_INTERVALO_DIAS) return false;
  const lista = cargaSobrecarregados(team);
  if(!lista.length) return false;
  team.cargaUltimoAviso = hoje;
  const linhas = lista.slice(0, 5).map(p => {
    const alt = cargaAlternativa(team, p);
    const b = cargaBanda(p);
    return [playerNameHtml(p), `carga ${b.label.toLowerCase()} (${Math.round(cargaValor(p))}), condição ${Math.round(p.condicao != null ? p.condicao : 100)}%${alt ? ` — sugiro descansar e dar a vez a ${playerNameHtml(alt)} (carga ${Math.round(cargaValor(alt))})` : " — sem alternativa descansada na mesma posição"}.`];
  });
  pushNews(state.currentDate,
    repDoc({
      teamId: team.id, org: "Departamento técnico", titulo: "Rotação do plantel",
      sub: `${lista.length} jogador${lista.length > 1 ? "es" : ""} com carga alta`,
      chips: [repChip(`${lista.length} em risco`, "aviso")],
      resumo: "Com carga elevada sobe o risco de lesão, a condição recupera mais devagar e o rendimento desce. Uma rotação no próximo jogo ajuda: a carga decai cerca de 8% por dia de descanso.",
      secoes: [{ icone: "🔋", titulo: "Jogadores a poupar", cheia: true, linhas: linhas }],
      rodape: "Gestão de carga · treinador adjunto",
    }),
    "tatica", `Rotação: ${lista.length} jogador${lista.length > 1 ? "es" : ""} com carga alta`);
  return true;
}

// Resumo para o utilizador (ficha do jogador e tabela do plantel).
function cargaBadgeHtml(p){
  const c = cargaValor(p);
  if(c < 45) return "";
  const b = cargaBanda(p);
  return `<span title="Carga de trabalho ${b.label.toLowerCase()} (${Math.round(c)}): mais risco de lesão, recuperação mais lenta" style="color:${b.cor};font-weight:800;font-size:10px;margin-left:4px;">⚡${b.label}</span>`;
}
function cargaFichaHtml(p){
  const c = cargaValor(p);
  const b = cargaBanda(p);
  const txt = c < 45 ? "Carga normal: sem efeitos."
    : `Risco de lesão ×${cargaInjuryMult(p).toFixed(2)} · recuperação diária ×${cargaRecoveryMult(p).toFixed(2)} · rendimento ×${cargaPerfFactor(p).toFixed(3)}`;
  return `<div class="helptext" style="margin-top:6px;">Carga de trabalho: <b style="color:${b.cor}">${b.label}</b> (${Math.round(c)}/100). ${txt}</div>`;
}
