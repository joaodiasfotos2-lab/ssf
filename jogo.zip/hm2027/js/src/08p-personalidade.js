// Personalidade do jogador (2026-10-12, pedido do utilizador: ideia 4 da nona lista).
// Decisões de desenho confirmadas por ele:
//  - 4 traços: Ambicioso (quer jogar e ganhar), Leal ao clube, Líder (química e capitão) e Instável
//    (cartões, polémicas, rendimento que oscila);
//  - influencia: humor e satisfação, renovações e propostas, balneário e disciplina, e o
//    rendimento em jogo (efeito pequeno);
//  - o traço do plantel do utilizador vê-se logo; o dos outros jogadores só depois de um relatório de
//    scouting (coerente com o nevoeiro já existente);
//  - notícias quando o traço dispara, aviso do adjunto no relatório mensal, a IA também usa os
//    traços e o traço evolui com a carreira.
//
// O campo antigo `temperamento` (Profissional/Ambicioso/Calmo/Volátil) mantém-se para o código que
// já o usa (taxas de moral, exigências salariais), mas deixa de ser mostrado: a ficha mostra a
// personalidade. A personalidade é derivada do temperamento na primeira vez que é pedida
// (Ambicioso→ambicioso, Volátil→instável; os restantes dividem-se entre líder e leal consoante a
// liderança) e depois guardada em `p.personalidade`. Quando o traço evolui, o temperamento
// acompanha-o para nunca se contradizerem.
//
// Dados no jogador: personalidade ("ambicioso"|"leal"|"lider"|"instavel"),
// pedidoSaida { desde, motivo, teamId } | null.
//
// ESTIMATIVAS (não existem no RGHP): todos os pesos numéricos abaixo — efeitos na satisfação, na
// moral, no rendimento (máx. ±2% a ±6% de oscilação nos instáveis), nos cartões, no balneário,
// probabilidades mensais de pedidos de saída e conflitos, e as transições de traço no fim da época.

const PERS_TRACOS = {
  ambicioso: { label: "Ambicioso", temperamento: "Ambicioso",
    texto: "Quer jogar e ganhar. Reage mal a ser suplente e a clubes sem objetivos; está atento a propostas de clubes maiores e exige mais na renovação." },
  leal: { label: "Leal ao clube", temperamento: "Calmo",
    texto: "Aguenta bem as fases más e renova com mais facilidade e por menos. Recusa mudar-se para um rival." },
  lider: { label: "Líder", temperamento: "Profissional",
    texto: "Puxa pelo grupo: sobe a química do balneário, é candidato natural a capitão e rende um pouco mais nos jogos grandes." },
  instavel: { label: "Instável", temperamento: "Volátil",
    texto: "Rendimento que oscila com o humor. Mais cartões e polémicas, mais conflitos no balneário e satisfação mais volátil." },
};
const PERS_IDS = Object.keys(PERS_TRACOS);

function persTraco(p){
  if(!p) return "leal";
  if(PERS_TRACOS[p.personalidade]) return p.personalidade;
  const temp = p.temperamento;
  const lid = p.attrs && p.attrs.lideranca != null ? p.attrs.lideranca : 10;
  const r = balnearioHash01("pers|" + p.id);
  let t;
  if(temp === "Ambicioso") t = "ambicioso";
  else if(temp === "Volátil") t = "instavel";
  else {
    // Profissional/Calmo: escolha ponderada pelos atributos (determinístico por jogador).
    const det = p.attrs && p.attrs.determinacao != null ? p.attrs.determinacao : 10;
    const agg = p.attrs && p.attrs.agressividade != null ? p.attrs.agressividade : 10;
    const age = p.age || 25;
    const w = {
      lider: 0.8 + Math.max(0, lid - 11) * 0.6,
      ambicioso: 0.6 + Math.max(0, det - 11) * 0.35 + (age <= 24 ? 0.4 : 0),
      instavel: 0.25 + Math.max(0, agg - 12) * 0.3,
      leal: 1.2 + (age >= 28 ? 0.5 : 0),
    };
    const tot = w.lider + w.ambicioso + w.instavel + w.leal;
    let x = r * tot;
    t = "leal";
    for(const k of ["lider", "ambicioso", "instavel", "leal"]){ if(x < w[k]){ t = k; break; } x -= w[k]; }
  }
  p.personalidade = t;
  return t;
}
function persLabelDe(t){ return (PERS_TRACOS[t] || PERS_TRACOS.leal).label; }

// Só se conhece a personalidade dos jogadores do clube do utilizador ou observados por scouting.
function persConhecida(p, team){
  if(!p) return false;
  if(team && isUserControlledTeam(team)) return true;
  if(p.__persRevelada) return true;
  try { return !!scoutingReportFor(p.id); } catch(e){ return false; }
}
function persLinhaFicha(p, team){
  const known = persConhecida(p, team);
  if(!known) return `<div class="pm-retro-row"><span class="lbl">Personalidade</span><span class="val"><span class="helptext" title="Só se descobre com um relatório de scouting">Desconhecida</span></span></div>`;
  const t = persTraco(p);
  const pedido = p.pedidoSaida ? ` <span class="helptext" title="Pediu para sair do clube" style="color:#D6402F;">· pediu para sair</span>` : "";
  return `<div class="pm-retro-row"><span class="lbl">Personalidade</span><span class="val"><span class="helptext" title="${escapeHtml(PERS_TRACOS[t].texto)}">${escapeHtml(PERS_TRACOS[t].label)}</span>${pedido}</span></div>`;
}
function persParagrafoScouting(p){
  const t = persTraco(p);
  return `Personalidade: ${PERS_TRACOS[t].label.toLowerCase()}. ${PERS_TRACOS[t].texto}`;
}

// ---------------------------------------------------------------------------------------------
// Satisfação, moral, rendimento e disciplina
// ---------------------------------------------------------------------------------------------
function persSatisfacaoDelta(p, team, playRate){
  const t = persTraco(p);
  const repJog = p.reputacaoJogador || 0;
  const repClube = team && team.reputacao != null ? team.reputacao : 50;
  if(t === "ambicioso") return (playRate < 0.5 ? -(0.5 - playRate) * 16 : playRate > 0.75 ? 3 : 0) - (repClube < 55 && repJog > 35 ? 3 : 0);
  if(t === "leal") return 4 + (playRate < 0.5 ? (0.5 - playRate) * 10 : 0);
  if(t === "lider") return 2 + (playRate < 0.5 ? (0.5 - playRate) * 6 : 0);
  return -2 + (Math.random() - 0.5) * 8;
}
function persSatisfacaoRate(p){ return { ambicioso: 0.12, leal: 0.08, lider: 0.09, instavel: 0.15 }[persTraco(p)] || 0.10; }
function persMoralMult(p){ return { ambicioso: 1.2, leal: 0.6, lider: 0.8, instavel: 1.6 }[persTraco(p)] || 1; }
function persCartaoMult(p){ return { instavel: 1.5, ambicioso: 1.1, leal: 0.95, lider: 0.85 }[persTraco(p)] || 1; }

// Antes de cada jogo: oscilação dos instáveis e pequeno bónus de líderes em jogos grandes.
function persPrepararJogo(home, away, grande){
  [home, away].forEach(team => {
    if(!team) return;
    (team.players || []).forEach(p => {
      const t = persTraco(p);
      const moral = p.moral != null ? p.moral : 60;
      let m = 1;
      if(t === "instavel"){
        const u1 = Math.max(1e-9, Math.random()), u2 = Math.random();
        const g = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
        m = clamp(1 + g * 0.022 - (moral < 45 ? 0.012 : 0), 0.94, 1.04);
      } else if(t === "lider") m = moral >= 45 ? (grande ? 1.018 : 1.006) : 1;
      else if(t === "ambicioso") m = grande ? 1.012 : 1;
      else if(t === "leal") m = (team === home && away && clubsAreDirectRivals(home, away)) ? 1.01 : 1;
      // 0.2.4: Clássicos — os voláteis oscilam mais, os calmos e profissionais ganham estabilidade.
      if(away && typeof derbyAmbienteJogador === "function") m = derbyAmbienteJogador(p, m, home, away);
      p.__persMult = m;
    });
  });
}
function persRendimentoFactor(p){ return ((p && p.__persMult) || 1) * (typeof scintAdaptacaoFactor === "function" ? scintAdaptacaoFactor(p) : 1); }

// ---------------------------------------------------------------------------------------------
// Balneário
// ---------------------------------------------------------------------------------------------
function persLiderBonus(p){ const t = persTraco(p); return t === "lider" ? 2.5 : t === "instavel" ? -1.5 : 0; }
function persBalnearioAlvo(squad){
  let l = 0, i = 0, le = 0;
  squad.forEach(p => { const t = persTraco(p); if(t === "lider") l++; else if(t === "instavel") i++; else if(t === "leal") le++; });
  return (l >= 2 ? 3 : l === 1 ? 1.5 : -1) - (i >= 3 ? 3 : i === 2 ? 1.5 : 0) + (le >= 4 ? 1.5 : 0);
}

// ---------------------------------------------------------------------------------------------
// Renovações e propostas
// ---------------------------------------------------------------------------------------------
function persSalarioMult(player, toTeam, isRenewal){
  const t = persTraco(player);
  if(t === "ambicioso") return 1.05 + ((toTeam && clubAppeal(toTeam) < 60) ? 0.05 : 0);
  if(t === "leal") return isRenewal ? 0.94 : 1;
  if(t === "instavel") return 1.04;
  return 1;
}
function persNegociacaoMod(player, fromTeam, toTeam, isRenewal){
  const t = persTraco(player);
  let m = 0;
  if(t === "leal"){
    if(isRenewal) m += 8;
    else if(fromTeam && toTeam && fromTeam.id !== toTeam.id){ m -= 6; if(clubsAreDirectRivals(fromTeam, toTeam)) m -= 24; }
  }
  if(t === "ambicioso" && fromTeam && toTeam){
    m += clamp((clubAppeal(toTeam) - clubAppeal(fromTeam)) * 0.25, -10, 10);
    if(isRenewal && (player.satisfacao != null ? player.satisfacao : 70) < 50) m -= 6;
  }
  if(t === "instavel" && isRenewal) m -= 4;
  if(t === "lider" && isRenewal) m += 3;
  return m;
}
// Recusa de renovação por personalidade (decidida uma vez por negociação, como a mágoa do papel).
function persRecusaRenovacao(player, toTeam){
  if(!player) return null;
  if(player.pedidoSaida) return "pedido";
  const sat = player.satisfacao != null ? player.satisfacao : 70;
  const t = persTraco(player);
  const rng = makeSeededRng(`${player.id}|${state.season}|${toTeam ? toTeam.id : "x"}|renov-pers`);
  const r = seededRndFloat(rng, 0, 1);
  if(t === "ambicioso" && sat < 45 && r < 0.35) return "ambicioso";
  if(t === "instavel" && sat < 40 && r < 0.30) return "instavel";
  return null;
}
function persTextoRecusa(player, motivo){
  if(motivo === "pedido") return "O jogador já pediu para sair do clube — não quer renovar.";
  if(motivo === "ambicioso") return "O jogador é ambicioso e sente que o clube não lhe dá o que procura — não quer continuar aqui.";
  return "O jogador está desavindo com o clube e não está disposto a renovar neste momento.";
}
// Colocar no mercado um jogador que pediu para sair acalma-o: percebe que o clube o ouviu.
function persAoListar(player){
  if(player && player.pedidoSaida){
    player.satisfacao = clamp((player.satisfacao != null ? player.satisfacao : 70) + 6, 0, 100);
    player.pedidoSaida.atendido = true;
  }
}

// ---------------------------------------------------------------------------------------------
// Evolução do traço
// ---------------------------------------------------------------------------------------------
function persDefinir(p, novo, team, texto){
  const antigo = persTraco(p);
  if(antigo === novo || !PERS_TRACOS[novo]) return;
  p.personalidade = novo;
  p.temperamento = PERS_TRACOS[novo].temperamento;
  if(team && isUserControlledTeam(team) && typeof pushNews === "function"){
    pushNews(state.currentDate, `${playerLinkHtml(team.id, p)} mudou de comportamento: ${texto} Passou de <b>${persLabelDe(antigo).toLowerCase()}</b> a <b>${persLabelDe(novo).toLowerCase()}</b>.`, "personalidade", `Mudança de personalidade: ${p.name}`, { teamId: team.id });
  }
}
function persFimDeEpoca(){
  Object.values(state.teams || {}).forEach(team => {
    if(!team || team.nuvemEuropeia || team.selecaoNacional) return;
    (team.players || []).forEach(p => {
      if(!p || p.__provisional) return;
      const t = persTraco(p);
      const sat = p.satisfacao != null ? p.satisfacao : 70;
      const lid = p.attrs && p.attrs.lideranca != null ? p.attrs.lideranca : 10;
      const age = p.age || 24;
      const jogos = (p.career && p.career.jogos) || 0;
      const r = Math.random();
      if((t === "leal" || t === "ambicioso") && age >= 29 && lid >= 14 && jogos >= 120 && r < 0.15)
        persDefinir(p, "lider", team, "com a experiência, tornou-se uma voz respeitada no balneário.");
      else if(t === "ambicioso" && age >= 31 && sat >= 60 && r < 0.20)
        persDefinir(p, "leal", team, "com a idade, aprendeu a valorizar a estabilidade e o clube.");
      else if(t === "instavel" && age >= 30 && sat >= 65 && r < 0.18)
        persDefinir(p, "leal", team, "amadureceu e estabilizou.");
      else if(t !== "instavel" && sat < 30 && age <= 30 && r < 0.10)
        persDefinir(p, "instavel", team, "uma época má deixou marcas e está mais irritadiço.");
      else if(t === "leal" && sat < 25 && r < 0.20)
        persDefinir(p, "ambicioso", team, "perdeu a paciência e quer mais da carreira.");
    });
  });
}

// ---------------------------------------------------------------------------------------------
// Mensal: pedidos de saída, conflitos no balneário, gestos de lealdade e aviso do adjunto
// ---------------------------------------------------------------------------------------------
function persMensal(team){
  if(!team || team.equipaPrincipalId || team.selecaoNacional || team.nuvemEuropeia || !Array.isArray(team.players)) return;
  const user = isUserControlledTeam(team);
  const squad = team.players.filter(p => p && !p.__provisional);
  const b = typeof ensureBalneario === "function" ? ensureBalneario(team) : null;
  const hoje = isoDate(state.currentDate || new Date());
  const risco = [];

  squad.forEach(p => {
    const t = persTraco(p);
    const sat = p.satisfacao != null ? p.satisfacao : 70;
    const moral = p.moral != null ? p.moral : 60;
    if(p.pedidoSaida && p.pedidoSaida.teamId !== team.id) p.pedidoSaida = null;

    // Pedido de saída (ambiciosos descontentes).
    if(!p.pedidoSaida && t === "ambicioso" && (p.age || 24) >= 19 && sat < 38 && Math.random() < (user ? 0.25 : 0.15)){
      p.pedidoSaida = { desde: hoje, motivo: "protagonismo", teamId: team.id };
      if(user){
        pushNews(state.currentDate, `${playerLinkHtml(team.id, p)} pediu para sair do ${teamLinkHtml(team.id)}. Considera que o clube não lhe dá o protagonismo que procura e quer ser vendido ou emprestado.<br><br>Podes ouvir propostas (colocá-lo no mercado), dar-lhe mais responsabilidade no plantel ou segurá-lo — mas a satisfação dele não vai melhorar sozinha, e enquanto o pedido durar não aceita renovar.`, "personalidade", `Pedido de saída: ${p.name}`, { teamId: team.id });
      } else {
        if(!p.transferListado){
          try { p.transferListado = true; p.valorPedido = Math.round(playerMarketValue(p, team) * 1.1); } catch(e){}
        }
        if((p.reputacaoJogador || 0) >= 45 && newsIsFromUserDivision(team.name))
          pushNews(state.currentDate, `${playerLinkHtml(team.id, p)} pediu para sair do ${teamLinkHtml(team.id)} e o clube já terá aberto a porta a propostas.`, "mercado", `Pedido de saída no ${team.name}`, { teamId: team.id });
      }
    } else if(p.pedidoSaida){
      if(sat >= 55 || p.pedidoSaida.atendido && sat >= 50){
        if(user) pushNews(state.currentDate, `${playerLinkHtml(team.id, p)} deixou cair o pedido de saída e diz-se focado no ${teamLinkHtml(team.id)}.`, "personalidade", `${p.name} retirou o pedido de saída`, { teamId: team.id });
        p.pedidoSaida = null;
      } else if(user && !p.transferListado){
        // Sem resposta do clube, o descontentamento agrava-se.
        p.moral = clamp(moral - 2.5, 0, 100); p.satisfacao = clamp(sat - 1.5, 0, 100);
        if(b) b.coesao = clamp(b.coesao - 0.8, 3, 99);
      }
    }

    if(user){
      if(p.pedidoSaida && !p.transferListado) risco.push({ p, txt: "pediu para sair e continua sem resposta do clube" });
      else if(t === "ambicioso" && sat < 52 && !p.pedidoSaida) risco.push({ p, txt: "é ambicioso e anda descontente; pode pedir para sair" });
      else if(t === "instavel" && (moral < 45 || sat < 50)) risco.push({ p, txt: "é instável e está de cabeça quente; risco de conflito e de cartões" });
      else if(t === "leal" && sat < 30) risco.push({ p, txt: "mesmo sendo leal, está a esgotar a paciência" });
    }
  });

  // Conflitos de balneário (instáveis) e quem os pacifica (líderes).
  if(b){
    squad.filter(p => persTraco(p) === "instavel" && (p.diasLesao || 0) === 0).forEach(p => {
      const sat = p.satisfacao != null ? p.satisfacao : 70;
      const prob = 0.035 * (sat < 50 ? 2 : 1) * (b.coesao < 45 ? 1.6 : 1) * (p.titular ? 1 : 1.4);
      if(Math.random() >= prob) return;
      const outros = squad.filter(q => q.id !== p.id);
      const colega = outros.length ? outros[Math.floor(Math.random() * outros.length)] : null;
      const comTreinador = !p.titular && Math.random() < 0.5;
      p.moral = clamp((p.moral != null ? p.moral : 60) - 8, 0, 100);
      p.satisfacao = clamp(sat - 4, 0, 100);
      b.coesao = clamp(b.coesao - 2.5, 3, 99);
      if(colega && !comTreinador) colega.moral = clamp((colega.moral != null ? colega.moral : 60) - 4, 0, 100);
      const lider = squad.find(q => q.id !== p.id && persTraco(q) === "lider" && (q.moral != null ? q.moral : 60) >= 45);
      const pacificou = !!lider && Math.random() < 0.55;
      if(pacificou){ b.coesao = clamp(b.coesao + 1.5, 3, 99); p.moral = clamp(p.moral + 3, 0, 100); }
      if(user){
        const quem = comTreinador ? "discutiu com o treinador por não ser opção" : colega ? `teve uma discussão acesa com ${playerLinkHtml(team.id, colega)} no balneário` : "teve um momento de exaltação no balneário";
        const fim = pacificou ? ` ${playerLinkHtml(team.id, lider)}, o líder do grupo, acalmou os ânimos e o assunto ficou sanado — por agora.` : " Ninguém conseguiu acalmar os ânimos de imediato e o ambiente ressentiu-se.";
        pushNews(state.currentDate, `${playerLinkHtml(team.id, p)} ${quem}.${fim}`, "personalidade", `Polémica no balneário: ${p.name}`, { teamId: team.id });
      }
    });
    // Gesto de um leal quando o grupo está em baixo.
    if(user && b.coesao < 45 && Math.random() < 0.08){
      const leal = squad.filter(p => persTraco(p) === "leal" && balnearioTenureYears(b, p) >= 2).sort((x, y) => balnearioTenureYears(b, y) - balnearioTenureYears(b, x))[0];
      if(leal){
        b.coesao = clamp(b.coesao + 1.5, 3, 99);
        pushNews(state.currentDate, `${playerLinkHtml(team.id, leal)}, há ${Math.max(2, Math.round(balnearioTenureYears(b, leal)))} anos no ${teamLinkHtml(team.id)}, deu a cara pelo clube nesta fase difícil e pediu união ao grupo.`, "personalidade", `${leal.name} dá a cara pelo clube`, { teamId: team.id });
      }
    }
  }

  // Aviso do adjunto (só o utilizador): jogadores em risco.
  if(user && risco.length){
    const linhas = risco.slice(0, 6).map(x => [playerLinkHtml(team.id, x.p), `${persLabelDe(persTraco(x.p)).toLowerCase()}: ${x.txt}.`]);
    pushNews(state.currentDate, repDoc({
      teamId: team.id, org: "Departamento técnico", titulo: "Jogadores em risco",
      sub: "Relatório do Treinador Adjunto",
      chips: [repChip(`${risco.length} jogador${risco.length > 1 ? "es" : ""} a acompanhar`, "aviso")],
      resumo: "Falar com eles, ajustar o papel no plantel ou ouvir propostas pode evitar o pior antes que o problema rebente.",
      secoes: [{ icone: "🧠", titulo: "A acompanhar", cheia: true, linhas: linhas }],
      rodape: "Balneário e personalidade · treinador adjunto",
    }), "tatica", "Adjunto: jogadores em risco", { teamId: team.id });
  }
}
