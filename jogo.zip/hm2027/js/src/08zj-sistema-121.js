// =====================================================================
// 0.3.8 — Terceiro sistema: 1-2-1 (losango)
//
// Formas dos sistemas (nomes usados na literatura do hóquei em patins — Apunts, "Táctica y estrategia
// en el hockey sobre patines"): 2-2 = quadrado, 1-2-1 = losango (rombo), 3-1 = triângulo. A defesa à
// zona toma a forma do sistema escolhido (ver 08zh-defesa.js), por isso há UM só 1-2-1, que serve de
// forma de ataque e de forma de defesa à zona.
//
// 1-2-1 no ataque: base (distribui, DEF/MED), dois alas (abertos, rápidos, qualquer linha) e um pivot
// (avançado de área). Na composição do onze: 1 AVÇ e 2 DEF/MED obrigatórios + 1 lugar livre de ala
// (aceita DEF/MED ou AVÇ). Os valores são estimativas de jogo, pequenas de propósito.
//
// Familiaridade própria em team.familiaridade121 (a que falta num save antigo vale 45, ligeiramente
// abaixo do neutro, como os sistemas secundários de um clube).
// =====================================================================
const SISTEMAS_TAC = Object.freeze(["3-1","2-2","1-2-1"]);
const SISTEMA_FORMA = Object.freeze({ "3-1":"triângulo", "2-2":"quadrado", "1-2-1":"losango" });
function sistemaOk(s){ return SISTEMAS_TAC.indexOf(s) >= 0; }
function famKeyOf(s){ return s==="2-2" ? "familiaridade22" : s==="1-2-1" ? "familiaridade121" : "familiaridade31"; }
function famOf(team, s){ const v = team ? team[famKeyOf(s)] : null; return v!=null ? v : (s==="1-2-1" ? 45 : 50); }
// soma/subtrai à familiaridade de um sistema (só em equipas que já têm identidade tática)
function famAdd(team, s, delta){
  if(!team || team.familiaridade31==null || team.familiaridade22==null) return;
  team[famKeyOf(s)] = roundDecimal(clamp(famOf(team, s) + delta, 0, 100));
}
// Pontuação do plantel para o 1-2-1: base (construtor), pivot (melhor avançado) e dois alas (os mais
// rápidos/técnicos dos restantes, de qualquer linha).
function sistema121Papeis(team){
  const pool = availablePlayersForSystemFit(team);
  const avcs = pool.filter(p=>p.linha==="Avancado").sort((a,b)=>playerSystemValue(b)-playerSystemValue(a));
  const defmeds = pool.filter(p=>p.linha!=="Avancado");
  const baseScore = p => playerSystemValue(p) + 0.5*defMedProfileScores(p).construtor;
  const base = defmeds.slice().sort((a,b)=>baseScore(b)-baseScore(a))[0] || null;
  const pivot = avcs[0] || null;
  const used = new Set([base, pivot].filter(Boolean).map(p=>p.id));
  const alaScore = p => playerSystemValue(p) + 0.4*(((p.attrs.velocidade||10)+(p.attrs.aceleracao||10)+(p.attrs.drible||10))/3);
  const alas = pool.filter(p=>!used.has(p.id)).sort((a,b)=>alaScore(b)-alaScore(a)).slice(0,2);
  return { pool, avcs, defmeds, base, pivot, alas };
}
function systemFitScore121(team){
  const r = sistema121Papeis(team);
  const baseV = r.base ? playerSystemValue(r.base) : 8;
  const pivotV = r.pivot ? playerSystemValue(r.pivot) : 8;
  const alasV = r.alas.length ? avg(r.alas.map(playerSystemValue)) : 8;
  const circ = [r.base].concat(r.alas).filter(Boolean);
  const circulation = circ.length ? avg(circ.map(p=>((p.attrs.criatividade||10)+(p.attrs.habilidade||10))/2)) : 10;
  const mobility = r.alas.length ? avg(r.alas.map(p=>((p.attrs.velocidade||10)+(p.attrs.aceleracao||10)+(p.attrs.resistencia||10))/3)) : 10;
  const depthPenalty = clamp((1-r.avcs.length)*10 + (2-r.defmeds.length)*6 + (4-r.pool.length)*6, 0, 30);
  return clamp(baseV*1.0 + pivotV*1.0 + alasV*1.6 + circulation*0.4 + mobility*0.2 - depthPenalty, 0, 100);
}
