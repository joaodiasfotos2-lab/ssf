// ============================= 08zn-staff-ecossistema.js =============================
// Ecossistema de staff — fase 1 (0.4.26). Pedido: "passagem de alguns jogadores para treinador
// quando acabam a carreira. Treinadores também se retiram. Deve haver um ecossistema de staff."
// Decisões do utilizador (2026-11-07): adjunto já na fase 1; pirâmide de carreira começa na 3.ª
// divisão; lendas do clube do utilizador podem ser oferecidas ao seu staff; staff especializado
// (preparador físico, treinador de GR, scout — fases seguintes) será manual com sugestão do adjunto.
//
// Modelo (mesma forma do treinador principal, 08c): pessoa = {id, nome, dataNascimento, nacionalidade,
//   paisOrigem, stats(12), clubeActualId, mandatoAtual, historico, etapa 0|1|2, funcao, origem
//   "gerado"|"ex-jogador", salario, semClubeDesde, jogadorId?, carreiraJogador?}.
//   etapa = nível já atingido na pirâmide: 0 formação · 1 adjunto · 2 principal.
// Lugares por clube (só clubes com academia — academyEligible): team.treinador (principal, 08c),
//   team.adjunto, team.treinadorFormacao. team.staffVagas.{adjunto,formacao}=true só no clube do
//   utilizador: lugar vazio à espera de ele contratar (a IA preenche os seus sozinha).
// Fluxos:
//   - Jogador que se reforma → ~20–55% passa a treinador (staffFromRetiredPlayer, chamado de
//     processRetirements). Entra no pool state.treinadoresDisponiveis. Lenda/ídolo do clube do
//     utilizador → proposta ao utilizador (state.staffPropostas, janela com Aceitar/Recusar).
//   - Treinadores retiram-se dos 60 aos 72 anos (staffAnnual, chamado de beginDefeso); arquivo em
//     state.staffRetirados. Pool: sem clube há >3 épocas → reforma/afastamento. Sem limite fixo de 25.
//   - Pirâmide: formação → adjunto → principal. Vagas de principal são preenchidas (08c) também por
//     promoção do adjunto do próprio clube ou de outro (candidatos extra: staffExtraHireCandidates).
//   - Adjunto: com a vaga de principal aberta, a equipa perde menos rendimento (0,96 em vez de 0,93).
//     Treinador de formação: ±10% no desenvolvimento da Academia (junto do efeito do principal).
//   - Custo: o staff do utilizador já está "incluído na estrutura" do clube; só o que exceder o salário
//     base do escalão é debitado (staffMensal).
// =================================================================================
var STAFF_RETIRE_MIN = 60;
var STAFF_RETIRE_MAX = 72;
var STAFF_POOL_CAP = 320;
var STAFF_PROPOSTA_DIAS = 14;
var STAFF_FUNCOES = {
  adjunto: { label: "Treinador adjunto", etapa: 1, slot: "adjunto", frac: 0.45 },
  formacao: { label: "Treinador de formação", etapa: 0, slot: "treinadorFormacao", frac: 0.30 },
};

function staffEtapa(c){ return c && c.etapa != null ? c.etapa : 2; }
function staffExp(c){ return c && c.stats && Number.isFinite(c.stats.reputacaoExperiencia) ? c.stats.reputacaoExperiencia : 8; }
function staffIdade(c, date){
  const d = new Date(date || state.currentDate || new Date()), b = new Date(c.dataNascimento);
  if(isNaN(b.getTime())) return 45;
  let a = d.getFullYear() - b.getFullYear();
  if(d.getMonth() < b.getMonth() || (d.getMonth() === b.getMonth() && d.getDate() < b.getDate())) a--;
  return a;
}
function staffRetireProb(age){
  if(age < STAFF_RETIRE_MIN) return 0;
  if(age >= STAFF_RETIRE_MAX) return 1;
  return Math.pow((age - (STAFF_RETIRE_MIN - 1)) / (STAFF_RETIRE_MAX - STAFF_RETIRE_MIN + 1), 1.8);
}
function staffPool(){ if(!Array.isArray(state.treinadoresDisponiveis)) state.treinadoresDisponiveis = []; return state.treinadoresDisponiveis; }
function staffArquivo(){ if(!Array.isArray(state.staffRetirados)) state.staffRetirados = []; return state.staffRetirados; }
function staffPropostas(){ if(!Array.isArray(state.staffPropostas)) state.staffPropostas = []; return state.staffPropostas; }
function staffHistTotals(c){
  const h = Array.isArray(c.historico) ? c.historico : [], m = c.mandatoAtual || {};
  return h.reduce((a, x) => ({ j: a.j + (x.jogos || 0), v: a.v + (x.vitorias || 0) }), { j: m.jogos || 0, v: m.vitorias || 0 });
}
function staffArquivar(c, motivo, clube){
  const t = staffHistTotals(c);
  staffArquivo().unshift({ id: c.id, nome: c.nome, idade: staffIdade(c), epoca: seasonLabel(state.season), motivo, etapa: staffEtapa(c), origem: c.origem || "gerado",
    clube: clube ? clube.name : null, jogos: t.j, vitorias: t.v, exp: Math.round(staffExp(c)) });
  if(staffArquivo().length > 400) staffArquivo().length = 400;
}

// ---------- salários ----------
function staffSalario(c, funcao, team){
  if(funcao === "principal") return treinadorSalarioMensal(c.stats, team);
  const f = STAFF_FUNCOES[funcao];
  return Math.max(400, Math.round(treinadorSalarioMensal(c.stats, team) * f.frac / 50) * 50);
}
function staffBaseline(team, funcao){
  const f = STAFF_FUNCOES[funcao];
  const rep = clamp((team.reputacao || 50) / 5, 2, 18);
  return Math.max(400, Math.round((800 + rep * 180) * f.frac / 50) * 50);
}
function staffExtraMensal(team){
  let extra = 0;
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const c = team[STAFF_FUNCOES[fn].slot];
    if(c) extra += Math.max(0, (c.salario != null ? c.salario : staffSalario(c, fn, team)) - staffBaseline(team, fn));
  });
  return extra;
}
function staffMensal(date){
  const d = new Date(date), key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  if(state.staffMonthKey === key) return;
  state.staffMonthKey = key;
  staffFillMissing();
  const team = state.teams[state.userTeamId];
  if(!team || team.equipaPrincipalId) return;
  const extra = staffExtraMensal(team);
  if(extra > 0) addFinanceMovement(team, "despesa", "Staff", "Salários do staff técnico acima da estrutura base do clube", Math.round(extra), d);
}

// ---------- geração ----------
function staffGenerate(team, funcao){
  const f = STAFF_FUNCOES[funcao];
  const pais = normalizeCountryCode(teamCountry(team));
  const id = `${team.id}-${funcao}-${uid()}`;
  const rng = makeSeededRng(id);
  const idade = funcao === "adjunto" ? seededRnd(rng, 32, 56) : seededRnd(rng, 28, 50);
  const stats = generateTreinadorStats(team, rng);
  const penal = funcao === "adjunto" ? 1.5 : 3;
  TREINADOR_STATS_COMPETENCIA.forEach(k => { stats[k] = clampAttr(stats[k] - penal); });
  const c = {
    id, nome: randomNameForCountry(pais, rng), dataNascimento: makeBirthDate(rng, idade, state.currentDate ? new Date(state.currentDate) : undefined),
    nacionalidade: nationalityForCountry(pais), paisOrigem: pais, stats, clubeActualId: team.id,
    mandatoAtual: defaultTreinadorMandato(state.season, state.currentDate), historico: [], etapa: f.etapa, funcao, origem: "gerado",
  };
  c.salario = staffSalario(c, funcao, team);
  return c;
}
function bootstrapStaffIfEmpty(team){
  if(!academyEligible(team)) return;
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const slot = STAFF_FUNCOES[fn].slot;
    if(team[slot]) return;
    if(team.staffVagas && team.staffVagas[fn]) return;
    team[slot] = staffGenerate(team, fn);
  });
}

// ---------- ex-jogadores → treinadores ----------
function staffCoachFromPlayer(player, team, etapa, rng){
  const ovr = overall(player), rep = player.reputacaoJogador || 0;
  const jogos = ((player.career && player.career.jogos) || 0) + ((player.season && player.season.jogos) || 0);
  const expBase = clampAttr(2 + ovr * 0.22 + rep / 100 * 5 + Math.min(2, jogos / 300));
  const stats = {};
  TREINADOR_STATS_COMPETENCIA.forEach(k => { stats[k] = clampAttr(expBase - 1 + seededRnd(rng, -3, 3)); });
  stats.reputacaoExperiencia = clampAttr(expBase);
  TREINADOR_STATS_PERFIL.forEach(k => { stats[k] = clampAttr(treinadorPerfilRoll(rng)); });
  const pais = normalizeCountryCode(player.paisOrigem || teamCountry(team));
  const c = {
    id: `${player.id}-treinador-${uid()}`, nome: player.name, dataNascimento: player.dataNascimento || makeBirthDate(rng, player.age || 35, state.currentDate ? new Date(state.currentDate) : undefined),
    nacionalidade: player.nacionalidade || nationalityForCountry(pais), paisOrigem: pais, stats, clubeActualId: null, mandatoAtual: null, historico: [],
    etapa, funcao: etapa >= 1 ? "adjunto" : "formacao", origem: "ex-jogador", jogadorId: player.id, especialidade: player.pos === "GR" ? "GR" : null,
    carreiraJogador: { jogos, ovr: Math.round(ovr), clube: team.name, epoca: seasonLabel(state.season) },
    semClubeDesde: isoDate(state.currentDate || new Date()),
  };
  return c;
}
function staffFromRetiredPlayer(player, team){
  try {
    if(!player || !team || team.selecaoNacional || team.nuvemEuropeia) return null;
    const rep = player.reputacaoJogador || 0;
    const jogos = ((player.career && player.career.jogos) || 0) + ((player.season && player.season.jogos) || 0);
    const mine = team.id === state.userTeamId;
    const lenda = mine && state.lendaJogadorId === player.id;
    const rng = makeSeededRng(`staff-ex:${player.id}:${state.season}`);
    let p = 0.10 + Math.min(0.15, rep / 100 * 0.15) + Math.min(0.12, jogos / 600 * 0.12) + (player.pos === "GR" ? 0.04 : 0);
    if(!lenda && seededRndFloat(rng, 0, 1) >= p) return null;
    const etapa = (lenda || rep >= 65 || jogos >= 400) ? 1 : 0;
    const c = staffCoachFromPlayer(player, team, etapa, rng);
    if(mine && (lenda || (jogos >= 150 && seededRndFloat(rng, 0, 1) < 0.5))){
      staffCriarProposta(team, c, etapa >= 1 ? "adjunto" : "formacao", lenda ? "lenda" : "idolo");
      return c;
    }
    staffPool().push(c);
    return c;
  } catch(e){ console.warn("[HM2027] staffFromRetiredPlayer", e); return null; }
}

// ---------- instalação num lugar ----------
function staffLimparSlot(team, funcao, motivo){
  const f = STAFF_FUNCOES[funcao], old = team[f.slot];
  if(!old) return null;
  const d = new Date(state.currentDate || new Date());
  const m = old.mandatoAtual || { jogos: 0, vitorias: 0, empates: 0, derrotas: 0 };
  old.historico = Array.isArray(old.historico) ? old.historico : [];
  old.historico.unshift({ clubId: team.id, clubName: team.name, epocaSaida: seasonLabel(state.season), jogos: m.jogos, vitorias: m.vitorias, empates: m.empates, derrotas: m.derrotas, motivoSaida: motivo || "substituido", data: isoDate(d), funcao });
  if(old.historico.length > 10) old.historico.length = 10;
  old.clubeActualId = null; old.mandatoAtual = null; old.semClubeDesde = isoDate(d); old.salario = null;
  team[f.slot] = null;
  return old;
}
function staffInstalar(team, funcao, c){
  const f = STAFF_FUNCOES[funcao];
  c.clubeActualId = team.id; c.funcao = funcao; c.etapa = Math.max(c.etapa != null ? c.etapa : 0, f.etapa);
  c.mandatoAtual = defaultTreinadorMandato(state.season, state.currentDate);
  c.semClubeDesde = null;
  c.salario = staffSalario(c, funcao, team);
  team[f.slot] = c;
  if(team.staffVagas) team.staffVagas[funcao] = false;
}

// ---------- preencher lugares (IA) ----------
function staffFitSlot(c, team, funcao){
  const alvo = (team.reputacao || 50) / 5 - (funcao === "adjunto" ? 2 : 4);
  return -Math.abs(staffExp(c) - alvo) - (funcao === "adjunto" ? 0 : Math.max(0, staffEtapa(c) - 1) * 3);
}
function staffFillSlot(team, funcao){
  const f = STAFF_FUNCOES[funcao];
  if(team[f.slot]) return;
  const rng = makeSeededRng(`staff-fill:${team.id}:${funcao}:${state.season}`);
  // promoção interna: o treinador de formação sobe a adjunto
  if(funcao === "adjunto" && team.treinadorFormacao && staffExp(team.treinadorFormacao) >= 9 && seededRndFloat(rng, 0, 1) < 0.5){
    const c = staffLimparSlot(team, "formacao", "promovido");
    staffInstalar(team, "adjunto", c);
    return;
  }
  const pool = staffPool();
  const cand = pool.map(c => ({ c, fit: staffFitSlot(c, team, funcao) }))
    .filter(x => !(x.c.historico && x.c.historico[0] && x.c.historico[0].clubId === team.id) && x.fit > -4 && staffExp(x.c) <= (team.reputacao || 50) / 5 + 2 && (funcao !== "formacao" || staffEtapa(x.c) <= 1))
    .sort((a, b) => b.fit - a.fit);
  if(cand.length){
    const c = cand[0].c;
    state.treinadoresDisponiveis = pool.filter(x => x !== c);
    staffInstalar(team, funcao, c);
    return;
  }
  staffInstalar(team, funcao, staffGenerate(team, funcao));
}

function staffFillMissing(){
  Object.values(state.teams).forEach(t => {
    if(t.id === state.userTeamId || t.equipaPrincipalId || !academyEligible(t)) return;
    Object.keys(STAFF_FUNCOES).forEach(fn => { if(!t[STAFF_FUNCOES[fn].slot]) staffFillSlot(t, fn); });
  });
}
// ---------- candidatos extra à vaga de principal (promoção do adjunto) ----------
function staffExtraHireCandidates(team, date, rng){
  const out = [];
  const alvo = (team.reputacao || 50) / 5;
  if(team.adjunto && staffExp(team.adjunto) >= alvo - 5)
    out.push({ tr: team.adjunto, score: treinadorFitScore(team.adjunto, team) + 2.5, origemClube: null, origemAdjunto: team });
  if(seededRndFloat(rng, 0, 1) < 0.25){
    Object.values(state.teams).forEach(other => {
      if(other.id === team.id || other.id === state.userTeamId || !academyEligible(other) || !other.adjunto) return;
      if(staffExp(other.adjunto) < Math.max(6, alvo - 3) || staffExp(other.adjunto) > alvo + 2) return;
      out.push({ tr: other.adjunto, score: treinadorFitScore(other.adjunto, team) + 1, origemClube: null, origemAdjunto: other });
    });
  }
  return out;
}
// Chamado por hireTreinadorForVacancy quando a escolha vem de um lugar de adjunto.
function staffPromoverAdjunto(tr, origem, team, date){
  const c = staffLimparSlot(origem, "adjunto", "promovido");
  if(origem.id !== team.id) pushTreinadorMercadoNews(origem, date, `${escapeHtml(tr.nome)}, adjunto do ${teamLinkHtml(origem.id)}, assume o comando técnico de outro clube.`, "Adjunto promovido a treinador");
  return c || tr;
}

// ---------- processo anual ----------
function staffProgress(c, role){
  if(!c || !c.stats) return;
  const e = staffExp(c);
  let d = 0;
  if(role === "principal"){
    const m = c.mandatoAtual;
    if(m && m.jogos >= 10){ const pct = treinadorRecordPct(m); d = pct >= 60 ? 1 : pct >= 50 ? 0.6 : pct >= 35 ? 0.2 : -0.4; }
    else d = 0.2;
  } else { d = e < 13 ? 0.5 : 0.2; }
  if(d) c.stats.reputacaoExperiencia = clamp(e + d, 0, 20);
}
function staffAnnual(){
  if(state.staffProcessedSeason === state.season) return;
  state.staffProcessedSeason = state.season;
  const date = new Date(state.currentDate || new Date());
  const iso = isoDate(date);
  const teams = Object.values(state.teams).filter(t => academyEligible(t) && !t.equipaPrincipalId);
  // 1. progressão de experiência
  teams.forEach(t => {
    if(t.treinador && t.id !== state.userTeamId) staffProgress(t.treinador, "principal");
    Object.keys(STAFF_FUNCOES).forEach(fn => { const c = t[STAFF_FUNCOES[fn].slot]; if(c) staffProgress(c, fn); });
  });
  // 2. reformas — principais (IA), adjuntos, formação, pool
  const retire = (c, tag) => seededRndFloat(makeSeededRng(`staff-ret:${c.id}:${state.season}:${tag}`), 0, 1) < staffRetireProb(staffIdade(c, date));
  teams.forEach(t => {
    const tr = t.treinador;
    if(tr && t.id !== state.userTeamId && retire(tr, "p")){
      registerTreinadorClubExit(tr, t, date, "reforma");
      staffArquivar(tr, "reforma", t);
      t.treinador = null;
      const rng = makeSeededRng(`treinador-vaga:${t.id}:${iso}`);
      t.treinadorVacancia = { desde: iso, motivo: "reforma", resolverEm: isoDate(addDays(date, seededRnd(rng, 14, 28))) };
      t.treinadorConfiancaBaixaMeses = 0; t.treinadorAvisoEmitido = false;
      pushTreinadorMercadoNews(t, date, `${escapeHtml(tr.nome)} reforma-se do banco do ${teamLinkHtml(t.id)}, aos ${staffIdade(tr, date)} anos.`, "Treinador reforma-se");
    }
    Object.keys(STAFF_FUNCOES).forEach(fn => {
      const c = t[STAFF_FUNCOES[fn].slot];
      if(c && retire(c, fn)){
        staffLimparSlot(t, fn, "reforma"); staffArquivar(c, "reforma", t);
        if(t.id === state.userTeamId){
          t.staffVagas = t.staffVagas || {}; t.staffVagas[fn] = true;
          pushNews(date, `${escapeHtml(c.nome)}, ${STAFF_FUNCOES[fn].label.toLowerCase()} do teu clube, reformou-se. Podes contratar um substituto em Clube → Staff técnico.`, "staff", "Staff: reforma", { teamId: t.id });
        }
      }
    });
  });
  state.treinadoresDisponiveis = staffPool().filter(c => {
    const idade = staffIdade(c, date);
    const ult = (c.historico && c.historico[0] && c.historico[0].data) || c.semClubeDesde;
    const anos = ult ? (date - new Date(ult)) / 31557600000 : 0;
    let sai = null;
    if(retire(c, "pool")) sai = "reforma";
    else if(anos >= 3 && seededRndFloat(makeSeededRng(`staff-afast:${c.id}:${state.season}`), 0, 1) < 0.35) sai = "afastado";
    else if(idade >= 66 && anos >= 1) sai = "reforma";
    if(!sai) return true;
    staffArquivar(c, sai, null);
    return false;
  });
  // 2b. rotação: adjuntos e formadores de clubes de IA mudam de ares ao fim de 2+ épocas (~10%/ano)
  teams.forEach(t => {
    if(t.id === state.userTeamId) return;
    Object.keys(STAFF_FUNCOES).forEach(fn => {
      const c = t[STAFF_FUNCOES[fn].slot];
      if(!c || !c.mandatoAtual || (state.season - (c.mandatoAtual.epocaInicio || 0)) < 2) return;
      if(seededRndFloat(makeSeededRng(`staff-rot:${c.id}:${state.season}`), 0, 1) < 0.10){
        const velho = staffLimparSlot(t, fn, "saida");
        if(velho) staffPool().push(velho);
      }
    });
  });
  // 3. preencher lugares (clubes de IA); o utilizador contrata os seus
  teams.forEach(t => {
    if(t.id === state.userTeamId) return;
    Object.keys(STAFF_FUNCOES).forEach(fn => staffFillSlot(t, fn));
  });
  // 4. limite técnico de segurança do pool
  const pool = staffPool();
  if(pool.length > STAFF_POOL_CAP){
    pool.sort((a, b) => staffExp(b) - staffExp(a));
    pool.slice(STAFF_POOL_CAP).forEach(c => staffArquivar(c, "afastado", null));
    pool.length = STAFF_POOL_CAP;
  }
}

// ---------- efeitos ----------
function staffFormacaoMult(team){
  const c = team && team.treinadorFormacao;
  if(!c || !c.stats || c.stats.desenvolvimentoJovens == null) return 1;
  return clamp(1 + (c.stats.desenvolvimentoJovens - 10) * 0.01, 0.9, 1.1);
}

// ---------- propostas ao utilizador (lendas e ídolos) ----------
function staffCriarProposta(team, c, funcao, motivo){
  const d = new Date(state.currentDate || new Date());
  const id = `sp:${c.id}`;
  c.semClubeDesde = isoDate(d);
  const p = { id, tipo: funcao, motivo, clubId: team.id, criada: isoDate(d), expiraEm: isoDate(addDays(d, STAFF_PROPOSTA_DIAS)), estado: "pendente", coach: c };
  staffPropostas().unshift(p);
  if(staffPropostas().length > 20) staffPropostas().length = 20;
  const quem = motivo === "lenda" ? "a lenda do clube" : "antigo jogador do clube";
  pushNews(d, `${escapeHtml(c.nome)}, ${quem}, terminou a carreira e quer ficar ligado ao ${teamLinkHtml(team.id)} como ${STAFF_FUNCOES[funcao].label.toLowerCase()}. Tens até ${fmtDateShort(p.expiraEm)} para decidir. <button class="news-open-staff" data-staff-act="proposta" data-id="${id}">Ver proposta →</button>`,
    "staff", "Proposta de staff", { teamId: team.id, autoAdvanceStop: true });
  return p;
}
function staffProposta(id){ return staffPropostas().find(p => p.id === id) || null; }
function staffResponderProposta(id, aceitar){
  const p = staffProposta(id);
  if(!p || p.estado !== "pendente") return { ok: false, reason: "Esta proposta já não está pendente." };
  const team = state.teams[p.clubId];
  if(aceitar){
    if(!team) return { ok: false, reason: "O clube já não existe." };
    const velho = staffLimparSlot(team, p.tipo, "substituido");
    if(velho) staffPool().unshift(velho);
    staffInstalar(team, p.tipo, p.coach);
    p.estado = "aceite";
    pushNews(state.currentDate, `${escapeHtml(p.coach.nome)} é o novo ${STAFF_FUNCOES[p.tipo].label.toLowerCase()} do ${teamLinkHtml(team.id)}.`, "staff", "Staff: novo elemento", { teamId: team.id });
  } else {
    p.estado = "recusada";
    staffPool().push(p.coach);
  }
  return { ok: true };
}
function staffResolveExpired(date){
  const iso = isoDate(new Date(date));
  staffPropostas().forEach(p => {
    if(p.estado === "pendente" && iso > p.expiraEm){ p.estado = "expirada"; staffPool().push(p.coach); }
  });
}

// ---------- contratar (utilizador) ----------
function staffCandidatos(funcao){
  const f = STAFF_FUNCOES[funcao];
  return staffPool().filter(c => funcao === "formacao" ? staffEtapa(c) <= 1 : true)
    .map(c => ({ c, q: TREINADOR_STATS_COMPETENCIA.reduce((a, k) => a + (c.stats[k] || 0), 0) / TREINADOR_STATS_COMPETENCIA.length + (funcao === "formacao" ? (c.stats.desenvolvimentoJovens || 0) * 0.5 : 0) }))
    .sort((a, b) => b.q - a.q).slice(0, 14).map(x => x.c);
}
function staffAceita(c, team, funcao){
  const need = staffExp(c) * 4 - (funcao === "adjunto" ? 10 : 20);
  return (team.reputacao || 50) >= need ? { ok: true } : { ok: false, reason: `${c.nome} não aceita: o clube não tem a estatura que ele procura.` };
}
function staffContratar(funcao, coachId){
  const team = state.teams[state.userTeamId], f = STAFF_FUNCOES[funcao];
  if(!team || !f) return { ok: false, reason: "Clube inválido." };
  const c = staffPool().find(x => x.id === coachId);
  if(!c) return { ok: false, reason: "Este candidato já não está disponível." };
  const a = staffAceita(c, team, funcao);
  if(!a.ok) return a;
  state.treinadoresDisponiveis = staffPool().filter(x => x !== c);
  const velho = staffLimparSlot(team, funcao, "substituido");
  if(velho) staffPool().unshift(velho);
  staffInstalar(team, funcao, c);
  pushNews(state.currentDate, `${escapeHtml(c.nome)} é o novo ${f.label.toLowerCase()} do ${teamLinkHtml(team.id)}.`, "staff", "Staff: novo elemento", { teamId: team.id });
  return { ok: true };
}

// ---------- fichas ----------
function staffFindById(id){
  let c = staffPool().find(x => x.id === id);
  if(c) return { c, clube: null };
  const p = staffPropostas().find(x => x.coach && x.coach.id === id);
  if(p) return { c: p.coach, clube: null };
  for(const t of Object.values(state.teams)){
    for(const fn of Object.keys(STAFF_FUNCOES)){ const x = t[STAFF_FUNCOES[fn].slot]; if(x && x.id === id) return { c: x, clube: t }; }
  }
  return null;
}
function staffFichaData(id){
  const r = staffFindById(id);
  if(!r) return null;
  const { c, clube } = r;
  const funcao = clube ? STAFF_FUNCOES[c.funcao] && STAFF_FUNCOES[c.funcao].label : null;
  return {
    kind: "pessoa", teamId: clube ? clube.id : null, nome: c.nome, nacionalidade: c.nacionalidade, dataNascimento: c.dataNascimento, stats: c.stats,
    clubeNome: clube ? clube.name : "Sem clube", mandatoAtual: c.mandatoAtual || defaultTreinadorMandato(state.season, state.currentDate),
    historico: c.historico || [], salario: c.salario != null ? c.salario : staffSalario(c, c.funcao === "adjunto" || c.funcao === "formacao" ? c.funcao : "adjunto", state.teams[state.userTeamId] || {}),
    funcaoLabel: funcao || (staffEtapa(c) >= 2 ? "Treinador (sem clube)" : "Candidato a staff"),
    origem: c.origem === "ex-jogador" ? `Ex-jogador${c.carreiraJogador ? ` (${c.carreiraJogador.jogos} jogos, OVR ${c.carreiraJogador.ovr})` : ""}` : "Treinador de carreira",
  };
}

// ---------- interface ----------
function staffStatCell(v){ return `<b style="color:${typeof attrValColor === "function" ? attrValColor(Math.round(v)) : "inherit"}">${Math.round(v)}</b>`; }
function staffClubHtml(team){
  if(!academyEligible(team) || team.equipaPrincipalId) return "";
  const mine = team.id === state.userTeamId;
  const rows = Object.keys(STAFF_FUNCOES).map(fn => {
    const f = STAFF_FUNCOES[fn], c = team[f.slot];
    const hire = mine ? ` <button class="btn btn-ghost" data-staff-act="hire" data-funcao="${fn}">${c ? "Mudar" : "Contratar"}</button>` : "";
    if(!c) return `<div class="pm-retro-row"><span class="lbl">${f.label}</span><span class="val">${mine ? '<span class="helptext">vaga por preencher</span>' : "—"}${hire}</span></div>`;
    const sal = c.salario != null ? c.salario : staffSalario(c, fn, team);
    const extra = mine ? Math.max(0, sal - staffBaseline(team, fn)) : 0;
    return `<div class="pm-retro-row"><span class="lbl">${f.label}</span><span class="val">${escapeHtml(c.nome)} <span class="helptext">${staffIdade(c)} anos · exp. ${Math.round(staffExp(c))}${c.origem === "ex-jogador" ? " · ex-jogador" : ""}${extra > 0 ? ` · +${fmtMoney(extra)}/mês` : ""}</span> <button class="btn btn-ghost" data-staff-act="ficha" data-id="${c.id}">Ficha</button>${hire}</span></div>`;
  }).join("");
  let props = "";
  if(mine){
    const pend = staffPropostas().filter(p => p.estado === "pendente");
    if(pend.length) props = `<div class="pm-retro-subline" style="margin-top:8px;">Propostas de staff:</div>` + pend.map(p => `<div class="pm-retro-row"><span class="lbl">${escapeHtml(p.coach.nome)}</span><span class="val">${STAFF_FUNCOES[p.tipo].label} · até ${fmtDateShort(p.expiraEm)} <button class="btn btn-ghost" data-staff-act="proposta" data-id="${p.id}">Ver</button></span></div>`).join("");
  }
  return `<div class="pm-retro-section-lbl" style="margin-top:14px;">Staff técnico</div>${rows}${props}`;
}
function staffOverlay(html){
  let root = document.getElementById("staffOverlay");
  if(root) root.remove();
  root = document.createElement("div");
  root.id = "staffOverlay"; root.className = "nm-overlay"; root.style.zIndex = 190;
  root.innerHTML = `<div class="nm-modal" role="dialog" aria-modal="true" style="max-width:760px;">${html}</div>`;
  document.body.appendChild(root);
  return root;
}
function staffRefresh(){
  try { if(typeof renderClubFichaView === "function" && document.getElementById("fichaStaffOpenBtn")) renderClubFichaView(); } catch(e){}
  try { if(typeof renderAll === "function") renderAll(); } catch(e){}
}
function openStaffHireModal(funcao){
  const team = state.teams[state.userTeamId], f = STAFF_FUNCOES[funcao];
  if(!team || !f) return;
  const cand = staffCandidatos(funcao);
  const atual = team[f.slot];
  const rows = cand.map(c => {
    const sal = staffSalario(c, funcao, team), extra = Math.max(0, sal - staffBaseline(team, funcao));
    return `<tr><td style="text-align:left;">${escapeHtml(c.nome)}</td><td>${staffIdade(c)}</td><td>${c.origem === "ex-jogador" ? "ex-jogador" : "treinador"}</td><td>${staffStatCell(staffExp(c))}</td><td>${staffStatCell(c.stats.desenvolvimentoJovens || 0)}</td><td>${staffStatCell(c.stats.adaptabilidade || 0)}</td><td>${fmtMoney(sal)}${extra > 0 ? ` <span class="helptext">(+${fmtMoney(extra)})</span>` : ""}</td><td><button class="btn btn-ghost" data-staff-act="ficha" data-id="${c.id}">Ficha</button> <button class="btn btn-primary" data-staff-do="contratar" data-id="${c.id}">Contratar</button></td></tr>`;
  }).join("");
  const root = staffOverlay(`
    <div class="nm-box" style="margin-bottom:8px;"><b>${f.label}</b> — ${atual ? `atual: ${escapeHtml(atual.nome)}` : "vaga por preencher"}.
      <div class="helptext" style="margin-top:4px;">Salário incluído na estrutura do clube: ${fmtMoney(staffBaseline(team, funcao))}/mês. O que exceder é debitado todos os meses.</div></div>
    <div class="nm-box" style="max-height:48vh;overflow:auto;"><table class="pm-retro-stat-table" style="text-align:center;"><thead><tr><th style="text-align:left;">Nome</th><th>Idade</th><th>Origem</th><th>Exp.</th><th>Jov.</th><th>Adapt.</th><th>Salário/mês</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="8">Sem candidatos disponíveis de momento.</td></tr>`}</tbody></table></div>
    <div class="nm-err" id="staffErr"></div>
    <div class="nm-foot"><button class="nm-btn" data-staff-do="fechar">Fechar</button></div>`);
  root.addEventListener("click", ev => {
    const b = ev.target.closest("[data-staff-do]");
    if(!b) return;
    const act = b.getAttribute("data-staff-do");
    if(act === "fechar"){ root.remove(); return; }
    if(act === "contratar"){
      const r = staffContratar(funcao, b.getAttribute("data-id"));
      if(!r.ok){ const er = document.getElementById("staffErr"); if(er) er.textContent = r.reason || "Não foi possível contratar."; return; }
      root.remove(); staffRefresh();
    }
  });
}
function openStaffProposalModal(id){
  const p = staffProposta(id);
  if(!p || p.estado !== "pendente") return;
  const team = state.teams[p.clubId], c = p.coach, f = STAFF_FUNCOES[p.tipo];
  const atual = team && team[f.slot];
  const sal = staffSalario(c, p.tipo, team), extra = Math.max(0, sal - staffBaseline(team, p.tipo));
  const kv = (k, v) => `<div class="nm-kv"><span>${k}</span><b>${v}</b></div>`;
  const root = staffOverlay(`
    <div class="nm-head"><h3>🎓 Proposta de staff</h3><p>${escapeHtml(c.nome)} quer ficar ligado ao clube depois de terminar a carreira.</p></div>
    <div class="nm-box">
      ${kv("Candidato", `${escapeHtml(c.nome)} · ${staffIdade(c)} anos`)}
      ${kv("Carreira de jogador", c.carreiraJogador ? `${c.carreiraJogador.jogos} jogos · OVR final ${c.carreiraJogador.ovr}` : "—")}
      ${kv("Função proposta", f.label)}
      ${kv("Experiência / Desenvolvimento de jovens", `${Math.round(staffExp(c))} / ${Math.round(c.stats.desenvolvimentoJovens || 0)}`)}
      ${kv("Salário", `${fmtMoney(sal)}/mês${extra > 0 ? ` (+${fmtMoney(extra)} acima da estrutura)` : " (incluído na estrutura)"}`)}
      ${kv("Atual", atual ? `${escapeHtml(atual.nome)} (passa a disponível)` : "vaga por preencher")}
      ${kv("Decides até", fmtDateShort(p.expiraEm))}
      <div class="nm-err" id="staffErr"></div>
    </div>
    <div class="nm-foot"><button class="nm-btn" data-staff-do="later">Decidir mais tarde</button><button class="nm-btn" data-staff-do="recusar">Recusar</button><button class="nm-btn p" data-staff-do="aceitar">Aceitar</button><button class="nm-btn" data-staff-act="ficha" data-id="${c.id}">Ficha</button></div>`);
  root.addEventListener("click", ev => {
    const b = ev.target.closest("[data-staff-do]");
    if(!b) return;
    const act = b.getAttribute("data-staff-do");
    if(act === "later"){ root.remove(); return; }
    const r = staffResponderProposta(id, act === "aceitar");
    if(!r.ok){ const er = document.getElementById("staffErr"); if(er) er.textContent = r.reason || "Erro."; return; }
    root.remove(); staffRefresh();
  });
}
document.addEventListener("click", ev => {
  const b = ev.target.closest && ev.target.closest("[data-staff-act]");
  if(!b) return;
  ev.preventDefault();
  const act = b.getAttribute("data-staff-act");
  if(act === "ficha") openTreinadorModal("pessoa", b.getAttribute("data-id"));
  else if(act === "hire") openStaffHireModal(b.getAttribute("data-funcao"));
  else if(act === "proposta") openStaffProposalModal(b.getAttribute("data-id"));
});
