  // =================================================================
  // Arquivo de épocas (0.4.21) — "revisitar as 5 épocas anteriores" nas competições de liga.
  // No início do defeso (antes das subidas/descidas e de as estatísticas serem repostas) guarda-se, por
  // competição: classificação final, TODOS os resultados, quadro do playoff, listas de estatísticas
  // (marcadores, assistências, MVP, guarda-redes, cartões) e os resumos de jogo do clube do utilizador +
  // todos os de playoff. Fica no save (state.competitionArchive[idCompetição] = [época mais recente, ...],
  // no máximo 5). Os nomes de jogador só são link enquanto o jogador existir — reformado deixa de ter link.
  // =================================================================
  var ARCHIVE_MAX_SEASONS = 5;
  var __archiveView = null;   // {compId, season} enquanto o ecrã mostra uma época arquivada (lido por matchSumRef/findMatchSummary)

  function competitionArchiveList(compId){
    const l = state.competitionArchive && state.competitionArchive[compId];
    return Array.isArray(l) ? l : [];
  }
  function competitionArchiveEntry(compId, season){
    return competitionArchiveList(compId).find(e=>e.season===season) || null;
  }

  // Link para a ficha de um jogador enquanto ele existir (num plantel/academia, ou como livre); reformado → só o nome.
  function archivedPlayerLinkHtml(name, teamId, playerId){
    const safe = escapeHtml(name||"");
    if(!playerId) return safe;
    const real = resolvePlayerTeamId(teamId, playerId);
    if(real) return `<button class="playername-btn" data-team="${real}" data-id="${playerId}">${safe}</button>`;
    if((state.freeAgents||[]).some(p=>p.id===playerId)) return `<button class="playername-btn" data-team="${teamId}" data-id="${playerId}">${safe}</button>`;
    return safe;
  }

  function withViewedCompetition(compId, fn){
    const prev = state.viewedCompetitionId;
    state.viewedCompetitionId = compId;
    try { return fn(); } finally { state.viewedCompetitionId = prev; }
  }

  // [id, nome, clube, ...valores] — uma linha por jogador de cada lista de estatísticas.
  function archiveStatRows(list, keys){
    return list.map(e=>[e.p.id, e.p.name, e.team.id, ...keys.map(k=>e.p.season[k]||0)]);
  }
  function archiveStatEntries(rows, keys){
    return rows.map(r=>{
      const season = {}; keys.forEach((k,i)=>{ season[k] = r[3+i]; });
      return { p:{ id:r[0], name:r[1], season }, team: state.teams[r[2]] || {id:r[2], name:r[2]} };
    });
  }
  const ARCHIVE_STAT_LISTS = [
    ["sc","topScorers",["golos"]], ["as","topAssists",["assistencias"]], ["mv","topMVP",["mvp"]],
    ["pe","topPenaltis",["penaltisDefendidos"]], ["lv","topLivresDiretos",["livresDiretosDefendidos"]],
    ["gq","gkQualified",["jogos","golosSofridos"]], ["gu","gkUnqualified",["jogos","golosSofridos"]],
    ["cd","topCartoes",["amarelos","azuis","vermelhos"]],
  ];

  function archiveCompetitionSeason(comp, nameIndex){
    const teamIds = comp.teamIds.slice(), idx = {};
    teamIds.forEach((id,i)=>{ idx[id]=i; });
    const rows = standingsForCompetition(comp.id);
    const table = rows.map(t=>[t.id, t.stats.J, t.stats.V, t.stats.E, t.stats.D, t.stats.GM, t.stats.GS, t.stats.Pts]);
    const rounds = comp.fixtures.map(r=>({
      d: r.date ? new Date(r.date).toISOString() : null,
      m: r.map(f=>[idx[f.home], idx[f.away], f.played?f.homeScore:-1, f.played?f.awayScore:-1, f.soWinner?1:0]),
    }));
    const L = withViewedCompetition(comp.id, computeStatLists);
    const stats = {}; ARCHIVE_STAT_LISTS.forEach(([k,name,keys])=>{ stats[k] = archiveStatRows(L[name], keys); });
    let playoff = null;
    if(comp.playoff){ playoff = JSON.parse(JSON.stringify(comp.playoff)); delete playoff.nextGameDate; }
    // Resumos de jogo: os do(s) clube(s) do utilizador e todos os de playoff, já com o id de cada jogador
    // (resolvido pelo nome ainda com os plantéis desta época) para os links funcionarem mais tarde.
    const sums = {}, store = state.matchSummaries || {};
    const mine = new Set(typeof userControlledTeamIds==="function" ? userControlledTeamIds() : [state.userTeamId]);
    const resolve = (name, side, h, a) => {
      const tid = side===0 ? h : a, t = state.teams[tid];
      const own = t && t.players.find(p=>p.name===name);
      if(own) return own.id;
      const c = nameIndex.get(name);
      return c && c.length===1 ? c[0] : null;
    };
    Object.keys(store).forEach(k=>{
      const [ck, h, a] = k.split("|"), po = ck.endsWith("#po"), base = po ? ck.slice(0,-3) : ck;
      if(base!==comp.id) return;
      if(!po && !mine.has(h) && !mine.has(a)) return;
      sums[k] = store[k].map(s=>{
        const c = { ...s };
        // v3 (0.4.22): [nome,lado,golos,assist.,cartões,nota,GR,id]; antes: [nome,lado,golos,assist.,cartões,id]
        const base = (s.v||0)>=3 ? 7 : 5;
        c.pl = (s.pl||[]).map(p=>{ const q = p.slice(0,base); q[base] = resolve(p[0], p[1], h, a); return q; });
        if(s.mvp) c.mvp = [s.mvp[0], s.mvp[1], s.mvp[2], resolve(s.mvp[0], s.mvp[1], h, a)];
        return c;
      });
    });
    return { season: state.season, label: seasonLabel(state.season), teamIds, table, rounds, stats, playoff, sums };
  }

  // name → [ids] de todos os jogadores com plantel (para resolver nomes de resumos que não estejam no clube).
  function archiveBuildNameIndex(){
    const m = new Map();
    Object.values(state.teams).forEach(t=>(t.players||[]).forEach(p=>{
      const l = m.get(p.name); if(l) l.push(p.id); else m.set(p.name, [p.id]);
    }));
    return m;
  }

  // Chamado em beginDefeso(), antes de closeCompletedSeasonPlayerStats() e das subidas/descidas.
  function archiveCompetitionsSeason(){
    if(!state.competitionArchive || typeof state.competitionArchive!=="object") state.competitionArchive = {};
    const nameIndex = archiveBuildNameIndex();
    Object.values(state.competitions).forEach(comp=>{
      try {
        const list = Array.isArray(state.competitionArchive[comp.id]) ? state.competitionArchive[comp.id] : [];
        if(list.length && list[0].season===state.season) return;   // já arquivada (defeso retomado)
        list.unshift(archiveCompetitionSeason(comp, nameIndex));
        list.length = Math.min(list.length, ARCHIVE_MAX_SEASONS);
        state.competitionArchive[comp.id] = list;
      } catch(e){ console.warn("[HM2027] arquivo de época falhou para", comp.id, e); }
    });
  }

  // ---- Seletor de época (só nas competições de liga com arquivo) ----
  function populateCompetitionViewSeasonSelect(){
    const sel = document.getElementById("competitionViewSeasonSelect"), lab = document.getElementById("competitionViewSeasonLabel");
    if(!sel) return;
    const compId = state.viewedCompetitionId, list = (state.competitions[compId] ? competitionArchiveList(compId) : []);
    const show = list.length>0;
    sel.classList.toggle("hidden", !show); if(lab) lab.classList.toggle("hidden", !show);
    if(!show){ sel.innerHTML = ""; return; }
    sel.innerHTML = `<option value="">Época atual (${seasonLabel(state.season)})</option>` + list.map(e=>`<option value="${e.season}">${e.label}</option>`).join("");
    const cur = (state.viewedArchive && state.viewedArchive.compId===compId) ? state.viewedArchive.season : null;
    sel.value = (cur!=null && list.some(e=>e.season===cur)) ? String(cur) : "";
  }
  function viewedArchiveEntry(compId){
    const v = state.viewedArchive;
    if(!v || v.compId!==compId) return null;
    return competitionArchiveEntry(compId, v.season);
  }
  (function(){
    const sel = document.getElementById("competitionViewSeasonSelect");
    if(sel) sel.addEventListener("change", e=>{
      const v = e.target.value;
      state.viewedArchive = v==="" ? null : { compId: state.viewedCompetitionId, season: parseInt(v,10) };
      renderCompetitionView();
    });
  })();

  // ---- Desenho de uma época arquivada (mesmos contentores do ecrã normal) ----
  function renderArchivedCompetition(comp, entry){
    __archiveView = { compId: comp.id, season: entry.season };
    const meta = document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = `Época ${entry.label} (arquivo) · ${entry.teamIds.length} clubes`;
    const tn = id => (state.teams[id] ? state.teams[id].name : id);
    // classificação
    const n = entry.table.length;
    document.getElementById("standingsBody").innerHTML = entry.table.map((r,i)=>{
      const [id,J,V,E,D,GM,GS,Pts] = r, t = state.teams[id], pos = i+1, dg = GM-GS;
      return `<tr class="${id===state.userTeamId?'me':''} ${standingsZoneClass(comp,pos,n)}">
        <td class="num">${pos}</td>
        <td class="teamcell"><span class="swatch" style="background:${t?clubDisplayColor(t):'#888'};"></span><button class="jr-team-link" data-team="${id}">${escapeHtml(tn(id))}</button></td>
        <td class="num">${J}</td><td class="num">${V}</td><td class="num">${E}</td><td class="num">${D}</td>
        <td class="num">${GM}</td><td class="num">${GS}</td><td class="num">${dg>0?'+':''}${dg}</td>
        <td class="num"><b>${Pts}</b></td></tr>`;
    }).join("");
    // calendário & resultados
    const occSeen = {};
    document.getElementById("fixturesBody").innerHTML = entry.rounds.map((rd, ri)=>{
      const rows = rd.m.map(m=>{
        const home = entry.teamIds[m[0]], away = entry.teamIds[m[1]];
        const isMe = home===state.userTeamId || away===state.userTeamId, played = m[2]>=0;
        let attr = "", cls = "";
        if(played){
          const ok = home+"|"+away, occ = occSeen[ok]||0; occSeen[ok] = occ+1;
          const ref = matchSumRef(comp.id, home, away, occ);
          if(ref){ attr = ` data-sum="${ref}" data-sumlabel="${escapeHtml(entry.label)} · Jornada ${ri+1}" title="Ver resumo do jogo"`; cls = " has-sum"; }
        }
        const score = played ? `${m[2]} – ${m[3]}${m[4]?' <span style="font-size:9px;color:var(--texto-mute);">(g.p.)</span>':''}` : "—";
        return `<div class="fixture-row ${isMe?'me':''}">
          <div class="home"><button class="jr-team-link jr-home" data-team="${home}">${escapeHtml(tn(home))}</button></div><div class="vs${cls}"${attr}>${score}</div><div class="away"><button class="jr-team-link jr-away" data-team="${away}">${escapeHtml(tn(away))}</button></div>
        </div>`;
      }).join("");
      return `<div class="jornada-heading">Jornada ${ri+1}</div>${rows}`;
    }).join("");
    // estatísticas
    const L = {}; ARCHIVE_STAT_LISTS.forEach(([k,name,keys])=>{ L[name] = archiveStatEntries(entry.stats[k]||[], keys); });
    document.getElementById("statsGrid").innerHTML = statsGridHtml(L, `nessa época`);
    // equipas: os plantéis de épocas passadas não se guardam
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = `<p class="helptext">Os plantéis não ficam guardados nas épocas anteriores. Escolhe "Época atual" para ver as equipas.</p>`;
    // playoff
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab){
      if(entry.playoff && typeof PLAYOFF_DIVISION_CONFIG!=="undefined" && PLAYOFF_DIVISION_CONFIG[comp.divisionId]){
        renderPlayoffTab({ id: comp.id, divisionId: comp.divisionId, status: "concluida", playoff: entry.playoff });
      } else playoffTab.innerHTML = '<p class="helptext">Sem playoff guardado para esta época.</p>';
    }
  }

  // =================================================================
  // Confronto directo (0.4.22) — jogos anteriores entre os dois clubes de um resumo: época atual (liga, playoffs, taças)
  // + as épocas arquivadas das ligas onde ambos jogaram. Cada linha com resumo guardado abre-o ao clicar.
  // Devolve { html, count } — count = n.º de jogos anteriores encontrados.
  // =================================================================
  var H2H_MAX_ROWS = 8;
  function headToHeadBuild(c){
    const A = c.h, B = c.a;
    if(!A || !B || A===B) return null;
    const pair = (h,a) => (h===A && a===B) || (h===B && a===A);
    const meetings = [];   // {dt, sort, label, h, a, hs, as, so, ref, base}
    const baseOf = ck => ck.endsWith("#po") ? ck.slice(0,-3) : ck;
    const compLabel = (ck) => {
      const base = baseOf(ck), po = ck.endsWith("#po");
      const nm = (typeof COMPETITION_LABELS!=="undefined" && COMPETITION_LABELS[base]) || (state.competitions[base] && (state.competitions[base].label||state.competitions[base].name)) || base;
      return nm + (po ? " · Playoff" : "");
    };
    const refOf = (store, prefix, ck, h, a, occ) => {
      const arr = store && store[matchSummaryKey(ck, h, a)];
      return (arr && arr.length>occ) ? `${prefix}${ck}|${h}|${a}|${occ}` : null;
    };
    // --- época atual: liga (calendário) ---
    const curStore = state.matchSummaries || {}, leagueIds = new Set();
    Object.values(state.competitions||{}).forEach(comp=>{
      if(!comp || !Array.isArray(comp.fixtures) || !comp.teamIds || !comp.teamIds.includes(A) || !comp.teamIds.includes(B)) return;
      leagueIds.add(comp.id);
      const occSeen = {};
      comp.fixtures.forEach((round, ri)=>{
        round.forEach(f=>{
          if(!f.played) return;
          const ok = f.home+"|"+f.away, occ = occSeen[ok]||0; occSeen[ok] = occ+1;
          if(!pair(f.home, f.away)) return;
          const d = round.date ? dayKey(round.date) : "";
          meetings.push({ dt:d, sort:d+"|0", label:`${compLabel(comp.id)} · Jornada ${ri+1}`, h:f.home, a:f.away, hs:f.homeScore, as:f.awayScore, so:f.soWinner?1:0, ref:refOf(curStore, "", comp.id, f.home, f.away, occ), base:comp.id });
        });
      });
    });
    // --- época atual: playoffs e restantes competições (só existem nos resumos guardados) ---
    Object.keys(curStore).forEach(k=>{
      const [ck, h, a] = k.split("|");
      if(!pair(h,a) || leagueIds.has(ck)) return;
      curStore[k].forEach((s, i)=>{
        const d = s.dt || "";
        meetings.push({ dt:d, sort:d+"|1"+String(i).padStart(2,"0"), label:compLabel(ck), h, a, hs:s.hs, as:s.as, so:s.so||0, ref:`${ck}|${h}|${a}|${i}`, base:baseOf(ck) });
      });
    });
    // --- épocas arquivadas (ligas onde ambos jogaram) ---
    Object.keys(state.competitionArchive||{}).forEach(compId=>{
      competitionArchiveList(compId).forEach(e=>{
        if(e.season===state.season && leagueIds.has(compId)) return;   // defeso: já contada acima
        const hi = e.teamIds.indexOf(A), ai = e.teamIds.indexOf(B);
        if(hi<0 || ai<0) return;
        const prefix = `${e.season}~`, occSeen = {};
        let lastDate = "";
        e.rounds.forEach((rd, ri)=>{
          const d = rd.d ? dayKey(rd.d) : ""; if(d) lastDate = d;
          rd.m.forEach(m=>{
            if(m[2]<0) return;
            const h = e.teamIds[m[0]], a = e.teamIds[m[1]];
            const ok = h+"|"+a, occ = occSeen[ok]||0; occSeen[ok] = occ+1;
            if(!pair(h,a)) return;
            meetings.push({ dt:d, sort:d+"|0", label:`${compLabel(compId)} ${e.label} · Jornada ${ri+1}`, h, a, hs:m[2], as:m[3], so:m[4]?1:0, ref:refOf(e.sums, prefix, compId, h, a, occ), base:compId });
          });
        });
        Object.keys(e.sums||{}).forEach(k=>{
          const [ck, h, a] = k.split("|");
          if(!ck.endsWith("#po") || !pair(h,a)) return;
          e.sums[k].forEach((s, i)=>{
            const d = s.dt || "";
            meetings.push({ dt:d||lastDate, sort:(d||lastDate)+"|1"+String(i).padStart(2,"0"), label:`${compLabel(ck)} ${e.label}`, h, a, hs:s.hs, as:s.as, so:s.so||0, ref:`${prefix}${ck}|${h}|${a}|${i}`, base:compId, season:e.label, approx:!d });
          });
        });
      });
    });
    // --- só o que veio antes deste jogo ---
    // Resumos sem data (anteriores à 0.4.22): tira o próprio jogo e mostra os restantes.
    const before = c.dt
      ? meetings.filter(m => m.dt ? m.dt < c.dt : false)
      : meetings.filter(m => !(m.base===c.c && m.h===c.h && m.a===c.a && m.hs===c.hs && m.as===c.as));
    before.sort((x,y)=> x.sort<y.sort ? 1 : x.sort>y.sort ? -1 : 0);
    const tn = id => escapeHtml((state.teams[id]&&state.teams[id].name)||id);
    if(!before.length){
      return { count:0, html:`<div class="ms-h2h"><div class="ms-h2h-none">Primeiro confronto registado entre <b>${tn(A)}</b> e <b>${tn(B)}</b>.<br><small>O histórico guarda a época atual e as 5 épocas anteriores das ligas.</small></div></div>` };
    }
    // Mini-campeonato só com os jogos entre os dois clubes (3 pontos por vitória, 1 por empate; g.p. conta como empate)
    const T = {}; [A,B].forEach(id=>{ T[id] = { id, J:0, V:0, E:0, D:0, GM:0, GS:0 }; });
    before.forEach(m=>{
      const hh = T[m.h], aa = T[m.a];
      hh.J++; aa.J++; hh.GM += m.hs; hh.GS += m.as; aa.GM += m.as; aa.GS += m.hs;
      if(m.hs>m.as){ hh.V++; aa.D++; } else if(m.hs<m.as){ aa.V++; hh.D++; } else { hh.E++; aa.E++; }
    });
    const tab = [T[A], T[B]].map(t=>({ ...t, Pts:t.V*3+t.E, DG:t.GM-t.GS }));
    tab.sort((x,y)=> (y.Pts-x.Pts) || (y.DG-x.DG) || (y.GM-x.GM));
    const tabRows = tab.map((t,i)=>`<tr class="${t.id===A?"me":""}"><td class="num">${i+1}</td><td class="tc"><span class="swatch" style="background:${state.teams[t.id]?clubDisplayColor(state.teams[t.id]):"#888"};"></span>${tn(t.id)}</td><td class="num">${t.J}</td><td class="num">${t.V}</td><td class="num">${t.E}</td><td class="num">${t.D}</td><td class="num">${t.GM}</td><td class="num">${t.GS}</td><td class="num">${t.DG>0?"+":""}${t.DG}</td><td class="num"><b>${t.Pts}</b></td></tr>`).join("");
    const rows = before.slice(0, H2H_MAX_ROWS).map(m=>{
      const f = m.h===A ? m.hs : m.as, g = m.h===A ? m.as : m.hs;
      const res = f>g ? "v" : f<g ? "d" : "e", resTxt = {v:"V", e:"E", d:"D"}[res];
      const when = (m.dt && !m.approx) ? fmtDateShort(new Date(m.dt+"T12:00:00")) : (m.season||"");
      const so = m.so ? ` <span class="g-p">(g.p.)</span>` : "";
      const attr = m.ref ? ` data-sum="${m.ref}" data-sumlabel="${escapeHtml(m.label)}" title="Ver resumo do jogo"` : "";
      return `<div class="ms-h2h-row${m.ref?" has-sum":""}"${attr}><span class="rs ${res}" title="Resultado para ${escapeHtml((state.teams[A]||{}).name||A)}">${resTxt}</span><span class="dt">${when}</span><span class="cp">${escapeHtml(m.label)}</span><span class="tm h">${tn(m.h)}</span><b class="sc">${m.hs} – ${m.as}${so}</b><span class="tm a">${tn(m.a)}</span></div>`;
    }).join("");
    const more = before.length>H2H_MAX_ROWS ? `<div class="ms-h2h-more">+ ${before.length-H2H_MAX_ROWS} jogos anteriores</div>` : "";
    const html = `<div class="ms-h2h">
      <table class="ms-h2h-tab"><thead><tr><th>#</th><th class="tc">Clube</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GM</th><th>GS</th><th>DG</th><th>Pts</th></tr></thead><tbody>${tabRows}</tbody></table>
      <div class="ms-h2h-goals"><small>Só os jogos entre os dois clubes · g.p. conta como empate</small></div>
      <div class="ms-h2h-list">${rows}</div>${more}
    </div>`;
    return { html, count: before.length };
  }
